@extends('layouts.admin.panel')
@section('breadcrumb')
    <div class="ui breadcrumb">
        <a class="section" href="{{ route('Laralum::users') }}">{{ trans('laralum.user_list') }}</a>
        <i class="right angle icon divider"></i>
        <div class="active section">{{ trans('laralum.users_edit_title') }}</div>
    </div>
@endsection
@section('title', trans('laralum.users_edit_title'))
@section('icon', "edit")
@section('subtitle', trans('laralum.users_edit_subtitle', ['email' => $row->email]))
@section('content')
<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                <h2> </h2>
                <ul class="nav navbar-right panel_toolbox">
                </ul>
                <div class="clearfix"></div>
            </div>
            <div class="x_content">
            <br>
                <form class="form-horizontal form-label-left" method="POST">
                    <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-3">Nom Prénom <span class="required">*</span></label>
                        <div class="col-md-9 col-sm-9 col-xs-9">
                            <input class="form-control  has-feedback-left" type="text" name="name" id="name" value="{{ $row->name }}" required="required">                 
                            <span class="fa fa-user form-control-feedback left" aria-hidden="true"></span>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-3">Email <span class="required">*</span></label>
                        <div class="col-md-9 col-sm-9 col-xs-9">
                            <input class="form-control has-feedback-left" name="email" id="email" type="text" value="{{ $row->email}}" required="required">
                            <span class="fa fa-envelope form-control-feedback left" aria-hidden="true"></span>
                        </div>
                    </div>
                    <!--<div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-3">Mot de passe <span class="required">*</span></label>
                        <div class="col-md-9 col-sm-9 col-xs-9">
                            <input class="form-control has-feedback-left" id="password" name="password" type="password" value="{{ $row->password }}" required="required">
                            <span class="fa fa-lock form-control-feedback left" aria-hidden="true"></span>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-3">Confirmer mot de passe <span class="required">*</span></label>
                        <div class="col-md-9 col-sm-9 col-xs-9">
                            <input  class="form-control has-feedback-left" id="password_confirmation" name="password_confirmation"  value="{{ $row->password }}" type="password" value="" required="required" >
                            <span class="fa fa-lock form-control-feedback left" aria-hidden="true"></span>
                        </div>
                    </div>-->
                    <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12">Roles</label>
                        <div class="col-md-9 col-sm-9 col-xs-12">
                            <div class="">
                                <ul class="to_do">
                                    @foreach($roles as $role)
                                            <li>
                                                <p>
                                                    <input type="checkbox" class="flat" name="{{ $role->id }}" @foreach($roles_user as $role_user) @if($role->id == $role_user->role_id)<?php echo "checked" ?> @endif @endforeach> {{ $role->name }}
                                                </p>
                                            </li>
                                    @endforeach
                                </ul>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12">{{ trans('laralum.users_activate_user') }}</label>
                            <div class="col-md-3 col-sm-3 col-xs-12">
                                <div class="">
                                    <label>
                                        <input name="active" id="active" type="checkbox" class="js-switch" @if($row->active == '1') <?php echo "checked" ?> @endif/>
                                    </label>
                                </div>                                                
                            </div>
                        </div>
                    <div class="ln_solid"></div>
                    <div class="form-group">
                        <div class="col-md-9 col-md-offset-9">
                            {{ csrf_field() }}
                            <input class="form-control" type="hidden" name="country_code" id="country_code" value="FR">
                            <a href="{{ route('Laralum::users') }}"><button type="button" class="btn btn-primary">Liste des utilisateurs</button></a>
                            <button type="submit" class="btn btn-success">Valider</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection

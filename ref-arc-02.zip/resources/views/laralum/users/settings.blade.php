@extends('layouts.admin.panel')
@section('breadcrumb')
<div class="ui breadcrumb">
  <i class="fa fa-cogs"></i>
    <strong>{{ trans('laralum.users_settings') }}</strong>
</div>
@endsection
@section('title', trans('laralum.users_settings_title'))
@section('icon', "options")
@section('subtitle', trans('laralum.users_settings_subtitle'))
@section('content')
<div class="x_panel">
  <div class="x_content">
    <br>
    <form id="edit_project" data-parsley-validate="" class="form-horizontal form-label-left" novalidate="" method="POST">
        {{ csrf_field() }}
      <div class="form-group">
        <label class="control-label col-md-3 col-sm-3 col-xs-12">Role par défaut</label>
        <div class="col-md-3 col-sm-3 col-xs-12">
          <select name="default_role" class="select2_single form-control" tabindex="-1">
            @foreach($roles as $role)
            <option <?php if($rows->default_role == $role->id){ echo "selected"; } ?> value="{{ $role->id }}">{{ $role->name }}</option>
            @endforeach          
        </select>
    </div>
</div>
<!--<div class="form-group">
<label class="control-label col-md-3 col-sm-3 col-xs-12">Location</label>
    <div class="col-md-3 col-sm-3 col-xs-12">
      <div class="">
        <label>
          <input name="location" type="checkbox" class="js-switch" <?php if($rows->location){ echo "checked"; } ?>/>
      </label>
  </div>                                                
</div>
</div>-->
<div class="form-group">
    <label class="control-label col-md-3 col-sm-3 col-xs-12">Autoriser l'inscription</label>
    <div class="col-md-3 col-sm-3 col-xs-12">
      <div class="">
        <label>
          <input name="register_enabled" type="checkbox" class="js-switch"  <?php if($rows->register_enabled){ echo "checked"; } ?> />
      </label>
  </div>                                                
</div>
</div>
<div class="form-group">
    <label class="control-label col-md-3 col-sm-3 col-xs-12">Activation</label>
    <div class="col-md-3 col-sm-3 col-xs-12">
      <select name="default_active" class="select2_single form-control" tabindex="-1">
        @foreach($select_data as $key => $val)        
        <option <?php if($rows->default_active == $key){ echo "selected"; } ?> value="{{ $key }}">{{ $val }}</option> 
        @endforeach       
    </select>
</div>
</div>
<div class="form-group">
    <label class="control-label col-md-3 col-sm-3 col-xs-12">{{ trans('laralum.users_welcome_email') }}</label>
    <div class="col-md-3 col-sm-3 col-xs-12">
      <div class="">
        <label>
          <input name="welcome_email" type="checkbox" class="js-switch"  <?php if($rows->welcome_email){ echo "checked"; } ?> />
      </label>
  </div>                                                
</div>
</div>
<div class="ln_solid"></div>
<div class="form-group">
    <div class="col-md-3 col-sm-6 col-xs-12 pull-right">
      <a href="{{ route('Laralum::users') }}"><button type="submit" class="btn btn-primary">Retour</button></a>
      <button type="submit" class="btn btn-success">Valider</button>
  </div>
</div>
</form>
</div>
</div>
@endsection
@section('js')
<script>
  $(document).ready(function() {

    $(".select2_single").select2({
      placeholder: "Select a state",
      allowClear: true
  });
    $(".select2_group").select2({});
    $(".select2_multiple").select2({
      maximumSelectionLength: 4,
      placeholder: "With Max Selection limit 4",
      allowClear: true
  });
});
</script>
@endsection

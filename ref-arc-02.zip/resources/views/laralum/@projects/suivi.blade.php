<?php use App\User; ?>
@extends('layouts.admin.panel')
@section('breadcrumb')
<div class="ui breadcrumb">
  <i class="fa fa-edit"></i>
  <a class="section" href="{{ route('Laralum::projects') }}">{{ trans('laralum.projects_list') }}</a>
  / {{ $projects->name }}
</div>
@endsection
@section('title', trans('laralum.projects_edit'))
@section('icon', "book")
@section('subtitle', trans('laralum.projects_edit'))
@section('content')
<div class="x_panel">
  <div class="x_content">
    <div class="" role="tabpanel" data-example-id="togglable-tabs">
      <ul id="myTab" class="nav nav-tabs bar_tabs" role="tablist">
        <li role="presentation" class="active"><a href="#tab_content1" id="home-tab" role="tab" data-toggle="tab" aria-expanded="true">Profil</a>
        </li>
        <li role="presentation" class=""><a href="#tab_content2" role="tab" id="profile-tab" data-toggle="tab" aria-expanded="false">Historique</a>
        </li>
      </ul>
      <div id="myTabContent" class="tab-content">
        <div role="tabpanel" class="tab-pane fade active in" id="tab_content1" aria-labelledby="home-tab">
          <div class="row">           
          </div>
          <section class="col-md-3">
            <div class="x_panel">
              <div id="nameProj" class="x_title" style="text-align:center;"><h3 class="red">{{ $projects->name }}</h3></div>
              <div class="x_content">
                <label class="red">Description :</label><br>
                <p style="font-style:italic;" id="projectdesc">
                  {{ $projects->description }}
                </p>
                <label class="red">Createur :</label><br>
                <span><a href="{{ route('Laralum::users_profile', ['id' => $projects->user_id]) }}">
                 <i class="fa fa-user"></i> {{ User::find($projects->user_id)->name }}</a></span><br><br>
                 <label class="red">Date de creation :</label><br>
                 <span>{{ date('d F Y', strtotime($projects->created_at)) }}</span><br><br>
                 <label class="red">Date de dernière mise a jour :</label><br>
                 <span>{{ date('d F Y', strtotime($projects->updated_at)) }}</span><br><br>
                 <label class="red">Nombre d'applications :</label><br>
                 <span>{{ $projects->nb_apps }}</span><br><br>
                 <div class="ln_solid"></div>
                 @if(Laralum::loggedInUser()->hasPermission('refarc.projects.edit'))
                  <div style="text-align: center"><button type="button" class="btn btn-warning" data-toggle="modal" data-target=".modaleditapp"><i class="fa fa-pencil"></i> Modifier</button></div>
                 @endif
                 <div id="modal_app" class="modal fade modaleditapp" tabindex="-1" role="dialog" aria-hidden="true">
                   <div class="modal-dialog modal-lg">
                     <div class="modal-content">
                       <div class="modal-header" style="text-align: center">
                         <div class="modal-title"><h2>Modification de {{ $projects->name }}</h2></div>
                         <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">X</span>
                         </div>
                         <div class="modal-body">
                           <form id="edit_app" data-parsley-validate="" class="form-horizontal form-label-left" novalidate="" method="POST">
                            <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Projet <span class="required">*</span>
                              </label>
                              <div class="col-md-6 col-sm-6 col-xs-12">
                                <input id="project_name" name="name" required="required" class="form-control col-md-7 col-xs-12" type="text" value="{{ ucfirst($projects->name) }}">
                              </div>
                            </div>
                            <div class="form-group">
                              <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Description
                              </label>
                              <div class="col-md-6 col-sm-6 col-xs-12">
                                <textarea  id="project_desc" name="description" class="form-control" rows="3" style="width: 414px; height: 91px;">{{ $projects->description }}</textarea>
                              </div>
                            </div>                           
                            <input type="hidden" name="_token" value="<?php echo csrf_token() ?>">
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>
                          <button id="updateproj" type="button" class="btn btn-success">Modifier</button>
                        </div>
                        </form>
                      </div>
                  </div>
                 </div>
                </div>
              </section>
              <section class="col-md-9">
                <div class="x_panel">
                  <div class="x_title" style="color:#E74C3C;font-size:18px;">Liste des applications</div>
                  <div class="x_content">
                    <div class="row">
                      @if(Laralum::loggedInUser()->hasPermission('refarc.applications.create'))
                      <div class="col-md-6">
                        <label class="btn btn-success pull-left"  data-toggle="modal" data-target=".modaladdapp"><i class="fa fa-plus"></i> Ajouter une application</label>
                      </div>
                      @endif

                  <div id="modal_app_add" class="modal fade modaladdapp" tabindex="-1" role="dialog" aria-hidden="true">
                   <div class="modal-dialog modal-lg">
                     <div class="modal-content">
                       <div class="modal-header" style="text-align: center">
                         <div class="modal-title"><h2>Ajouter application</h2></div>
                         <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">X</span>
                         </div>
                         <div class="modal-body">
                           <form id="edit_app" data-parsley-validate="" class="form-horizontal form-label-left" novalidate="" method="POST">
                           <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Nom <span class="required">*</span>
                            </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                              <input id="name" name="nameapp" required="required" class="form-control col-md-7 col-xs-12" type="text" value="">
                            </div>
                          </div>
                          <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Ecolience
                            </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                              <input id="name" name="ecolience" class="form-control col-md-7 col-xs-12" type="text" value="">
                            </div>
                          </div>
                          <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">IRT 
                            </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                              <input id="name" name="irt" class="form-control col-md-7 col-xs-12" type="text" value="">
                            </div>
                          </div>
                          <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Trigramme 
                            </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                              <input id="name" name="trigramme" class="form-control col-md-7 col-xs-12" type="text" value="">
                            </div>
                          </div>
                          <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Criticité STAMP 
                            </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                              <select id="name" name="criticite_stamp" class="form-control col-md-7 col-xs-12" type="text" value="">
                                <option value="Non prioritaire">Non prioritaire</option>
                                <option value="Secondaire">Secondaire</option>
                                <option value="Critique">Critique</option>
                                <option value="Vitale">Vitale</option>
                              </select>
                            </div>
                          </div>
                          <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Sensible groupe 
                            </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                              <input id="name" name="sensible_groupe" class="form-control col-md-7 col-xs-12" type="text" value="">
                            </div>
                          </div>
                          <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Niveau de sensibilité fraude 
                            </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                              <input id="name" name="niv_sensible_fraude" class="form-control col-md-7 col-xs-12" type="text" value="">
                            </div>
                          </div>
                          <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">demande client 
                            </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                              <textarea  name="demande_client" class="form-control" rows="3" style="width: 414px; height: 91px;"></textarea>
                            </div>
                          </div>
                                              
                            <input type="hidden" name="_token" value="<?php echo csrf_token() ?>">
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>
                          <button id="addapps" type="button" class="btn btn-success">Modifier</button>
                        </div>
                        </form>
                      </div>
                  </div>
                 </div>
                    </div><br>
                    @foreach($applications as $application)
                    <div class="row">
                      <div class="animated flipInY col-lg-6 col-md-6 col-sm-12 col-xs-12">
                        <a href="{{ route('Laralum::applications', ['id' => $projects->id, 'idApp' => $application]) }}"><div class="tile-stats" style="border:1px solid #26B99A">
                          <div class="icon"><i class="fa fa-pencil" style="color:#26B99A;"></i></div>
                          <div class="count">0%</div>
                          <h3>{{ ucfirst($application->name) }}</h3><br>
                          <div class="progress">
                            <div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div>
                          </div>
                        </a>
                      </div>
                    </div>
                    @endforeach                                      
                  </div>
                </div>              
            </section>
          </div>
          <div role="tabpanel" class="tab-pane fade" id="tab_content2" aria-labelledby="profile-tab">
            <div class="col-md-12">
              <div class="row" style="text-align:center">
                <label style="font-size:24px">Historique</label>
              </div>
              <ul class="list-unstyled timeline">
                @foreach($history as $hist)
                <li>
                  <div class="block">
                    <div class="tags">
                      <a href="" class="tag">
                        <span>Modification</span>
                      </a>
                    </div>
                    <div class="block_content">
                      <h2 class="title">
                        @if($hist->namefield == 'name')
                        <a>Le nom du projet a été modifié</a>
                        @elseif($hist->namefield == 'description')
                        <a>La description du projet a été modifié</a>
                        @else
                        <a>Le statut a été modifié</a>
                        @endif
                      </h2>
                      <div class="byline">
                        <span>{{ date('d/m/Y h:i', strtotime($hist->updated_at)) }}</span> par <a class="red"><b>{{ ucfirst(User::find($hist->user_id)->name) }}</b></a>
                      </div>
                  </div>
                </div>
              </li>
              @endforeach
              <li>
                <div class="block">
                  <div class="tags">
                    <a href="" class="tag">
                      <span>Creation</span>
                    </a>
                  </div>
                  <div class="block_content">
                    <h2 class="title">
                      <a>Le projet a été crée</a>
                    </h2>
                    <div class="byline">
                      <span>{{ date('d/m/Y', strtotime($projects->created_at)) }}</span> par <a>{{ ucfirst(User::find($projects->user_id)->name) }}</a>
                    </div>
                  </div>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
@endsection
@section('js')
<script type="text/javascript">
  $("#updateproj").on('click', function(e) {
      $.ajax({
          type: 'get',
          url: "update?name="+$("#project_name").val()+"&description="+$("#project_desc").val()+"",
          success: function(result) { // Je récupère la réponse du fichier PHP
              $("#nameProj").html($("#project_name").val());
              $("#projectdesc").html($("#project_desc").val());
              $('#modal_app').modal('hide');
              location.reload();
              swal({
                title: "Modification",
                text: "Le DAH a bien été modifié",
                type: "success",
                confirmButtonText: "Fermer"
              });    
          }
      });
  });
  $("#addapps").on('click', function(e) {
      $.ajax({
          type: 'get',
          url: "application/create?idproject=<?php echo $projects->id ?>&nameapp="+$('input[name=nameapp]').val()+"&ecolience="+$('input[name=ecolience]').val()+"&irt="+$('input[name=irt]').val()+"&trigramme="+$('input[name=trigramme]').val()+"&criticite_stamp="+$('select[name=criticite_stamp]').val()+"&sensible_groupe="+$('input[name=sensible_groupe]').val()+"&niv_sensible_fraude="+$('input[name=niv_sensible_fraude]').val()+"&demande_client="+$('textarea[name=demande_client]').val()+"",
          success: function(result) { // Je récupère la réponse du fichier PHP
              $("#nameProj").html($("#project_name").val());
              $("#projectdesc").html($("#project_desc").val());
              $('#modal_app_add').modal('hide');
              location.reload();
              swal({
              title: "Création",
              text: "L'application a bien été crée",
              type: "success",
              confirmButtonText: "Fermer"
            });      
          }
      });
  });
</script>
@endsection
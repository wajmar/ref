    <?php use App\User; ?>
    @extends('layouts.admin.panel')
    @section('breadcrumb')    
    <div class="ui breadcrumb">
        <i class="fa fa-add"></i>
        <a class="section" href="{{ route('Laralum::projects') }}">{{ trans('laralum.projects_list') }}</a>
        / <small>{{ trans('laralum.projects_create') }}</small>
    </div>
    @endsection
    @section('title', trans('laralum.projects_create'))
    @section('icon', "add")
    @section('content')
    
    <div class="x_panel">
      <div class="x_title">
      <h3>Création d'un nouveau DAH</h3>
      </div>
      <div class="x_content">
        <br>
        <form id="add_project" data-parsley-validate="" class="form-horizontal form-label-left" novalidate="" method="POST">

          <div class="form-group">
            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Projet <span class="required">*</span>
            </label>
            <div class="col-md-6 col-sm-6 col-xs-12">
              <input id="name" name="name" required="required" class="form-control col-md-7 col-xs-12" type="text" value="">
          </div>
      </div>
      <div class="form-group">
        <label class="control-label col-md-3 col-sm-3 col-xs-12">
            {{ trans('laralum.description') }}
        </label>
        <div class="col-md-9 col-sm-9 col-xs-12">
          <textarea  name="description" class="form-control" rows="3" style="width: 611px; height: 110px;"></textarea>
      </div>
  </div>
  <div class="form-group">
    <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">Date de création</label>
    <div class="control-group">
        <div class="controls">
          <div class="col-md-3 xdisplay_inputx form-group has-feedback">
          <input type="text" name="created_at" class="form-control has-feedback-left" id="single_cal4" placeholder="" aria-describedby="inputSuccess2Status4">
            <span class="fa fa-calendar-o form-control-feedback left" aria-hidden="true"></span>
            <span id="inputSuccess2Status4" class="sr-only">(success)</span>
        </div>
    </div>
</div>
</div>
<div class="form-group">
    <label class="control-label col-md-3 col-sm-3 col-xs-12">Nombre d'applications
    </label>
    <div class="col-md-1">
        <input id="number" name="nb_apps" required="required" data-validate-minmax="1,10" class="form-control col-md-7 col-xs-12" type="number">        
    </div>
</div>
<input type="hidden" name="_token" value="<?php echo csrf_token() ?>">
<div class="ln_solid"></div>
<div class="form-group">
    <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-7">
      <a href="{{ route('Laralum::projects') }}"><button type="button" class="btn btn-primary">Liste des projets</button></a>
      <button type="submit" class="btn btn-success">Submit</button>
  </div>
</div>
</form>
</div>
</div>
@endsection
@section('js')
<script type="text/javascript">
    $(document).ready(function() {
        $('#single_cal4').daterangepicker({
          singleDatePicker: true,
          singleClasses: "picker_4"
      }, function(start, end, label) {
          console.log(start.toISOString(), end.toISOString(), label);
      });
    });
</script>
@endsection

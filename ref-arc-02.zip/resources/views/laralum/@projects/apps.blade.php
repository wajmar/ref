<?php use App\User; ?>
<div class="col-md-12 col-sm-12 col-xs-12">
  <div class="x_panel">
    <div class="x_content">
    <div class="progress">
          <div class="progress-bar progress-bar-danger progress-bar-striped" role="progressbar" aria-valuenow="12.5" aria-valuemin="0" aria-valuemax="100" style="width:10%">
          </div>
        </div>
      <br><br>
      <ul class="stats-overview">
        <li>
          <span class="name"> Version </span>
          <span class="value text-success" id="vers"> {{ $appsParams->version }} </span>
        </li>
        <li>
          <span class="name"> Créateur </span>
          <span class="value text-success"> {{ User::find($appsParams->user_id)->name }} </span>
        </li>
        <li class="hidden-phone">
          <span class="name"> Dernière modification </span>
          <span class="value text-success"> {{ date('d/m/Y', strtotime($appsParams->updated_at)) }} </span>
        </li>
      </ul><br>
    <form id="edit_app" data-parsley-validate="" class="form-horizontal form-label-left" novalidate="" method="POST">
        {{ csrf_field() }}
        <div><button type="button" class="btn btn-success btn-xs" onclick="versionUp('{{ $appsParams->version }}');"><i class="fa fa-level-up"></i> Version Majeure</button></div>
        <input type="hidden" name="appname" id="appname" value="{{ $appsParams->id }}">        
      </form>

      <br>
      <form id="edit_app" data-parsley-validate="" class="form-horizontal form-label-left" novalidate="" method="POST">
        {{ csrf_field() }}        
      <div class="accordion" id="accordion" role="tablist" aria-multiselectable="true">
        @foreach ($parents as $parent)
        <?php           
        $readonly = '';
        if (!Laralum::loggedInUser()->su) {
          $readonly = 'Readonly';
        }        
        ?>
        <div class="panel pan_{{ $parent->ordre }}" style="border-top:1px solid red;">
          <div class="panel-heading">             
            <a role="tab" id="heading_{{ $parent->ordre }}" data-toggle="collapse" data-parent="#accordion" href="#collapse_{{ $parent->ordre }}" aria-expanded="true" aria-controls="collapseOne">
              <h4 class="panel-title" style="height:inherit">
                <span class="label label-danger">{{ $parent->num_parag }}</span>
                <span id="title_{{ $parent->id }}">{{ $parent->text }}</span>
              </a>
              <span class="right">
              <span id="loader_{{ $parent->id }}"></span>




              <?php
                if (!empty($parent->modified)) {
                  echo '<i id="check_{{ $parent->id }}" class="btn btn-success btn-xs fa fa-check" data-toggle="tooltip" data-placement="top"
                  data-original-title="Cette partie a été modifié"></i>';
                } else {
                  echo '<i id="nocheck_'.$parent->id.'" class="btn btn-danger btn-xs fa fa-exclamation" data-toggle="tooltip" data-placement="top"
                  data-original-title="Cette partie n\'a pas été modifié"></i>';
                }
                ?>
                <button id="save_{{ $parent->id }}" type="button" class="btn btn-warning btn-xs"
                onclick="addParagraphApp({{ $parent->id }});"><i class="fa fa-save"></i> Valider le contenu</button>


                <button type="button" class="btn btn-info btn-xs" data-toggle="modal" data-target=".bs-modal_add_{{ $parent->id }}" id="modal_add_st_{{ $parent->id }}">
                  <i class="fa fa-question"></i> Aide</button>
                  <div id="modal_add_{{ $parent->id }}" class="modal fade bs-modal_add_{{ $parent->id }}" tabindex="-1" role="dialog" aria-hidden="true" style="display: none;">
                    <div class="modal-dialog modal-lg">
                      <div class="modal-content">
                        <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
                          </button>
                          <h4 class="modal-title" id="myModalLabel">Aide</h4>
                        </div>
                        <div class="modal-body">
                        <div class="form-group">
                          <p>{{ $parent->aide }}
                          <button onclick="modifComment();" type="button" class="btn btn-warning  btn-xs"><i class="fa fa-pencil"></i> Modifier</button>
                          </p>
                        </div>
                        <div class="modal-footer">
                          <div id="ftr" style="display: none;">
                          <button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>
                          <button type="button" class="btn btn-success" onclick="addParagraph({{ $parent->id }}, {{ $parent->num_parag }}, 1, {{ $parent->id_template }});">Ajouter</button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>


              </span>
            </h4>
          </div>
          <div id="collapse_{{ $parent->ordre }}" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading_{{ $parent->ordre }}">
            <div class="panel-body">
              <label>Partie fixe :</label><br>
              <input type="hidden" name="version" value="{{ $tpl->version }}">
              <input type="hidden" name="module" value="tpl"> 
              <input type="hidden" id="num_parag_{{$parent->id}}" name="num_parag" value="{{ $parent->num_parag }}">
              <input type="hidden" id="niv_{{$parent->id}}" name="niv" value="{{ $parent->niv }}">
              <input type="hidden" id="text_{{$parent->id}}" name="text" value="{{ $parent->text }}">
              <input type="hidden" id="parent_{{$parent->id}}" name="parent" value="{{ $parent->parent }}">
              <input type="hidden" id="ordre_{{$parent->id}}" name="ordre" value="{{ $parent->ordre }}">
              <input type="hidden" id="tpl_{{$parent->id}}" name="template_id" value="{{ $parent->id_template }}">
              <input type="hidden" id="id_parent_tpl_{{$parent->id}}" name="template_id" value="{{$parent->id}}">                   
              <textarea id="text_statFirsNiv_{{ $parent->id }}" name="text_stat" class="form-control mceEditor" rows="4" >{{ $parent->text_stat }}</textarea>
              <br>
              @foreach ($first_nivs as $first_niv)
              @if($first_niv->parent == $parent->id && $first_niv->niv == 1)
              <div class="accordion_{{$parent->id}}_{{$first_niv->ordre}}" id="accordion_{{$parent->id}}_{{$first_niv->ordre}}" role="tablist" aria-multiselectable="true"><br>
                <div class="panel" style="border-top:2px solid lightblue;">
                  <div class="panel-heading">
                    <a role="tab" id="heading_{{$parent->id}}_{{$first_niv->ordre}}" data-toggle="collapse" data-parent="#accordion_{{$parent->id}}_{{$first_niv->ordre}}" href="#collapse_{{$parent->id}}_{{$first_niv->ordre}}" aria-expanded="true" aria-controls="collapseOne">           
                      <h4 class="panel-title">                      
                       <span class="label label-info">{{ $first_niv->num_parag }}</span> <span id="title_{{ $first_niv->id }}">{{ $first_niv->text }}</span>
                      </a>
                      <span class="right">
                      <?php
                        if (!empty($first_niv->modified)) {
                          echo '<i class="btn btn-success btn-xs fa fa-check" data-toggle="tooltip" data-placement="top"
                          data-original-title="Cette partie a été modifié"></i>';
                        } else {
                          echo '<i class="btn btn-danger btn-xs fa fa-exclamation" data-toggle="tooltip" data-placement="top"
                          data-original-title="Cette partie n\'a pas été modifié"></i>';
                        }
                      ?>
                        <span id="loader_{{ $first_niv->id }}"></span>
                      <button type="button" class="btn btn-warning btn-xs"
                      onclick="addParagraphApp({{ $first_niv->id }});"><i class="fa fa-save"></i> Valider le contenu</button>
                    </span>
                  </h4>
                </div>
                <div id="collapse_{{$parent->id}}_{{$first_niv->ordre}}" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading_{{$parent->id}}_{{$first_niv->ordre}}">
                  <div class="panel-body">
                    <label>Partie fixe :</label><br>
                    <input type="hidden" name="version" value="{{ $tpl->version }}">
                    <input type="hidden" name="module" value="tpl"> 
                    <input type="hidden" id="num_parag_{{$first_niv->id}}" name="num_parag" value="{{ $first_niv->num_parag }}">
                    <input type="hidden" id="niv_{{$first_niv->id}}" name="niv" value="{{ $first_niv->niv }}">
                    <input type="hidden" id="text_{{$first_niv->id}}" name="text" value="{{ $first_niv->text }}">
                    <input type="hidden" id="parent_{{$first_niv->id}}" name="parent" value="{{ $first_niv->parent }}">
                    <input type="hidden" id="ordre_{{$first_niv->id}}" name="ordre" value="{{ $first_niv->ordre }}">
                    <input type="hidden" id="tpl_{{$first_niv->id}}" name="template_id" value="{{ $first_niv->id_template }}">
                    <input type="hidden" id="id_parent_tpl_{{$first_niv->id}}" name="template_id" value="{{$first_niv->id}}">
                          <textarea class="mceEditor form-control" rows="4" {{$readonly}} id="text_statFirsNiv_{{ $first_niv->id }}">{{ $first_niv->text_stat }}</textarea>
                    <br>                        
                    @foreach ($second_nivs as $second_niv)
                    @if($second_niv->parent == $first_niv->id && $second_niv->niv == 2)
                    <div class="accordion_{{$first_niv->id}}_{{$second_niv->ordre}}" id="accordion_{{$first_niv->id}}_{{$second_niv->ordre}}" role="tablist" aria-multiselectable="true"><br>
                      <div class="panel" style="border-top:2px solid lightblue;">
                        <div class="panel-heading">
                          <a role="tab" id="heading_{{$first_niv->id}}_{{$second_niv->ordre}}" data-toggle="collapse" data-parent="#accordion_{{$first_niv->id}}_{{$second_niv->ordre}}" href="#collapse_{{$first_niv->id}}_{{$second_niv->ordre}}" aria-expanded="true" aria-controls="collapseOne">
                            <h4 class="panel-title">                              
                              <span class="label label-warning">{{ $second_niv->num_parag }}</span>
                              <span id="title_{{ $second_niv->id }}">{{ $second_niv->text }}</span>
                            </a>
                            <span class="right">
                              <?php
                                if (!empty($second_niv->modified)) {
                                  echo '<i class="btn btn-success btn-xs fa fa-check" data-toggle="tooltip" data-placement="top"
                                  data-original-title="Cette partie a été modifié"></i>';
                                } else {
                                  echo '<i class="btn btn-danger btn-xs fa fa-exclamation" data-toggle="tooltip" data-placement="top"
                                  data-original-title="Cette partie n\'a pas été modifié"></i>';
                                }
                              ?>
                              <span id="loader_{{ $second_niv->id }}"></span>
                              <button type="button" class="btn btn-warning btn-xs" 
                              onclick="addParagraphApp({{ $second_niv->id }});"><i class="fa fa-save"></i> Valider le contenu</button>                              
                            </span>
                          </h4>
                        </div>
                        <div id="collapse_{{$first_niv->id}}_{{$second_niv->ordre}}" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading_{{$first_niv->id}}_{{$second_niv->ordre}}">
                          <div class="panel-body">
                            <label>Partie fixe :</label><br>
                            <input type="hidden" name="version" value="{{ $tpl->version }}">
                            <input type="hidden" name="module" value="tpl"> 
                            <input type="hidden" id="num_parag_{{$second_niv->id}}" name="num_parag" value="{{ $second_niv->num_parag }}">
                            <input type="hidden" id="niv_{{$second_niv->id}}" name="niv" value="{{ $second_niv->niv }}">
                            <input type="hidden" id="text_{{$second_niv->id}}" name="text" value="{{ $second_niv->text }}">
                            <input type="hidden" id="parent_{{$second_niv->id}}" name="parent" value="{{ $second_niv->parent }}">
                            <input type="hidden" id="ordre_{{$second_niv->id}}" name="ordre" value="{{ $second_niv->ordre }}">
                            <input type="hidden" id="tpl_{{$second_niv->id}}" name="template_id" value="{{ $second_niv->id_template }}">
                            <input type="hidden" id="id_parent_tpl_{{$second_niv->id}}" name="template_id" value="{{$second_niv->id}}">
                            <textarea class="mceEditor form-control" rows="4" {{$readonly}} id="text_statFirsNiv_{{ $second_niv->id }}">{{ $second_niv->text_stat }}</textarea><br>
                          </div>
                        </div>
                      </div>                    
                    </div>
                  </form>
                  @endif
                  @endforeach
                </div>
              </div>
            </div>                    
          </div>
          @endif
          @endforeach
        </div>
      </div>
    </div>
    @endforeach
  </div>
</div>
</div>
@section('js')
@endsection
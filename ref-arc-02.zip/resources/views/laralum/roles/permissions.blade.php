@extends('layouts.admin.panel')
@section('breadcrumb')
<div class="ui breadcrumb">
    <i class="fa fa-cogs"></i>
    <a class="section" href="{{ route('Laralum::projects') }}">{{ trans('laralum.roles_title') }}</a>
    / <strong>{{ trans('laralum.roles_edit_permissions_title') }}</strong>
</div>
@endsection
@section('title', trans('laralum.roles_edit_permissions_title'))
@section('icon', "lightning")
@section('subtitle', trans('laralum.roles_edit_permissions_subtitle', ['name' => $role->name]))
@section('content')
<div class="clearfix"></div>
<div class="row">
<form id="add_project" class="form-horizontal form-label-left" novalidate="" method="POST">
    <!-- Start to do list -->
    <?php $found = false; ?>
    <div class="col-md-6 col-sm-6 col-xs-12">    
      <div class="x_panel">
        <div class="x_title">
          <h2>Utilisateurs / Roles / Permission</h2>
            <ul class="nav navbar-right panel_toolbox">
                <li>
                <a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                </li>
            </ul>
    <div class="clearfix"></div>
</div>
<div class="x_content">
  <div class="">
    <ul class="to_do">
        <?php $counter = 0; ?>
        @foreach($permissions as $perm)
            <?php
            $tabUser = ['user', 'users', 'roles'];
            $per = explode('.', $perm);
             if (in_array($per[1], $tabUser)) {
                if ($per[2] == 'delete') {
                    continue;
                }
            ?>
            <li>
                <p>
                  <input type="checkbox" class="js-switch"<?php
                                    $disabled = false;
                                    if(isset($role)){
                                        if($role->hasPermission($perm->slug)) {
                                            echo "checked='checked' ";
                                        }

                                        if($role->su) {
                                            if($perm->su) {
                                                $disabled = true;
                                            }
                                        }
                                    }
                                    if(!$disabled and (!$perm->assignable and !Laralum::loggedInUser()->su)){
                                        $disabled = true;
                                    }
                                    if($disabled) {
                                        echo "disabled ";
                                    }
                                ?>
                                name="{{ $perm->id }}" type="checkbox"  tabindex="0" class="@if(!$disabled) checkable @endif hidden"> {{ Laralum::permissionName($perm->slug) }}
                                <i class="fa fa-question" data-toggle="tooltip" data-placement="right" title="{{ Laralum::permissionDescription($perm->slug) }}" data-original-title=""></i>
                                @if(!$perm->assignable and !Laralum::loggedInUser()->su)<i data-variation="wide" class="red lock icon pop" data-position="right center" data-title="{{ trans('laralum.unassignable_permission') }}" data-content="{{ trans('laralum.unassignable_permission_desc') }}"></i>@endif
                                @if(!$perm->assignable and Laralum::loggedInUser()->su and !$disabled)<i data-variation="wide" class="red unlock icon pop" data-position="right center" data-title="{{ trans('laralum.unassignable_permission_unlocked') }}" data-content="{{ trans('laralum.unassignable_permission_unlocked_desc') }}"></i>@endif
                                @if(Laralum::loggedInUser()->su and $disabled)<i class="fa fa-lock" data-toggle="tooltip" data-placement="right" title="{{ trans('laralum.su_permission_and_role_desc') }}" data-content="{{ trans('laralum.su_permission_and_role_desc') }}"></i>@endif
                </p>
            </li>
            <?php } ?>
        @endforeach
  </ul>
</div>
</div>
</div>
</div>
<!-- End to do list -->
<!-- Start to do list -->
<div class="col-md-6 col-sm-6 col-xs-12">
  <div class="x_panel">
    <div class="x_title">
    <h2>Projets / DAH</h2>
      <ul class="nav navbar-right panel_toolbox">
        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
        </li>        
</ul>
<div class="clearfix"></div>
</div>
<div class="x_content">

  <div class="">
    <ul class="to_do">
        <?php $counter = 0; ?>
        @foreach($permissions as $perm)
            <?php
            $per = explode('.', $perm);
             if ($per[1] == 'projects') {
                if ($per[2] == 'delete') {
                    continue;
                }
            ?>
            <li>
                <p>
                  <input type="checkbox" class="js-switch"<?php
                                    $disabled = false;
                                    if(isset($role)){
                                        if($role->hasPermission($perm->slug)) {
                                            echo "checked='checked' ";
                                        }

                                        if($role->su) {
                                            if($perm->su) {
                                                $disabled = true;
                                            }
                                        }
                                    }
                                    if(!$disabled and (!$perm->assignable and !Laralum::loggedInUser()->su)){
                                        $disabled = true;
                                    }
                                    if($disabled) {
                                        echo "disabled ";
                                    }
                                ?>
                                name="{{ $perm->id }}" type="checkbox"  tabindex="0" class="@if(!$disabled) checkable @endif hidden"> {{ Laralum::permissionName($perm->slug) }}
                                <i class="fa fa-question" data-toggle="tooltip" data-placement="right" title="{{ Laralum::permissionDescription($perm->slug) }}" data-original-title=""></i>
                                @if(!$perm->assignable and !Laralum::loggedInUser()->su)<i data-variation="wide" class="red lock icon pop" data-position="right center" data-title="{{ trans('laralum.unassignable_permission') }}" data-content="{{ trans('laralum.unassignable_permission_desc') }}"></i>@endif
                                @if(!$perm->assignable and Laralum::loggedInUser()->su and !$disabled)<i data-variation="wide" class="red unlock icon pop" data-position="right center" data-title="{{ trans('laralum.unassignable_permission_unlocked') }}" data-content="{{ trans('laralum.unassignable_permission_unlocked_desc') }}"></i>@endif
                                @if(Laralum::loggedInUser()->su and $disabled)<i class="fa fa-lock" data-toggle="tooltip" data-placement="right" title="{{ trans('laralum.su_permission_and_role_desc') }}" data-content="{{ trans('laralum.su_permission_and_role_desc') }}"></i>@endif
                </p>
            </li>
            <?php } ?>
        @endforeach
  </ul>
</div>
</div>
</div>
</div>
<!-- End to do list -->
<!-- Start to do list -->
<div class="col-md-6 col-sm-6 col-xs-12">
  <div class="x_panel">
    <div class="x_title">
      <h2>Templates</h2>
      <ul class="nav navbar-right panel_toolbox">
        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
        </li>
        </ul>
<div class="clearfix"></div>
</div>
<div class="x_content">
  <div class="">
    <ul class="to_do">
        <?php $counter = 0; ?>
        @foreach($permissions as $perm)
            <?php
            $per = explode('.', $perm);
             if ($per[1] == 'templates') {
                if ($per[2] == 'delete') {
                    continue;
                }
            ?>
            <li>
                <p>
                  <input type="checkbox" class="js-switch"<?php
                                    $disabled = false;
                                    if(isset($role)){
                                        if($role->hasPermission($perm->slug)) {
                                            echo "checked='checked' ";
                                        }

                                        if($role->su) {
                                            if($perm->su) {
                                                $disabled = true;
                                            }
                                        }
                                    }
                                    if(!$disabled and (!$perm->assignable and !Laralum::loggedInUser()->su)){
                                        $disabled = true;
                                    }
                                    if($disabled) {
                                        echo "disabled ";
                                    }
                                ?>
                                name="{{ $perm->id }}" type="checkbox"  tabindex="0" class="@if(!$disabled) checkable @endif hidden"> {{ Laralum::permissionName($perm->slug) }}
                                <i class="fa fa-question" data-toggle="tooltip" data-placement="right" title="{{ Laralum::permissionDescription($perm->slug) }}" data-original-title=""></i>
                                @if(!$perm->assignable and !Laralum::loggedInUser()->su)<i data-variation="wide" class="red lock icon pop" data-position="right center" data-title="{{ trans('laralum.unassignable_permission') }}" data-content="{{ trans('laralum.unassignable_permission_desc') }}"></i>@endif
                                @if(!$perm->assignable and Laralum::loggedInUser()->su and !$disabled)<i data-variation="wide" class="red unlock icon pop" data-position="right center" data-title="{{ trans('laralum.unassignable_permission_unlocked') }}" data-content="{{ trans('laralum.unassignable_permission_unlocked_desc') }}"></i>@endif
                                @if(Laralum::loggedInUser()->su and $disabled)<i class="fa fa-lock" data-toggle="tooltip" data-placement="right" title="{{ trans('laralum.su_permission_and_role_desc') }}" data-content="{{ trans('laralum.su_permission_and_role_desc') }}"></i>@endif
                </p>
            </li>
            <?php } ?>
        @endforeach
  </ul>
</div>
</div>
</div>
</div>
<!-- End to do list -->
<!-- Start to do list -->
<div class="col-md-6 col-sm-6 col-xs-12">
  <div class="x_panel">
    <div class="x_title">
      <h2>Applications</h2>
      <ul class="nav navbar-right panel_toolbox">
        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
        </li>        
</ul>
<div class="clearfix"></div>
</div>
<div class="x_content">

  <div class="">
    <ul class="to_do">
        <?php $counter = 0; ?>
        @foreach($permissions as $perm)
            <?php
            $per = explode('.', $perm);
             if ($per[1] == 'applications') {
                if ($per[2] == 'delete') {
                    continue;
                }
            ?>
            <li>
                <p>
                  <input type="checkbox" class="js-switch"<?php
                                    $disabled = false;
                                    if(isset($role)){
                                        if($role->hasPermission($perm->slug)) {
                                            echo "checked='checked' ";
                                        }

                                        if($role->su) {
                                            if($perm->su) {
                                                $disabled = true;
                                            }
                                        }
                                    }
                                    if(!$disabled and (!$perm->assignable and !Laralum::loggedInUser()->su)){
                                        $disabled = true;
                                    }
                                    if($disabled) {
                                        echo "disabled ";
                                    }
                                ?>
                                name="{{ $perm->id }}" type="checkbox"  tabindex="0" class="@if(!$disabled) checkable @endif hidden"> {{ Laralum::permissionName($perm->slug) }}
                                <i class="fa fa-question" data-toggle="tooltip" data-placement="right" title="{{ Laralum::permissionDescription($perm->slug) }}" data-original-title=""></i>
                                @if(!$perm->assignable and !Laralum::loggedInUser()->su)<i data-variation="wide" class="red lock icon pop" data-position="right center" data-title="{{ trans('laralum.unassignable_permission') }}" data-content="{{ trans('laralum.unassignable_permission_desc') }}"></i>@endif
                                @if(!$perm->assignable and Laralum::loggedInUser()->su and !$disabled)<i data-variation="wide" class="red unlock icon pop" data-position="right center" data-title="{{ trans('laralum.unassignable_permission_unlocked') }}" data-content="{{ trans('laralum.unassignable_permission_unlocked_desc') }}"></i>@endif
                                @if(Laralum::loggedInUser()->su and $disabled)<i class="fa fa-lock" data-toggle="tooltip" data-placement="right" title="{{ trans('laralum.su_permission_and_role_desc') }}" data-content="{{ trans('laralum.su_permission_and_role_desc') }}"></i>@endif
                </p>
            </li>
            <?php } ?>
        @endforeach
  </ul>
</div>
</div>
</div>
</div>
<!-- End to do list -->
<div class="col-md-9 col-md-offset-9">
        {{ csrf_field() }}
        <a href="{{ route('Laralum::roles') }}"><button type="button" class="btn btn-primary">Liste des roles</button></a>
        <button type="submit" class="btn btn-success">Valider</button>
    </div>
</form>
</div>
@endsection

@extends('layouts.admin.panel')
@section('breadcrumb')
<div class="ui breadcrumb">
  <div class="active section"><i class="fa fa-list"></i> {{ trans('laralum.permissions_title') }}</div>
</div>
@endsection
@section('title', trans('laralum.permissions_title'))
@section('icon', "lightning")
@section('subtitle', trans('laralum.permissions_subtitle'))
@section('content')
<div class="row"> 

  <div class="col-md-12 col-sm-12 col-xs-12">
    <div class="x_panel">
      <div class="x_content">                    
        <table id="datatable-buttons" class="table table-striped table-bordered">
          <thead>
            <tr>
              <th>{{ trans('laralum.name') }}</th>
              <th>{{ trans('laralum.description') }}</th>
              <th>{{ trans('laralum.slug') }}</th>
              <th>{{ trans('laralum.roles') }}</th>
            </tr>
          </thead>
          <tbody>
            @foreach($permissions as $perm)
            <tr>
              <td>
                <div class="text">
                  {{ Laralum::permissionName($perm->slug) }}
                </div>          
              </td>
              <td>
                <div class="text">
                  {{ Laralum::permissionDescription($perm->slug) }}
                </div>
              </td>
              <td>
                <div class="text">
                  {{ $perm->slug }}
                </div>
              </td>              
              <td>
                {{ trans('laralum.permissions_roles', ['number' => count($perm->roles)]) }}
              </td>
            </tr>
            @endforeach
          </tbody>
        </table>
      </div>
    </div>
  </div>
  @endsection
  @section('js')
  <script type="text/javascript">
    $(document).ready(function() {
      var handleDataTableButtons = function() {
        if ($("#datatable-buttons").length) {
          $("#datatable-buttons").DataTable({
            dom: "Bfrtip",
            buttons: [
            {
              extend: "copy",
              className: "btn-sm"
            },
            {
              extend: "csv",
              className: "btn-sm"
            },
            {
              extend: "excel",
              className: "btn-sm"
            },
            {
              extend: "pdfHtml5",
              className: "btn-sm"
            },
            {
              extend: "print",
              className: "btn-sm"
            },
            ],
            
          });
        }
      };

      TableManageButtons = function() {
        "use strict";
        return {
          init: function() {
            handleDataTableButtons();
          }
        };
      }();


      $('#datatable-responsive').DataTable();        

      TableManageButtons.init(); 

      // Supprime les boutons d'export et le champ rechercher
      $("#datatable-buttons_filter").css("display","none");
      $(".dt-buttons").css("display","none");

    });       
  </script>
  @endsection
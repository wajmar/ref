<div class="col-md-12">
  <div class="row">
    <div class="col-xs-12">

      <div class="">
        <div style="text-align:center;font-size:22px;margin-top:10px;margin-bottom:15px;">Progression</div>
        <div class="progress">
          <div class="progress-bar progress-bar-danger progress-bar-striped" role="progressbar" aria-valuenow="12.5" aria-valuemin="0" aria-valuemax="100" style="width:10%">
          </div>
        </div>
        <div class="box-body no-padding">
          <div id="wizard">
            @foreach($parents as $parent)
            <?php           
            $exp = explode('.', $parent->num_parag);
            $readonly = '';
            if (!Laralum::loggedInUser()->su) {
              $readonly = 'Readonly';
            }
            ?>
            <h2 style="background-color:rgb(216,83,79)">{{ $parent->text }}</h2>
            <section style="position:relative">
              <!--<button type="button" class="btn btn-success"><i class="fa fa-plus"></i> Ajouter composant</button>-->
              <div class="box-group" id="accordion">
                <div class="panel">
                  <div class="box-header with-border">
                    <h4 class="box-title">
                      <a role="tab" id="heading_{{ $parent->ordre }}" data-toggle="collapse" data-parent="#accordion"
                      href="#collapse_{{ $parent->ordre }}" aria-expanded="true" aria-controls="collapseOne">
                      
                      <textarea class="aria_title_{{ $parent->id }} form-control" rows="4" {{$readonly}} id="text_statParent_{{ $parent->id }}">{{ $parent->text_stat }}</textarea>
                      <!--<div class="tt"><p>{{ htmlspecialchars($parent->text_stat) }} </p></div>-->
                      </a>
                    </h4>
                  </div>
                  <div id="collapseOne" class="panel-collapse collapse">
                    <div class="box-body">
                      <!-- Content -->
                      <div class="box-body">                      

                        
                      </div>
                    </div>
                  </div>
                  @foreach($first_nivs as $first_niv)
                  <?php if ($first_niv->parent == $parent->id) { ?>
                  <div class="box-header with-border">
                    <h4 class="box-title">
                      <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne">
                        {{ $first_niv->text }}
                      </a>
                    </h4>
                  </div>
                  <div id="collapseOne" class="panel-collapse collapse">
                    <div class="box-body">
                      <!-- Content -->
                      <div class="box-body">                      

                        
                      </div>
                    </div>
                  </div>
                  <?php } ?>
                  @endforeach
                </div>
              </div>
            </section>
            @endforeach
          </div>
          
        </div>
      </div>
    </div>
  </div>
</div>

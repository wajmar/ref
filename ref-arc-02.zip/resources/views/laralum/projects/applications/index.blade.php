<?php use App\User; ?>
@extends('layouts.admin.panel')
@section('breadcrumb')
<div class="ui breadcrumb">
  <i class="fa fa-edit"></i>
  <a class="section" href="{{ route('Laralum::projects') }}">{{ trans('laralum.projects_list') }}</a>
  / {{ $nameProj }}
</div>
@endsection
@section('title', trans('laralum.projects_edit'))
@section('icon', "book")
@section('subtitle', trans('laralum.projects_edit'))
@section('content')
<div class="row">
  <div class="col-md-12">
    <div class="x_panel">
      <?php
      $text = '';
      $disabled = false;
      $nameEditor = '';
      $stat = '';
      if (is_null($appsParams->active_edit)) {
        $class = 'alert alert-success alert-dismissible fade in';
        $classBtn = 'btn btn-success';
        $text = 'La modification de DAH.';
        $disabled = '';
        $txtBtn = 'Modifier';
        $icon = 'fa-pencil';
        $stat = 'activepossible';
      } elseif ($appsParams->active_edit === Laralum::loggedInUser()->id) {
        $class = 'alert alert-danger alert-dismissible fade in';
        $text = User::find($appsParams->active_edit)->name.' Modification en cour.';
        $classBtn = 'btn btn-danger';
        $disabled = '';
        $txtBtn = 'Terminer la modification';
        $icon = 'fa-refresh';
        $stat = 'active';
      } else {
        $class = 'alert alert-info alert-dismissible fade in';
        if (!empty(User::find($appsParams->active_edit)->name)) {
          $nameEditor = User::find($appsParams->active_edit)->name; }
          $text = $nameEditor.' En train de modifier le DAH.';
          $classBtn = 'btn btn-info';
          $disabled = 'disabled';
          $txtBtn = 'Modification indisponible';
          $icon = 'fa-exclamation';
          $stat = 'nonactive';
        }
        ?>
        @if(Laralum::loggedInUser()->hasPermission('refarc.applications.edit'))
        <form id="activ_edit" method="POST">
          <div id="warningEdit" class="{{ $class }}" role="alert">
            <button id="activeEdit" style="margin-top: -6px;" type="button" class="pull-right {{ $classBtn }}"
            ><i class="fa {{ $icon }}"></i> <b>{{ $txtBtn }}</b>
          </button>
          <input type="hidden" name="editor" id="editorstat" value="{{ $stat }}">
          {{ csrf_field() }}
          <strong>{{ $text }}</strong>  <i class="fa fa-question" data-toggle="tooltip" data-placement="right" title="l'activation de modification bloque les autres utilisateurs" data-original-title=""></i>      
        </div>
      </form>
      @endif
      <div class="x_content">
        <div class="" role="tabpanel" data-example-id="togglable-tabs">
          <ul id="myTab" class="nav nav-tabs bar_tabs" role="tablist">
            <li role="presentation" class="active"><a href="#tab_content1" id="profil" role="tab" data-toggle="tab" aria-expanded="true">Profil</a>
            </li>
            <li role="presentation"><a href="#tab_content2" id="dah" role="tab" data-toggle="tab" aria-expanded="false">DAH</a>
            </li>
            <li role="presentation" class=""><a href="#tab_content3" role="tab" id="hist" data-toggle="tab" aria-expanded="false">Historique</a>
            </li>
          </ul>
          <div id="myTabContent" class="tab-content">
            <div role="tabpanel" class="tab-pane fade active in" id="tab_content1" aria-labelledby="home-tab">
              <div class="row">
              </div>
              <section class="col-md-3">
                <div class="x_panel">
                  <div class="x_title" style="text-align:center;"><h3 id="app_name" class="red">{{ $applications->name }}</h3></div>
                  <div class="x_content">
                    <label class="red">Ecolience :</label><br>
                    <p style="font-style:italic;"" id="app_ecolience">
                      {{ $applications->ecolience }}
                    </p>
                    <label class="red">Créateur :</label><br>
                    <span><a href="{{ route('Laralum::users_profile', ['id' => $applications->user_id]) }}">
                     <i class="fa fa-user"></i> {{ User::find($applications->user_id)->name }}</a></span><br><br>
                     <label class="red">Date de creation :</label><br>
                     <span>{{ date('d F Y', strtotime($applications->created_at)) }}</span><br><br>
                     <label class="red">Date de dernière mise a jour :</label><br>
                     <span>{{ date('d F Y', strtotime($applications->updated_at)) }}</span><br><br>
                     <label class="red">IRT :</label><br>
                     <span id="app_irt">{{ $applications->irt }}</span><br><br>
                     <label class="red">Trigramme :</label><br>
                     <span id="app_trigramme">{{ $applications->trigramme }}</span><br><br>
                     <label class="red">Criticité STAMP :</label><br>
                     <span id="app_criticite_stamp">{{ $applications->criticite_stamp }}</span><br><br>
                     <label class="red">Sensible Groupe :</label><br>
                     <span id="app_sensible_groupe">
                      @if($applications->sensible_groupe == 1)
                      Oui
                      @else
                      Non
                      @endif
                    </span><br><br>
                    <label class="red">Demande Client :</label><br>
                    <span id="app_demande_client">{{ $applications->demande_client }}</span><br><br>
                    <label class="red">Version :</label><br>
                    <span>{{ $applications->version }}</span><br><br>
                    <label class="red">Statut :</label><br>
                    <span>{{ $applications->statu }}</span><br><br>
                    <label class="red">Niveau sensibilité fraude :</label><br>
                    <span id="app_niv_sensible_fraude">{{ $applications->niv_sensible_fraude }}</span>
                    <input type="hidden" name="" id="idApps" value="{{ $applications->id }}">
                    <br><br>
                    <div class="ln_solid"></div>
                    @if(Laralum::loggedInUser()->hasPermission('refarc.applications.edit'))
                    <div style="text-align: center"><button type="button" style="display:none;" id="editPrfl" class="btn btn-warning" data-toggle="modal" data-target=".modaleditapp"><i class="fa fa-pencil"></i> Modifier</button></div>
                    @endif
                    <div id="modal_app" class="modal fade modaleditapp" tabindex="-1" role="dialog" aria-hidden="true">
                     <div class="modal-dialog modal-lg">
                       <div class="modal-content">
                         <div class="modal-header" style="text-align: center">
                           <div class="modal-title">Modification application</div>
                           <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">X</span></button>
                         </div>
                         <div class="modal-body">
                           <form id="edit_app" data-parsley-validate="" class="form-horizontal form-label-left" novalidate="" method="POST">
                            <div class="form-group">
                              <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Nom <span class="required">*</span>
                              </label>
                              <div class="col-md-6 col-sm-6 col-xs-12">
                                <input id="name" name="name" required="required" class="form-control col-md-7 col-xs-12" type="text" value="{{ ucfirst($applications->name) }}">
                              </div>
                            </div>
                            <div class="form-group">
                              <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Ecolience
                              </label>
                              <div class="col-md-6 col-sm-6 col-xs-12">
                                <input id="name" name="ecolience" class="form-control col-md-7 col-xs-12" type="text" value="{{ $applications->ecolience }}">
                              </div>
                            </div>
                            <div class="form-group">
                              <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">IRT 
                              </label>
                              <div class="col-md-6 col-sm-6 col-xs-12">
                                <input id="name" name="irt" class="form-control col-md-7 col-xs-12" type="text" value="{{ $applications->irt }}">
                              </div>
                            </div>
                            <div class="form-group">
                              <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Trigramme 
                              </label>
                              <div class="col-md-6 col-sm-6 col-xs-12">
                                <input id="name" name="trigramme" class="form-control col-md-7 col-xs-12" type="text" value="{{ $applications->trigramme }}">
                              </div>
                            </div>
                            <div class="form-group">
                              <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Criticité STAMP 
                              </label>
                              <div class="col-md-6 col-sm-6 col-xs-12">
                                <select id="name" name="criticite_stamp" class="form-control col-md-7 col-xs-12" type="text" value="{{ $applications->criticite_stamp }}">
                                  <option value="Non prioritaire" <?php if ("Non prioritaire" ==  $applications->criticite_stamp) echo "selected";?>>Non prioritaire</option>
                                  <option value="Secondaire" <?php if ("Secondaire" ==  $applications->criticite_stamp) echo "selected";?>>Secondaire</option>
                                  <option value="Critique" <?php if ("Critique" ==  $applications->criticite_stamp) echo "selected";?>>Critique</option>
                                  <option value="Vitale" <?php if ("Vitale" ==  $applications->criticite_stamp) echo "selected";?>>Vitale</option>
                                </select>
                              </div>
                            </div>
                            <div class="form-group">
                              <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Sensible groupe 
                              </label>
                              <div class="col-md-6 col-sm-6 col-xs-12">
                                <input id="name" name="sensible_groupe" class="form-control col-md-7 col-xs-12" type="text" value="{{ $applications->sensible_groupe }}">
                              </div>
                            </div>
                            <div class="form-group">
                              <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Niveau de sensibilité fraude 
                              </label>
                              <div class="col-md-6 col-sm-6 col-xs-12">
                                <input id="name" name="niv_sensible_fraude" class="form-control col-md-7 col-xs-12" type="text" value="{{ $applications->niv_sensible_fraude }}">
                              </div>
                            </div>
                            <div class="form-group">
                              <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">demande client 
                              </label>
                              <div class="col-md-6 col-sm-6 col-xs-12">
                                <textarea  name="demande_client" class="form-control" rows="3" style="width: 414px; height: 91px;">{{ $applications->demande_client }}</textarea>
                              </div>
                            </div>
                            <input type="hidden" name="_token" value="<?php echo csrf_token() ?>">
                          </div>
                          <div class="modal-footer">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>
                            <button id="updateapp" type="button" class="btn btn-primary">Modifier</button>
                          </div>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
              </section>
              <div class="col-md-9 col-sm-9 col-xs-9">
                <div class="x_panel">
                  <div class="x_content">
                    <div class="" role="tabpanel" data-example-id="togglable-tabs2">
                      <ul id="myTab2" class="nav nav-tabs bar_tabs" role="tablist">
                        <li role="presentation" class="active"><a href="#tab_content4" id="home-tab" role="tab" data-toggle="tab" aria-expanded="false">Liste des intervenants</a>
                        </li>
                        <li role="presentation" class=""><a href="#tab_content5" role="tab" id="profile-tab" data-toggle="tab" aria-expanded="false">Liste de diffusion</a>
                        </li>
                      </ul>
                      <div id="myTabContent" class="tab-content">
                        <div role="tabpanel" class="tab-pane fade active in" id="tab_content4" aria-labelledby="home-tab">
                          <div class="row">
                            <button type="button" class="btn btn-success pull-right" data-toggle="modal" data-target=".modal_add_interv"><i class="fa fa-plus"></i> Ajouter</button>
                          </div><br>
                          <table id="table_interv" class="table table-bordered">
                            <thead>
                              <tr>
                                <th>Entite</th>
                                <th>Domaine de responsabilite</th>
                                <th>Nom Prenom</th>
                              </tr>
                            </thead>
                            <tbody>
                              @foreach($intervenants as $intervenant)
                              <tr>
                                <td>{{ $intervenant->entite }}</td>
                                <td>{{ $intervenant->resp_domain }}</td>
                                <td>{{ $intervenant->nom }}</td>
                              </tr>
                              @endforeach
                            </tbody>
                          </table>
                        </div>
                        <div role="tabpanel" class="tab-pane fade" id="tab_content5" aria-labelledby="profile-tab">
                          <div class="row">
                            <button type="button" class="btn btn-success pull-right" data-toggle="modal" data-target=".modal_add_diff"><i class="fa fa-plus"></i> Ajouter</button>
                          </div><br>
                          <table id="table_diff" class="table table-bordered">
                            <thead>
                              <tr>
                                <th>Entite</th>
                                <th>Nom du destinataire</th>
                                <th>Objet</th>
                              </tr>
                            </thead>
                            <tbody>
                              @foreach($diffusion as $diff)
                              <tr>
                                <td>{{ $diff->entite }}</td>
                                <td>{{ ucfirst($diff->nom) }}</td>
                                <td>{{ ucfirst($diff->objet) }}</td>
                              </tr>
                              @endforeach
                            </tbody>
                          </table> 
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- MODAL AJOUT INTERVENANT -->
            <div class="modal fade modal_add_interv" tabindex="-1" role="dialog" aria-hidden="true">
              <div class="modal-dialog modal-lg">
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
                    </button>
                    <h4 class="modal-title" id="myModalLabel" style="text-align:center">Ajout d'un intervenant</h4>
                    <div id="div_loader" style="text-align:center;height:30px;">
                      <img src="{{ asset('images/loader.gif') }}" id="loader" style="height:30px;display:none" >
                    </div>
                  </div>
                  <div class="modal-body">
                    <form id="form_interv">
                      {{ csrf_field() }}
                      <label class="control-label" for="name_interv">Nom :</label><br>
                      <input type="text" id="name_interv" name="name_interv" class="form-control col-md-10" autocomplete="off" required/>
                      <label for="email_interv">Email :</label>
                      <input type="text" id="email_interv" class="form-control" name="email" autocomplete="off" required>
                      <label for="entite_interv">Entite/Service :</label>
                      <input type="text" id="entite_interv" class="form-control" name="entite" autocomplete="off" required>
                      <label for="resp_domain_interv">Domaine de responsabilite :</label>
                      <input type="text" id="resp_domain_interv" class="form-control" name="resp_domain" autocomplete="off" required><br>
                      <div class="pull-right">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>
                        <button id="add_interv_btn" type="button" class="btn btn-success">Ajouter</button>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
            <!-- MODAL AJOUT DIFFUSION -->
            <div class="modal fade modal_add_diff" tabindex="-1" role="dialog" aria-hidden="true">
              <div class="modal-dialog modal-lg">
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
                    </button>
                    <h4 class="modal-title" id="myModalLabel" style="text-align:center">Ajout d'une diffusion</h4>
                    <div id="div_loader" style="text-align:center;height:30px;">
                      <img src="{{ asset('images/loader.gif') }}" id="loader_diff" style="height:30px;display:none">
                    </div>
                  </div>
                  <div class="modal-body">
                    <form id="form_diff">
                      {{ csrf_field() }}
                      <label class="control-label" for="name_diff">Nom :</label><br>
                      <input type="text" id="name_diff" name="name" class="form-control col-md-10" autocomplete="off" required/>
                      <label for="entite_diff">Entite/Service :</label>
                      <input type="text" id="entite_diff" class="form-control" name="entite" autocomplete="off" required>
                      <label for="objet_diff">Objet de la diffusion :</label>
                      <select id="objet_diff" name="objet" class="form-control" autocomplete="off" required>
                        <option>diffusion</option>
                        <option>validation</option>
                      </select>
                      <br>
                      <div class="pull-right">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>
                        <button id="add_diff_btn" type="button" class="btn btn-success">Ajouter</button>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
            <div role="tabpanel" class="tab-pane fade" id="tab_content2" aria-labelledby="profile-tab">
            </div>
            <div role="tabpanel" class="tab-pane fade" id="tab_content3" aria-labelledby="profile-tab">
              <div class="col-md-12">
                <div class="row" style="text-align:center">
                  <label style="font-size:24px">Historique</label>
                </div>
                <ul class="list-unstyled timeline">
                  @foreach($history as $hist)
                  <li>
                    <div class="block">
                      <div class="tags">
                        <a href="" class="tag">
                          <span>{{ date('d/m/Y', strtotime($hist->updated_at)) }}</span>
                        </a>
                      </div>
                      <div class="block_content">
                        <h2 class="title">                     
                          Modification
                        </h2>
                        <div class="byline">
                          <span>{{ date('d/m/Y m:s', strtotime($hist->updated_at)) }}</span> par <a class="red"><b>{{ ucfirst(User::find($hist->user_id)->name) }}</b></a>
                        </div>
                        <p class="excerpt">
                          @if($hist->namefield == 'name')
                          <a>Le nom de l'application "<i class="red">{{ $hist->old_value }}</i>" a été modifié à <i class="green"><b>{{ $hist->new_value }}</b></i></a>
                          @elseif($hist->namefield == 'ecolience')
                          <a>L'ecolience du projet "<i class="red">{{ $hist->old_value }}</i>" a été modifié à <i class="green"><b>{{ $hist->new_value }}</b></i></a>
                          @elseif($hist->namefield == 'irt')
                          <a>Le code IRT de l'application "<i class="red">{{ $hist->old_value }}</i>" a été modifié à <i class="green"><b>{{ $hist->new_value }}</b></i></a>
                          @elseif($hist->namefield == 'trigramme')
                          <a>Le trigramme de l'application "<i class="red">{{ $hist->old_value }}</i>" a été modifié à <i class="green"><b>{{ $hist->new_value }}</b></i></a>
                          @elseif($hist->namefield == 'criticite_stamp')
                          <a>La criticité STAMP de l'application "<i class="red">{{ $hist->old_value }}</i>" a été modifié à <i class="green"><b>{{ $hist->new_value }}</b></i></a>
                          @elseif($hist->namefield == 'sensible_groupe')
                          <a>Le niveau de sensibilité groupe de l'application "<i class="red">{{ $hist->old_value }}</i>" a été modifié à <i class="green"><b>{{ $hist->new_value }}</b></i></a>
                          @elseif($hist->namefield == 'niv_sensible_fraude')
                          <a>Le niveau de sensibilité à la fraude de l'application "<i class="red">{{ $hist->old_value }}</i>" a été modifié à <i class="green"><b>{{ $hist->new_value }}</b></i></a>
                          @elseif($hist->namefield == 'demande_client')
                          <a>La demande client de l'application "<i class="red">{{ $hist->old_value }}</i>" a été modifié à <i class="green"><b>{{ $hist->new_value }}</b></i></a>
                          @elseif($hist->namefield == 'statu')
                          <a>Le statut de l'application <i class="red">
                            @if($hist->old_value == '1')
                            <span class="label label-success">Final</span>
                            @else
                            <span class="label label-warning">Draft</span>
                            @endif
                            @endif
                          </p>
                        </div>
                      </div>
                    </li>
                    @endforeach
                    <li>
                      <div class="block">
                        <div class="tags">
                          <a href="" class="tag">
                            <span>Creation</span>
                          </a>
                        </div>
                        <div class="block_content">
                          <h2 class="title">
                            <a>L'application a été crée</a>
                          </h2>
                          <div class="byline">
                            <span>{{ date('d/m/Y', strtotime($applications->created_at)) }}</span> par <a>{{ ucfirst(User::find($applications->user_id)->name) }}</a>
                          </div>
                        </div>
                      </div>
                    </li>
                  </ul>
                </div>
              </div>
            </section>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
@endsection
@section('js')
<script type="text/javascript">

  var list_name = [];
  var list_email = [];
  var list_entite = [];

// Recuperation de la liste des intervenants
$(function (){

    // Autocomplete sur le nom INTERVENANTS
    $('#name_interv').autocomplete({
      serviceUrl:'/admin/intervenants/list',
      minLength: 2,
      dataType: 'json',
      showNoSuggestionNotice : true,
      noSuggestionNotice: 'Aucun resultat',
      onSelect: function (suggestion) {
        $('#email_interv').val(suggestion.email);
        $('#entite_interv').val(suggestion.entite);
        $('#resp_domain_interv').val(suggestion.resp_domain);
      },
      onSearchStart: function(query){

        $("#loader").css("display","initial");
      },
      onSearchComplete: function(query,suggestion){
        $("#loader").css("display","none");
      },
    });

    // Autocomplete sur le domaine de responsabilité
    $('#resp_domain_interv').autocomplete({
      serviceUrl: '/admin/intervenants/list/resp_domain',
      minLength: 2,
      dataType: 'json',
      showNoSuggestionNotice : true,
      noSuggestionNotice: 'Aucun resultat',
      onSearchStart: function(query){
        $("#loader").css("display","initial");
      },
      onSearchComplete: function(query,suggestion){
        $("#loader").css("display","none");
      },
    });

    // Autocomplete sur l'entite INTERV
    $('#entite_interv').autocomplete({
      serviceUrl: '/admin/intervenants/list/entite',
      minLength: 2,
      dataType: 'json',
      showNoSuggestionNotice : true,
      noSuggestionNotice: 'Aucun resultat',
      onSearchStart: function(query){
        $("#loader").css("display","initial");
      },
      onSearchComplete: function(query,suggestion){
        $("#loader").css("display","none");
      },
    });

    // Autocomplete sur le nom DIFFUSION
    $('#name_diff').autocomplete({
      serviceUrl:'/admin/diffusion/list',
      minLength: 2,
      dataType: 'json',
      showNoSuggestionNotice : true,
      noSuggestionNotice: 'Aucun resultat',
      onSelect: function (suggestion) {
        $('#entite_diff').val(suggestion.entite);
        $('#objet_diff').val(suggestion.objet);
      },
      onSearchStart: function(query){
        $("#loader_diff").css("display","initial");
      },
      onSearchComplete: function(query,suggestion){
        $("#loader_diff").css("display","none");
      },
    });

    // Autocomplete sur l'entite DIFF
    $('#entite_diff').autocomplete({
      serviceUrl: '/admin/diffusion/list/entite',
      minLength: 2,
      dataType: 'json',
      showNoSuggestionNotice : true,
      noSuggestionNotice: 'Aucun resultat',
      onSearchStart: function(query){

        $("#loader_diff").css("display","initial");
      },
      onSearchComplete: function(query,suggestion){
        $("#loader_diff").css("display","none");
      },
    });
  });

$("#updateapp").on('click', function(e) {
  $.ajax({
    type: 'get',
    url: "up/updates?id=<?php echo $applications->id ?>&name="+$('input[name=name]').val()+"&ecolience="+$('input[name=ecolience]').val()+"&irt="+$('input[name=irt]').val()+"&trigramme="+$('input[name=trigramme]').val()+"&criticite_stamp="+$('select[name=criticite_stamp]').val()+"&sensible_groupe="+$('input[name=sensible_groupe]').val()+"&niv_sensible_fraude="+$('input[name=niv_sensible_fraude]').val()+"&demande_client="+$('textarea[name=demande_client]').val()+"",
          success: function(result) { // Je récupère la réponse du fichier PHP
            $("#app_name").html(result.name);
            $("#app_ecolience").html(result.ecolience);
            $("#app_irt").html(result.irt);
            $("#app_trigramme").html(result.trigramme);
            $("#app_criticite_stamp").html(result.criticite_stamp);
            $("#app_sensible_groupe").html(result.sensible_groupe);
            $("#app_niv_sensible_fraude").html(result.niv_sensible_fraude);
            $("#app_demande_client").html(result.demande_client);
            $('#modal_app').modal('hide');
            location.reload();
            swal({
              title: "Modification",
              text: "L'application a été bien modifié",
              type: "success",
              confirmButtonText: "Fermer"
            });              
          }
        });
});
var idApps = $('#idApps').val();

$.ajax({
  type: 'get',
  url: idApps+'/apps',
  success: function(result) {
    $("#loaders").css('display', 'none');
     $("#tab_content2").html(result);
     var pdf_btn = "<a href='{{ route('Laralum::pdf',['id' => $applications->id ])}}'><button type='button class='btn btn-warning pull-right'><i class='fa fa-print'></i></button></a>"
      $("#tab_content2").append(pdf_btn);
     var read = 1;
        var stat = $('#editorstat').val();
        if (stat == 'active') {
          $('#versionCtr').css('display', '');
          $('#editPrfl').css('display', '');
          $('button[id^="save_"]').css('display', '');
          var read = 0;
        }  
        //$('textarea[class^="mceEditor_"]').each(function(){
          //var el = (this.id).split('_');
          //wiziAddTpl("mceEditor_"+el[1], read);
          tinyMCE.init({
            mode : "specific_textareas",
            editor_selector : "mceEditor_",
            readonly : read,
            autoresize_overflow_padding: 10,
            theme: 'modern',
            plugins: [
              'autoresize lists image preview',
              'fullscreen',
              'save table contextmenu directionality',
              'textcolor colorpicker textpattern'
            ],
            toolbar1: 'undo redo | styleselect | bold italic underline forecolor backcolor | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image | preview media | responsivefilemanager ',
            image_advtab: true,
            relative_urls: false,

            filemanager_title:"Responsive Filemanager",
            filemanager_crossdomain: false,
            /*external_filemanager_path:"{!! str_finish(asset('/templates'),'/') !!}",
            external_plugins: { "filemanager" : "{!! str_finish(asset('/templates'),'/') !!}/plugin.min.js"},*/
            external_filemanager_path:"../../../templates/",
             external_plugins: { "filemanager" : "../../../templates/plugin.min.js"},         
                    content_css: [
                      '//fonts.googleapis.com/css?family=Lato:300,300i,400,400i',
                      '//www.tinymce.com/css/codepen.min.css'
                    ]
        });
          
        //});       
  }
}); 
  
 $('#activeEdit').on('click', function(){
   var stat = $('#editorstat').val();
   if (stat == 'activepossible') {    
    $('#editPrfl').css('display', '');
    var _token = $('input[name=_token]').val();
    var formData = {id:idApps, stat:'editor', _token: _token};
    $.ajax({
      type: 'post',
      url: 'activeEdit',
      data : formData,
      success: function(result) {
        if (result == 'edit') {
          $('#versionCtr').css('display', '');
          $('#editPrfl').css('display', '');
          $('button[id^="save_"]').css('display', '');
          $('textarea[id^="text_statFirsNiv_"]').each(function(){
              tinyMCE.get(this.id).setMode('design');
          });
          $('#activeEdit').removeClass('btn btn-success').addClass('btn btn-danger')
          .html('<i class="fa fa-refresh"></i> Terminer la modification');
          $('#warningEdit').removeClass('alert alert-success alert-dismissible fade in')
          .addClass('alert alert-danger alert-dismissible fade in');
        } else if (result == 'stopedEdit') {
          $('#versionCtr').css('display', 'none');
          $('#editPrfl').css('display', 'none');
          $('button[id^="save_"]').css('display', 'none');
          $('textarea[id^="text_statFirsNiv_"]').each(function(){
              tinyMCE.get(this.id).setMode('readonly');
          });
          $('#activeEdit').removeClass('btn btn-danger').addClass('btn btn-success')
          .html('<i class="fa fa-pencil"></i> Modifier {{$applications->name}}');
          $('#warningEdit').removeClass('alert alert-danger alert-dismissible fade in')
          .addClass('alert alert-success alert-dismissible fade in');
        } else {
          $('#activeEdit').removeClass('btn btn-success').removeClass('btn btn-danger').addClass('btn btn-info')
          .html('<?php if (!empty(User::find($appsParams->active_edit)->name)) {
            echo User::find($appsParams->active_edit)->name; } ?> Modification indisponible <i class="fa fa-exclamation"></i>');
          $('#warningEdit').removeClass('alert alert-danger alert-dismissible fade in')
          .removeClass('alert alert-success alert-dismissible fade in')
          .addClass('alert alert-info alert-dismissible fade in');
          $('#activeEdit').attr('disabled', '');
        }
      }
    });
   }
   if (stat == 'active') {      
    var _token = $('input[name=_token]').val();
    var formData = {id:idApps, stat:'editor', _token: _token};
    $.ajax({
      type: 'post',
      url: 'activeEdit',
      data : formData,
      success: function(result) {
        if (result == 'edit') {
          $('#versionCtr').css('display', '');
          $('#editPrfl').css('display', '');
          $('button[id^="save_"]').css('display', '');
          $('textarea[id^="text_statFirsNiv_"]').each(function(){
              tinyMCE.get(this.id).setMode('design');
          });         
          $('#activeEdit').removeClass('btn btn-success').addClass('btn btn-danger')
          .html('<i class="fa fa-refresh"></i> Terminer la modification');
          $('#warningEdit').removeClass('alert alert-success alert-dismissible fade in')
          .addClass('alert alert-danger alert-dismissible fade in');
        } else if (result == 'stopedEdit') {
          $('#versionCtr').css('display', 'none');
          $('#editPrfl').css('display', 'none');
          $('button[id^="save_"]').css('display', 'none');
          $('textarea[id^="text_statFirsNiv_"]').each(function(){
              tinyMCE.get(this.id).setMode('readonly');
          });
          $('#activeEdit').removeClass('btn btn-danger').addClass('btn btn-success')
          .html('<i class="fa fa-pencil"></i> Modifier {{$applications->name}}');
          $('#warningEdit').removeClass('alert alert-danger alert-dismissible fade in')
          .addClass('alert alert-success alert-dismissible fade in');
        } else {
          $('#activeEdit').removeClass('btn btn-success').removeClass('btn btn-danger').addClass('btn btn-info')
          .html('<?php if (!empty(User::find($appsParams->active_edit)->name)) {
            echo User::find($appsParams->active_edit)->name; } ?> Modification indisponible <i class="fa fa-exclamation"></i>');
          $('#warningEdit').removeClass('alert alert-danger alert-dismissible fade in')
          .removeClass('alert alert-success alert-dismissible fade in')
          .addClass('alert alert-info alert-dismissible fade in');
          $('#activeEdit').attr('disabled', '');
        }
      }
    });
   }
  }); 
$("#add_interv_btn").on("click",function(e){
  var _name = $("#name_interv").val();
  var _email = $("#email_interv").val();
  var _entite = $("#entite_interv").val();
  var _resp_domain = $("#resp_domain_interv").val();

  var _token = $('input[name=_token]').val();
  var formData = {
    name:_name, email:_email,entite:_entite,resp_domain:_resp_domain, _token: _token,id_app: {{ $applications->id }}
  };
  $.ajax({
    type: 'post',
    url: '/admin/intervenants/add',
    data: formData,
    success:function(result){
      var row = '<tr><td>'+_entite+'</td><td>'+_resp_domain+'</td><td>'+_name+'</td></tr>';
        // Cache l'ensemble du modal
        $("#table_interv tbody").append(row);
        $(".modal").hide();
        $(".autocomplete-no-suggestion").hide();
        $(".modal-backdrop").hide();
        // Remise a 0 des inputs
        $("#name_interv").val("");
        $("#email_interv").val("");
        $("#entite_interv").val("");
        $("#resp_domain_interv").val("");
        // Affichage d'une notification
        swal({
          title: "Ajout",
          text: "L'intervenant a bien été ajouté",
          type: "success",
          confirmButtonText: "Fermer"
        });  
      }
    });
});

$("#add_diff_btn").on("click",function(e){
  var _name = $("#name_diff").val();
  var _entite = $("#entite_diff").val();
  var _objet = $("#objet_diff").val();

  var _token = $('input[name=_token]').val();
  var formData = {
    name:_name,entite:_entite,objet:_objet, _token: _token,id_app: {{ $applications->id }}
  };
  $.ajax({
    type: 'post',
    url: '/admin/diffusion/add',
    data: formData,
    success:function(result){
      var row = '<tr><td>'+_entite+'</td><td>'+_name+'</td><td>'+_objet+'</td></tr>';
        // Cache l'ensemble du modal
        $("#table_diff tbody").append(row);
        $(".modal").hide();
        $(".autocomplete-no-suggestion").hide();
        $(".modal-backdrop").hide();
        // Remise a 0 des inputs
        $("#name_diff").val("");
        $("#entite_diff").val("");
        $("#objet_diff").val("");
        // Affichage d'une notification
        swal({
          title: "Ajout",
          text: "La nouvelle diffusion a bien été ajouté",
          type: "success",
          confirmButtonText: "Fermer"
        });  
      }
    });
});
</script>
@endsection

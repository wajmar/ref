	@extends('layouts.admin.panel')
	@section('breadcrumb')
	<div class="ui breadcrumb">
		<i class="fa fa-newspaper-o"></i>
		<a class="section" href="">Modification</a>
	</div>
	@endsection
	@section('content')
	<div class="clearfix"></div>	
	<div id="loaders" style="margin-top:200px;margin-left:570px;"><img src="../../../images/loader.gif"></div>
	@if(Laralum::loggedInUser()->hasPermission('refarc.templates.edit') && $tpl->nbapps == 0)
	<input id="auth" type="hidden" value="1">
	@else
	<input id="auth" type="hidden" value="0">
	@endif
	<div class="row">
	</div>
	@endsection
	@section('js')	
	<script type="text/javascript">
		var auth = $('#auth').val();	
		$.ajax({
			type: 'get',
			url: 'tpls',
			success: function(result) {
				$("#loaders").css('display', 'none');
				$(".row").hide().html(result).fadeIn('slow');
				
				if (auth == 1) {
					var readO = 0;
				} else {
					var readO = 1;
				}
				wiziAddTpl("mceEditorAdd", readO);
				$('span[id^="title_"]').on('click', function(){
					var el = (this.id).split('_');
					wiziAddTpl("mceEditor_"+el[1], readO);
					tinyMCE.init({
						mode : "specific_textareas",
						editor_selector : "mceEditor_1",
						readonly : readO,
						autoresize_overflow_padding: 10,
						theme: 'modern',
						plugins: [
						'autoresize lists image preview',
						'fullscreen',
						'save table contextmenu directionality',
						'textcolor colorpicker textpattern'
						],
						toolbar1: 'undo redo | styleselect | bold italic underline forecolor backcolor | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image | preview media | responsivefilemanager ',
						image_advtab: true,
						relative_urls: false,

						filemanager_title:"Responsive Filemanager",
						filemanager_crossdomain: false,
            /*external_filemanager_path:"{!! str_finish(asset('/templates'),'/') !!}",
            external_plugins: { "filemanager" : "{!! str_finish(asset('/templates'),'/') !!}/plugin.min.js"},*/
            external_filemanager_path:"../../../templates/",
            external_plugins: { "filemanager" : "../../../templates/plugin.min.js"},           
            content_css: [
            '//fonts.googleapis.com/css?family=Lato:300,300i,400,400i',
            '//www.tinymce.com/css/codepen.min.css'
            ]
        });
				});		  
			}
		});	
		$('#editaria').on('click', function(){
			$('textarea[id^="text_statFirsNiv_"]').each(function(){
				tinyMCE.get(this.id).setMode('design');
			});
		});
	</script>
	@endsection
	
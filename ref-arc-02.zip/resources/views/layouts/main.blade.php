<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

        {!! Laralum::includeAssets('header') !!}
    </head>
    <body>
        <form id="logout-form" action="{{ url('/logout') }}" method="POST" style="display: none;">
    		{{ csrf_field() }}
    	</form>
        <div class="flex-center position-ref full-height">
            <!--@if (Route::has('login'))
                @if(Auth::check())
                    <div class="top-right links">
                        <a href="{{ url('/') }}">Welcome</a>
                        <a href="{{ url('/home') }}">Home</a>
                        @if(Laralum::loggedInUser()->isAdmin())
                            <a href="{{ route('Laralum::dashboard') }}">Administration</a>
                        @endif
                        <a href="{{ url('/logout') }}" onclick="event.preventDefault();document.getElementById('logout-form').submit();">Logout</a>
                    </div>
                @else
                    <div class="top-right links">
                        @if(!Laralum::checkInstalled())
                            <a style="color: #00C853;" href="{{ route('Laralum::install_locale') }}">Install Laralum</a>
                        @endif
                        <a href="{{ url('/') }}">Welcome</a>
                        <a href="{{ url('/home') }}">Home</a>
                        <a href="{{ url('/login') }}">Login</a>
                        <a href="{{ url('/register') }}">Register</a>
                    </div>
                @endif
            @endif-->

            <div class="content">

                @yield('content')
                <br>
                @if(session('success'))
            		<p style='font-size: 40px;color:green;'>{!! session('success') !!}<p>
            	@endif
            	@if(session('error'))
            		<p style='font-size: 40px;color:red;'>{!! session('error') !!}<p>
            	@endif
                @if(session('warning'))
            		<p style='font-size: 40px;color:orange;'>{!! session('warning') !!}<p>
            	@endif
            	@if(session('info'))
            		<p style='font-size: 40px;color:blue;'>{!! session('info') !!}<p>
            	@endif
                @if (session('status'))
                    <p style='font-size: 40px;color:green;'>{!! session('status') !!}<p>
                @endif
            	@if (count($errors) > 0)
            		<?php foreach($errors->all() as $error){ echo "<p style='font-size: 40px;color:red;'>$error<p>"; } ?>
            	@endif

            </div>
        </div>
    </body>
</html>

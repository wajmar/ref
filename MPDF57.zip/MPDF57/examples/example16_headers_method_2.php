<?php

include("../mpdf.php");

$mpdf=new mPDF('c','A4','','',10,10,47,47,8,0); 

$mpdf->mirrorMargins = 1;	// Use different Odd/Even headers and footers and mirror margins

$header = '
<table width="100%" style="vertical-align: bottom; font-family: serif;color: #000088;padding-bottom:0px;" border="1"><tr>
<td width="20%" align="left"><img src="sg.png" width="124px" style="padding-top:20px;"/></td>
<td width="60%" align="center" style="padding-top:20px;"><div style="font-size:16px;color:#000000;">Projet NOM APPLICATION <br>Dossier Architecture Hebergement</div></td>
<td width="20%" style="font-family:Times New Roman;font-size:14px;text-align: center;color:#000000"><img src="image7.png" width="30px"/><span>Diffusion <br>interne SG</span></td>
</tr></table>
';
$headerE = '
<table width="100%" style="border-bottom: 1px solid #000000; vertical-align: bottom; font-family: serif; font-size: 9pt; color: #000088;"><tr>
<td width="33%"><span style="font-weight: bold;">Outer header</span></td>
<td width="33%" align="center"><img src="sunset.jpg" width="126px" /></td>
<td width="33%" style="text-align: right;">Inner header p <span style="font-size:14pt;">{PAGENO}</span></td>
</tr></table>
';

$footer = '<div align="center">See <a href="http://mpdf1.com/manual/index.php">documentation manual</a></div>';
$footerE = '<div align="center">See <a href="http://mpdf1.com/manual/index.php">documentation manual</a></div>';


$mpdf->SetHTMLHeader($header);
$mpdf->SetHTMLHeader($header);
$mpdf->SetHTMLFooter($footerE,'E');


$html = '
<br>
<br>
<br>
<br>
<div style="background-color:#55C9FF;font-size:30px;" align="center"><b>Nom Application</b></div>
<br>
<br>
<div style="font-size:30px;" align="center"><b>Dossier d\'architecture Hebergement (DAH)</b></div>
<br>
<br>
<br>
<table aligne="center" width="80%" border="1">
<tr><td aligne="center" style="text-align:right;">Row 1<br>Ecolience</td><td>This is data</td></tr>
<tr><td aligne="center" style="text-align:right;">Row 1</td><td>This is data</td></tr>
</table>
';
// LOAD a stylesheet
$stylesheet = file_get_contents('mpdfstyletables.css');
$mpdf->WriteHTML($stylesheet,1);	// The parameter 1 tells that this is css/style only and no body/html/text
$mpdf->WriteHTML($html);

$mpdf->Output();
exit;

?>
<?php
$name='XBZar';
$type='TTF';
$desc=array (
  'Ascent' => 1025,
  'Descent' => -488,
  'CapHeight' => 680,
  'Flags' => 4,
  'FontBBox' => '[-292 -904 1630 1246]',
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 629,
);
$up=-278;
$ut=29;
$ttffile='C:/xampp/htdocs/MPDF57/ttfonts/XB Zar.ttf';
$TTCfontID='0';
$originalsize=1397368;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='xbzar';
$panose=' 0 0 2 0 5 6 9 0 0 2 0 3';
$haskerninfo=false;
$unAGlyphs=true;
?>
<?php
$name='XBRiyaz-BoldItalic';
$type='TTF';
$desc=array (
  'Ascent' => 1123,
  'Descent' => -391,
  'CapHeight' => 720,
  'Flags' => 262148,
  'FontBBox' => '[-481 -849 1632 1274]',
  'ItalicAngle' => 0,
  'StemV' => 165,
  'MissingWidth' => 605,
);
$up=-278;
$ut=29;
$ttffile='C:/xampp/htdocs/MPDF57/ttfonts/XB RiyazBdIt.ttf';
$TTCfontID='0';
$originalsize=1159500;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='xbriyazBI';
$panose=' 0 0 2 0 8 3 8 0 0 9 0 4';
$haskerninfo=false;
$unAGlyphs=true;
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

        <?php echo Laralum::includeAssets('header'); ?>

    </head>
    <body>
        <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
    		<?php echo e(csrf_field()); ?>

    	</form>
        <div class="flex-center position-ref full-height">
            <div class="content">
                <?php echo $__env->yieldContent('content'); ?>
                <br>
            </div>
        </div>
    </body>
</html>
<?php echo $__env->yieldContent('js'); ?>


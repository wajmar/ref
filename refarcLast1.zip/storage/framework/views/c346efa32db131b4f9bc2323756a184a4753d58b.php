<!DOCTYPE html>

<html lang="en">
<head>
	<meta charset="utf-8">

	<title><?php echo $__env->yieldContent('title'); ?> - <?php echo e(Laralum::settings()->website_title); ?></title>
	<meta name="description" content="Laralum - Laravel administration panel">
	<meta name="author" content="Èrik Campobadal Forés">

	<?php echo Laralum::includeAssets('laralum_header'); ?>


	<?php echo Laralum::includeAssets('charts'); ?>


  <?php echo $__env->yieldContent('css'); ?>

  <!--[if lt IE 9]>
    <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->

  </head>

  <body class="nav-md">

   <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
    <?php echo e(csrf_field()); ?>

  </form>

  <?php if(session('success')): ?>
  <script>
    $(document).ready(function() {
      swal({
        title: "",
        text: "<?php echo session('success'); ?>",
        type: "success",
        confirmButtonText: "Fermer"
      });     
    });			
  </script>
  <?php endif; ?>
  <?php if(session('error')): ?>
  <script>    
    $(document).ready(function() {
      swal({
        title: "",
        text: "<?php echo session('error'); ?>",
        type: "error",
        confirmButtonText: "Fermer"
      });
    });
  </script>
  <?php endif; ?>
  <?php if(session('warning')): ?>
  <script>
    $(document).ready(function() {
      new PNotify({
        title: "Erreur!",
        type: "worning",
        text: "<?php echo session('warning'); ?>",
        nonblock: {
          nonblock: true
        },
        addclass: 'dark',
        styling: 'bootstrap3'
      });
    });
</script>
<?php endif; ?>
<?php if(session('info')): ?>
<script>
$(document).ready(function() {
  new PNotify({
    title: "info",
    type: "worning",
    text: "<?php echo session('info'); ?>",
    nonblock: {
      nonblock: true
    },
    addclass: 'dark',
    styling: 'bootstrap3'
  });
});
</script>
<?php endif; ?>
<?php if(count($errors) > 0): ?>
<script>
  $(document).ready(function() {
   swal({
    title: "Erreur!",
    text: "<?php foreach($errors->all() as $error){ echo "$error<br>"; } ?>",
    type: "error",
    confirmButtonText: "Fermer",
    html: true
  });
 });
</script>
<?php endif; ?>




<div class="container body">
  <div class="main_container">
    <div class="col-md-3 left_col">
      <div class="left_col scroll-view">
        <div class="navbar nav_title" style="border: 0;">
          <a href="<?php echo e(route('Laralum::dashboard')); ?>" class="site_title"><i class="fa fa-archive"></i> <span><b class="red">Ref</b> 'ARC</span></a>
        </div>

        <div class="clearfix"></div>
      <!-- sidebar menu -->
      <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
        <div class="menu_section">
          <ul class="nav side-menu">
            <li><a href="<?php echo e(route('Laralum::dashboard')); ?>"><i class="fa fa-home"></i>Tableau de bord</a>
            </li>
            <li><a><i class="fa fa-folder"></i>Projets<span class="fa fa-chevron-down"></span></a>
              <ul class="nav child_menu">
                <?php if(Laralum::loggedInUser()->hasPermission('refarc.projects.access')): ?>
                <li><a href="<?php echo e(route('Laralum::projects')); ?>"><i class="fa fa-list-ul"></i>Listes des DAH</a></li>
                <?php endif; ?>
                <?php if(Laralum::loggedInUser()->hasPermission('refarc.projects.create')): ?>
                <li><a href="<?php echo e(route('Laralum::projects_create')); ?>"><i class="fa fa-plus"></i>Creer un nouveau DAH</a></li>
                <?php endif; ?>  
              </ul>
            </li>
            <?php if(Laralum::loggedInUser()->hasPermission('refarc.users.access')): ?>
            <li><a><i class="fa fa-users"></i>Utilisateurs<span class="fa fa-chevron-down"></span></a>
              <ul class="nav child_menu">
                <li><a href="<?php echo e(route('Laralum::users')); ?>"><i class="fa fa-list-ul"></i>Listes des utilisateurs</a></li>
                <?php if(Laralum::loggedInUser()->hasPermission('refarc.users.create')): ?>
                  <li><a href="<?php echo e(route('Laralum::users_create')); ?>"><i class="fa fa-plus"></i>Creer un nouvel utilisateur</a></li>
                <?php endif; ?>
                <?php if(Laralum::loggedInUser()->hasPermission('refarc.users.settings')): ?>
                  <li><a href="<?php echo e(route('Laralum::users_settings')); ?>"><i class="fa fa-cogs"></i>Configuration</a></li> 
                <?php endif; ?>
              </ul>
            </li>
            <?php endif; ?>
            <?php if(Laralum::loggedInUser()->hasPermission('refarc.roles.access')): ?>
            <li><a><i class="fa fa-tags"></i>Roles<span class="fa fa-chevron-down"></span></a>
              <ul class="nav child_menu">
                <li><a href="<?php echo e(route('Laralum::roles')); ?>"><i class="fa fa-list-ul"></i>Listes des roles</a></li>
                <?php if(Laralum::loggedInUser()->hasPermission('refarc.roles.create')): ?>
                <li><a href="<?php echo e(route('Laralum::roles_create')); ?>"><i class="fa fa-plus"></i>Creer un nouvel role</a></li>
                <?php endif; ?>
              </ul>
            </li>
            <?php endif; ?>
            <?php if(Laralum::loggedInUser()->hasPermission('refarc.permissions.access')): ?>
            <li><a><i class="fa fa-toggle-on"></i>Permissions<span class="fa fa-chevron-down"></span></a>
              <ul class="nav child_menu">
                <li><a href="<?php echo e(route('Laralum::permissions')); ?>"><i class="fa fa-list-ul"></i>Listes des permissions</a></li>
              </ul>
            </li>
            <?php endif; ?>
            <?php if(Laralum::loggedInUser()->hasPermission('refarc.templates.access')): ?>
            <li><a><i class="fa fa-newspaper-o"></i>Templates<span class="fa fa-chevron-down"></span></a>
              <ul class="nav child_menu">
                <li><a href="<?php echo e(route('Laralum::templates')); ?>"><i class="fa fa-cogs"></i>Gestion du template</a></li>
                <?php if(Laralum::loggedInUser()->hasPermission('refarc.templates.create')): ?>
                <li><a href="<?php echo e(route('Laralum::templates_types')); ?>"><i class="fa fa-cog"></i>Gestion des types</a></li>
                <?php endif; ?>
                <?php if(Laralum::loggedInUser()->hasPermission('refarc.templates.create')): ?>
                  <li><a href="<?php echo e(route('Laralum::fusion')); ?>"><i class="fa fa-filter"></i>Fusioner templates</a></li>
                <?php endif; ?>
                <li><a href="<?php echo e(route('Laralum::templates_users')); ?>"><i class="fa fa-users"></i> Utilisateurs génériques</a></li>
              </ul>
            </li>
            <?php endif; ?>
            <li><a><i class="fa fa-refresh"></i> Retour Experience<span class="fa fa-chevron-down"></span></a>
              <ul class="nav child_menu">
                <li>
                  <a href="<?php echo e(route('Laralum::experiences')); ?>"><i class="fa fa-bug"></i> Mes retours</a>
                </li>
                <li>
                  <a href="<?php echo e(route('Laralum::experiences_admin')); ?>"><i class="fa fa-cogs"></i>Administration retour</a>
                </li>
              </ul>
            </li>
          </ul>
        </div>
      </div>
      <!-- /sidebar menu -->
    </div>
  </div>

  <!-- top navigation -->
  <div class="top_nav">
    <div class="nav_menu">
      <nav class="" role="navigation">
        <div class="nav toggle">
          <a id="menu_toggle"><i class="fa fa-bars"></i></a>
        </div>

        <ul class="nav navbar-nav navbar-right">
          <li class="">
            <a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
              <i class="fa fa-user"></i> <?php echo e(Auth::user()->name); ?>

              <span class=" fa fa-angle-down"></span>
            </a>
            <ul class="dropdown-menu dropdown-usermenu pull-right">
              <li><a href="<?php echo e(route('Laralum::users_profile',['id' => Laralum::loggedInUser()->id])); ?>"><?php echo e(trans('laralum.profile')); ?></a></li>
              <li>
                <a href="<?php echo e(url('/logout')); ?>"
                onclick="event.preventDefault();document.getElementById('logout-form').submit();">
                <i class="fa fa-sign-out pull-right"></i>
                <?php echo e(trans('laralum.logout')); ?>


              </a></li>
            </ul>
          </li>

          <!--<li role="presentation" class="dropdown">
            <a href="javascript:;" class="dropdown-toggle info-number" data-toggle="dropdown" aria-expanded="false">
              <i class="fa fa-envelope-o"></i>
              <span class="badge bg-green">6</span>
            </a>
            <ul id="menu1" class="dropdown-menu list-unstyled msg_list" role="menu">
              <li>
                <a>

                  <span>
                    <span>John Smith</span>
                    <span class="time">3 mins ago</span>
                  </span>
                  <span class="message">
                    Film festivals used to be do-or-die moments for movie makers. They were where...
                  </span>
                </a>
              </li>
              <li>
                <a>
                  <span>
                    <span>John Smith</span>
                    <span class="time">3 mins ago</span>
                  </span>
                  <span class="message">
                    Film festivals used to be do-or-die moments for movie makers. They were where...
                  </span>
                </a>
              </li>
              <li>
                <a>
                  <span>
                    <span>John Smith</span>
                    <span class="time">3 mins ago</span>
                  </span>
                  <span class="message">
                    Film festivals used to be do-or-die moments for movie makers. They were where...
                  </span>
                </a>
              </li>
              <li>
                <a>
                  <span>
                    <span>John Smith</span>
                    <span class="time">3 mins ago</span>
                  </span>
                  <span class="message">
                    Film festivals used to be do-or-die moments for movie makers. They were where...
                  </span>
                </a>
              </li>
              <li>
                <div class="text-center">
                  <a>
                    <strong>See All Alerts</strong>
                    <i class="fa fa-angle-right"></i>
                  </a>
                </div>
              </li>
            </ul>
          </li>-->
        </ul>
      </nav>
    </div>
  </div>
  <!-- /top navigation -->

  <!-- page content -->
  <div class="right_col" role="main" style="min-height: 905px;">
    <div class="">
      <div class="page-title">
        <div class="title_left">
          <h3><?php echo $__env->yieldContent('breadcrumb'); ?></h3>
        </div>              
      </div>
      <div class="page-content">
        <?php echo $__env->yieldContent('content'); ?>
      </div>
    </div>
  </div>
  <!-- /page content -->

  <!-- footer content -->

  <!-- /footer content -->
</div>
</div>





<?php echo $__env->yieldContent('js'); ?>



</body>
<?php echo Laralum::includeAssets('laralum_bottom'); ?>

</html>

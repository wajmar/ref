<?php $__env->startSection('breadcrumb'); ?>
<div class="ui breadcrumb">
<div class="active section"><i class="fa fa-list-ul"></i> Liste des roles</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title', trans('laralum.roles_title')); ?>
<?php $__env->startSection('icon', "star"); ?>
<?php $__env->startSection('subtitle', trans('laralum.roles_subtitle')); ?>
<?php $__env->startSection('content'); ?>

<div class="clearfix"></div>
<div class="row"> 
  <div class="col-md-12 col-sm-12 col-xs-12">
    <div class="x_panel">
    <div class="x_content">                    
      <table id="datatable-buttons" class="table table-striped table-bordered">
        <thead>
          <tr>
            <th><?php echo e(trans('laralum.name')); ?></th>
            <th><?php echo e(trans('laralum.users')); ?></th>
            <th><?php echo e(trans('laralum.permissions')); ?></th>
            <th>Date de création</th>
            <th><?php echo e(trans('laralum.options')); ?></th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
          <tr>
            <td>
              <h3><?php echo e($role->name); ?>

                <?php if($role->su): ?>
                <i class="fa fa-question" data-toggle="tooltip" data-placement="right" title="Super Administrateur" data-original-title=""></i>
                <?php endif; ?>
              </h3>
            </td>
            <td style="vertical-align:middle;">
              <i class="fa fa-users"></i> <?php echo e(trans('laralum.roles_users', ['number' => count($role->users)])); ?>

            </td>
            <td style="vertical-align:middle;">
              <i class="fa fa-lock"></i> <?php echo e(trans('laralum.roles_permissions', ['number' => count($role->permissions)])); ?>

            </td>
            <td style="vertical-align:middle;">
              <i class="fa fa-calendar"></i> <?php echo e($role->created_at); ?>

            </td>
            <td style="text-align:center;vertical-align:middle;">
              <?php if($role->allow_editing or Laralum::loggedInUser()->su): ?>
              <!-- Bouton pour modifier un rôle -->
		<?php if(!$role->su): ?>
              <a><button type="button" class="btn btn-warning btn-xs" data-toggle="modal" data-target=".modal_<?php echo e($role->id); ?>" data-tooltip="tooltip" data-placement='top' title='Modifier le rôle'><i class="fa fa-pencil" ></i></button></a>
              <!--  Modal pour la modification d'un role -->
              <div class="modal fade modal_<?php echo e($role->id); ?>" tabindex="-1" role="dialog" aria-hidden="true">
                <div class="modal-dialog modal-sm">
                  <div class="modal-content">

                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
                      </button>
                      <h4 class="modal-title" id="myModalLabel" style="text-align:center">Modification d'un rôle</h4>
                    </div>
                    <form method="POST">
                    <div class="modal-body" style="text-align:center;">
                        <label>Nom du rôle : </label><br><br>
                        <input type="text" id="new_role_name_<?php echo e($role->id); ?>" class="form-control" value="<?php echo e($role->name); ?>"><br><br>
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-default" data-dismiss="modal">Annuler</button>
                      <button id="update_role" type="button" class="btn btn-warning" onclick="updateRole(<?php echo e($role->id); ?>)">Modifier</button>
                    </div>
                    </form>
                  </div>
                </div>
              </div>
		<?php endif; ?>
              <!-- Bouton pour accéder aux permissions -->
              <a href="<?php echo e(route('Laralum::roles_permissions', ['id' => $role->id])); ?>"><button type="button" class="btn btn-warning btn-xs" data-toggle='tooltip' data-placement='top' title='Modifier les permissions'><i class="fa fa-lock"></i></button></a> 
              <!-- Bouton pour supprimer un rôle -->
	      <?php if(!$role->su): ?>
              <button type="button" class="btn btn-danger btn-xs" data-toggle="modal" data-target=".modal_del_<?php echo e($role->id); ?>" data-tooltip="tooltip" data-placement="top" title="Supprimer ce rôle"><i class="fa fa-trash"></i></button>                                 
              <div class="modal fade modal_del_<?php echo e($role->id); ?>" tabindex="-1" role="dialog" aria-hidden="true">
                <div class="modal-dialog modal-sm">
                  <div class="modal-content">

                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
                      </button>
                      <h4 class="modal-title" id="myModalLabel" style="text-align:center">Suppression d'un rôle</h4>
                    </div>
                    <div class="modal-body" style="text-align:center;">
                        <span>Etes-vous sûr de vouloir supprimer le rôle <?php echo e($role->name); ?></span>
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-default" data-dismiss="modal">Annuler</button>
                      <a href="<?php echo e(route('Laralum::roles_delete', ['id' => $role->id])); ?>"><button id="del_role" type="button" class="btn btn-danger">Supprimer</button></a>
                    </div>
                  </div>
                </div>
              </div>
		<?php endif; ?>
            </div>
            <?php else: ?>
            <div class="ui disabled <?php echo e(Laralum::settings()->button_color); ?> icon button">
              <i class="lock icon"></i>
            </div>
            <?php endif; ?>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
      </tbody>
    </table>
  </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script type="text/javascript">
  $(document).ready(function() {
    var handleDataTableButtons = function() {
      if ($("#datatable-buttons").length) {
        $("#datatable-buttons").DataTable({
          dom: "Bfrtip",
          buttons: [
          {
            extend: "copy",
            className: "btn-sm"
          },
          {
            extend: "csv",
            className: "btn-sm"
          },
          {
            extend: "excel",
            className: "btn-sm"
          },
          {
            extend: "pdfHtml5",
            className: "btn-sm"
          },
          {
            extend: "print",
            className: "btn-sm"
          },
          ],
          
        });
      }
    };

    TableManageButtons = function() {
      "use strict";
      return {
        init: function() {
          handleDataTableButtons();
        }
      };
    }();


    $('#datatable-responsive').DataTable();        

    TableManageButtons.init(); 

    $("#datatable-buttons_filter").css("display","none");
    $(".dt-buttons").css("display","none");
    $('body').tooltip({
      selector : "[data-tooltip=tooltip]",
      container : "body",
      trigger : 'hover'
    });
  });   
  function updateRole(id){
      $.ajax({
          type: 'get',
          url: "roles/"+id+"/update?name="+$("#new_role_name_"+id).val()+"",
          success: function(result) { // Je récupère la réponse du fichier PHP
              $('.modal').modal('hide');
              location.reload();
              swal({
                title: "Modification",
                text: "Le role a bien été modifié",
                type: "success",
                confirmButtonText: "Fermer"
              });    
          }
      });
    }    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.panel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
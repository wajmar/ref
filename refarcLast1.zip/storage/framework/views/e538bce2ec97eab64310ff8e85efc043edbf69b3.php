<?php
use App\User;
use App\TypeTpl;
?>

<?php $__env->startSection('breadcrumb'); ?>
<div class="ui breadcrumb">
	<i class="fa fa-filter"></i>
	<a class="section" href="">Fusion de templates</a>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="clearfix"></div>
<div class="row"> 
	<div class="col-md-12 col-sm-12 col-xs-12">
		<div class="x_panel">
			<div class="x_title">
			</div>
			<form data-parsley-validate="" class="form-horizontal form-label-left" novalidate="" method="POST">
				<?php echo e(csrf_field()); ?>

				<div class="form-group">
					<label class="control-label col-md-3 col-sm-3 col-xs-12">Choisir une version du template</label>
					<div class="col-md-4 col-sm-9 col-xs-12">
						<select class="select2_group form-control" id="elselected">
							<?php $__currentLoopData = $tplType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
							<optgroup label="<?php echo e($type->type); ?>">
								<?php $__currentLoopData = $templates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $template): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
								<?php if($type->id == $template->type): ?>
								<option value="<?php echo e($template->id); ?>"><?php echo e($type->type); ?> version : <?php echo e($template->version); ?></option>
								<?php endif; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
							</optgroup>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
						</select>
					</div>					
				</div>
			</form>
		</div>
	</div>
</div>
<div class="row">
	<div class="col-md-12 col-sm-12 col-xs-12">
		<div class="x_panel">		
     <menu id="nestable-menu">
       <button type="button" class="btn btn-info" data-action="expand-all"><i class="fa fa-expand"></i> Ouvrir</button>
       <button type="button" class="btn btn-info" data-action="collapse-all"><i class="fa fa-compress"></i> Fermer</button>
       <span id="tplGenerate" style="display:none;">
        <button type="button" class="btn btn-success" data-toggle="modal" data-target=".modaladdapp"><i class="fa fa-download"></i>
          Generer template</button>
        </span>
        <div id="modal_app" class="modal fade modaladdapp" tabindex="-1" role="dialog" aria-hidden="true">
         <div class="modal-dialog modal-lg">
           <div class="modal-content">
             <div class="modal-header" style="text-align: center">
               <div class="modal-title"><h2>Ajouter nouveau template</h2></div>
               <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">X</span>
               </div>
               <div class="modal-body">
                 <form id="edit_app" data-parsley-validate="" class="form-horizontal form-label-left" novalidate="" method="POST">
                  <div id="adType" class="form-group">
                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Type
                    </label>
                    <div class="col-md-6 col-sm-6 col-xs-12">
                      <input type="text" name="type"  id="newtype" required="required" class="form-control">                               
                    </div>
                    <span id="loader"></span>                               
                  </div>
                  <div id="adTypeDisc" class="form-group">
                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Description
                    </label>
                    <div class="col-md-6 col-sm-6 col-xs-12">
                      <textarea  id="comment" name="comment" class="form-control" rows="3" style="width: 414px; height: 91px;"></textarea>
                    </div>
                  </div>                                                                                
                  <input type="hidden" name="_token" value="<?php echo csrf_token() ?>">
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>
                  <button id="updateproj" type="button" class="btn btn-success"  onclick="createTplFusion();">
                    <i class="fa fa-plus"></i> Ajouter template</button>
                    <button style="display: none" type="button" class="btn btn-primary" id="btadd"
                    onclick="adType();"><i class="fa fa-plus"></i> Ajouter nouveau type de document</button>                       
                  </div>
                </div>
              </div>
            </div>
            <span id="load"></span>
          </menu>
          <div class="cf nestable-lists">

            <div class="dd" id="nestable">
              <div class="dd-empty"></div>
            </div>        
            <div class="dd" id="nestable2">
              <div class="dd-empty"></div>
            </div>
            <br><br>        
          </form>
          <textarea id="nestable2-output" style="display: none;"></textarea>
        </div>
      </div>
    </div>
  </div>
  <?php $__env->stopSection(); ?>
  <?php $__env->startSection('js'); ?>
  <script type="text/javascript">
    $(document).ready(function()
    {

      var updateOutput = function(e)
      {	
        var list   = e.length ? e : $(e.target),
        output = list.data('output');
        if (window.JSON) {
        	var data = window.JSON.stringify(list.nestable('serialize'));
          output.val(data);
     
        if ($("#nestable2").find(".dd-empty").length > 0) {//alert('zebda');
          $('#tplGenerate').hide();
        } else {
          $('#tplGenerate').css('display', '');
        }
          var menu = $.parseJSON(data);

          var final_menu = [];

      var i = 1;

      $.each(menu, function(index, value){
        var item = {};
        var sp = value.id.split('/');
        if(typeof(value.children) !== 'undefined')
        {
          var j = 1;
          

          item['id'] = sp[0];
          item['tplId'] = sp[1];
          
          item['order'] = i;
          item['children'] = [];

          $.each(value.children, function(index1, value1){

            var child = {};
            var sh = value1.id.split('/');

            child['id'] = sh[0].replace('.', '_');
            child['tplId'] = sh[1];
            child['order'] = j;

            item['children'].push(child);
            j++; 

          });
        }
        else
        {
          item['id'] = sp[0];
          item['tplId'] = sp[1];
          item['order'] = i; 
        }

        final_menu.push(item);

        $('span#nprg_'+item['id']+'_'+item['tplId']).html(item['order']);

        i++;
      });

      } else {
        output.val('JSON browser support required for this demo.');
      }
      };

          // activate Nestable for list 1
          $('#nestable').nestable({
            group: 1
          });

          $('#nestable2').nestable({
            group: 1
          }).on('change', updateOutput);

          
    updateOutput($('#nestable').data('output', $('#nestable-output')));
    updateOutput($('#nestable2').data('output', $('#nestable2-output')));

    $('#nestable-menu').on('click', function(e)
    {
      var target = $(e.target),
      action = target.data('action');
      if (action === 'expand-all') {
        $('.dd').nestable('expandAll');
      }
      if (action === 'collapse-all') {
        $('.dd').nestable('collapseAll');
      }
    });

    $('#nestable3').nestable();
    

  });
    $('#elselected').on('change', function (e) {
      $('#load').html('<img src="../../images/ajax-loader.gif">');
      var id = this.value;
      var _token = $('input[name=_token]').val();
      $.ajax({
        type: 'post',
        data : {id:id, _token: _token},
        url: 'getdataFusion',
        success: function(result) {
         $('#nestable').html(result);  
         $('#load').html('');
       }
     });
    });

      function createTplFusion() {
        var comment = $('#comment').val();
        var type = $('#newtype').val();      
        var _token = $('input[name=_token]').val();
        var formData = {data:$('#nestable2-output').val(), type:type, comment:comment, _token: _token};
        url = "createTplFusion";
        $('#modal_app').hide();
        $.ajax({
          type: 'post',
          data : formData,
          url: url,
          success: function(result) {       
            if (result) {
          /*var url = '<?php echo e(route('Laralum::templates_suivi', ":id")); ?>';
          url = url.replace(':id', result);
          document.location.href = url;*/
          var url = '<?php echo e(route('Laralum::templates')); ?>';
          document.location.href = url;
        }
      }
    });
      }
      function adType() {
        $('#loader').html('<img src="../../images/ajax-loader.gif">');
        var formData = {type:$('#newtype').val()}
        $.ajax({
          type: 'get',
          data : formData,
          url: 'addtype',
          success: function(result) {
            if (result == 'exist') {
              $('#loader').html('');
              return false;
            } else {
              el = result.split('/');     
              $("#type").append('<option value='+el[0]+'>'+el[1]+'</option>');
              $("select option[value='"+el[0]+"']").attr("selected","selected");
              $('#loader').html('');
              $('#updateproj').fadeIn().show();
              $('#adTypeDisc').fadeIn().show();
              $('#btadd').fadeOut().hide();
            }
          }
        });
      }

      function addType() {    
        $('#adType').fadeIn().show();
        $('#btadd').fadeIn().show();
        $('#updateproj').fadeOut().hide();
        $('#deletetype').fadeIn().show();
        $('#adTypeDisc').fadeOut().hide();
      }
      function delType() {
        $('#adType').hide();
        $('#btadd').hide();
        $('#deletetype').fadeOut().hide();
        $('#comment').val('');
        $('#updateproj').fadeIn().show();
        $('#adTypeDisc').fadeIn().show();
      } 
      function delebtn() {
        $('#adType').hide();
        $('#btadd').hide();
        $('#updateproj').fadeIn().show();
        $('#deletetype').fadeOut().hide();
        $('#adTypeDisc').fadeIn().show();
      }    
    </script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.panel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <div class="ui breadcrumb">
        <a class="section" href="<?php echo e(route('Laralum::users')); ?>"><?php echo e(trans('laralum.user_list')); ?></a>
        /
        <strong class="active section"><?php echo e($user->name); ?></strong>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="clearfix"></div>
    <div class="row">
        <div class="col-md-3">
            <div class="x_panel">
                <br>
                <label class="red">Nom de l'utilisateur :</label><br>
                <span><?php echo e($user->name); ?></span><br><br>
                <label class="red">Identifiant SESAME :</label><br>
                <span><?php echo e($user->id_sesame); ?></span><br><br>
                <label class="red">Adresse mail :</label><br>
                <span><?php echo e($user->email); ?></span><br><br>
                <label class="red"> Rôle(s) :</label><br>
                <span>
                    <ul class="list-unstyled">
                        <?php $__currentLoopData = $roles_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role_user): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <?php if($role->id == $role_user->role_id): ?>
                                    <li><label class="btn btn-info"><?php echo e($role->name); ?></label></li>        
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    </ul>

                </span>
                <label class="red">Statut Compte :</label><br><br>
                <?php 
                    if($user->active == 1){
                        echo "<label class='btn btn-success btn-sm'><i class='fa fa-check'></i> Activé</label>";
                    }
                    else{
                        echo "<label class='btn btn-danger btn-sm'><i class='fa fa-warning'></i> Désactivé</label>";
                    }

                ?>
            </div> 
        </div> 
        <div class="col-md-9">
            <div class="x_panel">
                <div class="row panel-title">
                    <h3>Liste des applications de l'utilisateur</h3>
                </div><br>
                <?php if(count($projects) > 0): ?>
                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <div class="animated flipInY col-lg-6 col-md-6 col-sm-12 col-xs-12" style="float:left">
                            <a href="">
                                <div class="tile-stats" style="border:1px solid #26B99A">
                                    <div class="icon"><i class="fa fa-pencil" style="color:#26B99A;"></i></div>
                                    <div class="count">0%</div>
                                    <h3><?php echo e(ucfirst($project->name)); ?></h3><br>
                                    <div class="progress">
                                        <div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div>
                                    </div>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>    
                <?php else: ?>
                    <span>Aucune application</span>
                <?php endif; ?>
            </div>
        </div>   
    </div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.panel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
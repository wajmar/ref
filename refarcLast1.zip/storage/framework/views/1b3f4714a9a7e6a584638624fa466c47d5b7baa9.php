<?php $__currentLoopData = $tpl_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tpl_type): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <!-- Initialisation du compteur -->
            <?php 
              $count_tpl = 0; 
              $count_docs = 0;
            ?>
            <!-- Ecriture de la ligne -->
            <tr>
              <td><?php echo e($tpl_type->type); ?></td>
              <!-- Explode pour mise en forme de la date -->
              <?php $tpl_date = explode(" ",$tpl_type->created_at); ?>
              <td><?php  echo($tpl_date[0]) ?></td>

              <?php $__currentLoopData = $tpls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tpl): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <?php if($tpl_type->id == $tpl->type): ?>
                  <?php 
                    $count_tpl++;
                    $count_docs = $count_docs + $tpl->nbapps;
                  ?>
                <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
              <?php if($count_tpl > 0): ?>
                <!-- Modification/Suppression impossible-->
                <td><?php echo($count_docs) ?></td>
                <td><?php echo($count_tpl) ?></td>
                <!-- Pr�sence template et documents -->
                <td>
                  <button class="btn btn-default btn-xs" data-toggle="tooltip" data-placement="top" title="Modification impossible"><i class="fa fa-close"></i></button>
                  <button type="button" class="btn btn-default btn-xs" data-toggle="tooltip" data-placement="top" title="Suppression impossible"><i class="fa fa-close"></i></button>
                </td>
              <?php else: ?>
                <!-- Modification/Suppression possible -->
                <td><?php echo($count_docs) ?></td>
                <td><?php echo($count_tpl) ?></td>
                <td>
                  <a data-toggle="tooltip" data-placement="top" title="Modifier"><button type="button" class="btn btn-warning btn-xs" data-toggle="modal" data-target=".modalEditType_<?php echo e($tpl_type->id); ?>" ><i class="fa fa-pencil"></i></button></a>
                  <a data-toggle="tooltip" data-placement="top" title="Supprimer"><button type="button" class="btn btn-danger btn-xs" data-toggle="modal" data-target=".modalDelType_<?php echo e($tpl_type->id); ?>"><i class="fa fa-trash"></i></button></a>
                </td>
              <?php endif; ?>
            </tr>
            <!-- Modal de modification -->
            <div class="modal fade modalEditType_<?php echo e($tpl_type->id); ?>" tabindex="-1" role="dialog" aria-hidden="true">
              <div class="modal-dialog modal-sm">
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">�</span>
                    </button>
                    <h4 class="modal-title" id="myModalLabel">Modification de type</h4>
                  </div>
                  <div class="modal-body">
                    <label class="control-label" for="type_name">Nom du type :</label>
                    <input type="text" id="type_name" name="type_name" class="form-control" value="<?php echo e($tpl_type->type); ?>" required>
                  </div><br>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Annuler</button>
                    <button type="button" class="btn btn-warning" onclick="editType(<?php echo e($tpl_type->id); ?>)"><span id="text_edit_<?php echo e($tpl_type->id); ?>">Modifier</span><img id="loader_edit_<?php echo e($tpl_type->id); ?>" src="<?php echo e(asset('images/7.gif')); ?>" style="height:15px;width:15px;display:none"></button>
                  </div>
                </div>
              </div>
            </div>
            <!-- Fin du modal de modification -->
            <!-- Modal de suppression -->
            <div class="modal fade modalDelType_<?php echo e($tpl_type->id); ?>" tabindex="-1" role="dialog" aria-hidden="true">
              <div class="modal-dialog modal-sm">
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">�</span>
                    </button>
                    <h4 class="modal-title" id="myModalLabel">Suppression de type</h4>
                  </div>
                  <div class="modal-body">
                    <p>Etes-vous s�r de vouloir supprimer ce type ?</p>
                  </div><br>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Annuler</button>
                    <button type="button" class="btn btn-danger" onclick="deleteType(<?php echo e($tpl_type->id); ?>)"><span id="text_del_<?php echo e($tpl_type->id); ?>">Supprimer</span><img id="loader_del_<?php echo e($tpl_type->id); ?>" src="<?php echo e(asset('images/7.gif')); ?>" style="height:15px;width:15px;display:none"></button>
                  </div>
                </div>
              </div>
            </div>
            <!-- Fin du modal de suppression -->
          <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
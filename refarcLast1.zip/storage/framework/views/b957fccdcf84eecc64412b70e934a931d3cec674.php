
<?php $__env->startSection('breadcrumb'); ?>
<div class="ui breadcrumb">
	<i class="fa fa-folder"></i>
	<a class="section" href=""><?php echo e(trans('laralum.projects_list')); ?></a>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="x_panel">
		<div class="x_title">
			<h2><i class="fa fa-users"></i>Liste des utilisateurs génériques</h2>
			<div class="clearfix"></div>
		</div>
		<div class="x_content">
			<div class="" role="tabpanel" data-example-id="togglable-tabs">
				<ul id="myTab" class="nav nav-tabs bar_tabs" role="tablist">
					<li role="presentation" class="active"><a href="#tab_content1" id="home-tab" role="tab" data-toggle="tab" aria-expanded="true">Intervenants génériques</a>
					</li>
					<li role="presentation" class=""><a href="#tab_content2" role="tab" id="profile-tab" data-toggle="tab" aria-expanded="false">Diffusion générique</a>
					</li>
				</ul>
				<div id="myTabContent" class="tab-content">
					<div role="tabpanel" class="tab-pane fade active in" id="tab_content1" aria-labelledby="home-tab">
						<div class="row">
                          <button type="button" class="btn btn-success pull-right" data-toggle="modal" data-target=".modal_add_interv"><i class="fa fa-plus"></i> Ajouter</button>
                        </div><br>
                        <table id="table_interv" class="table table-bordered">
                          	<thead>
                            	<tr>
                              		<th>Entite</th>
                              		<th>Domaine de responsabilite</th>
                          			<th>Nom Prenom</th>
                          			<th>Options</th>
                            	</tr>
                          	</thead>
                          	<tbody>
                          	<?php $__currentLoopData = $intervenants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $interv): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                           		<tr class="interv_<?php echo e($interv->id); ?>">
                           			<td><?php echo e($interv->entite); ?></td>
                           			<td><?php echo e($interv->resp_domain); ?></td>
                           			<td><?php echo e($interv->nom); ?></td>
                           			<td><button type="button" class="btn btn-danger btn-xs" onclick="del_interv(<?php echo e($interv->id); ?>)" data-toggle="tooltip" data-placement="top" title="Supprimer"><i class="fa fa-trash"></i></button></td>
                           		</tr>
                           	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                          	</tbody>
                        </table>
					</div>
					<div role="tabpanel" class="tab-pane fade" id="tab_content2" aria-labelledby="profile-tab">
						<div class="row">
                          <button type="button" class="btn btn-success pull-right" data-toggle="modal" data-target=".modal_add_diff"><i class="fa fa-plus"></i> Ajouter</button>
                        </div><br>
                        <table id="table_diff" class="table table-bordered">
                          	<thead>
	                            <tr>
                              		<th>Entite</th>
                              		<th>Nom du destinataire</th>
                              		<th>Objet</th>
                              		<th>Options</th>
                        		</tr>
                          	</thead>
                          	<tbody>
                            <?php $__currentLoopData = $diffusion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $diff): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            	<tr class="diff_<?php echo e($diff->id); ?>">
                            		<td><?php echo e($diff->entite); ?></td>
                            		<td><?php echo e($diff->nom); ?></td>
                            		<td><?php echo e($diff->objet); ?></td>
                            		<td><button type="button" class="btn btn-danger btn-xs" onclick="del_diff(<?php echo e($diff->id); ?>)" data-toggle="tooltip" data-placement="top" title="Supprimer"><i class="fa fa-trash"></i></button></td>
                            	</tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                          	</tbody>
                        </table>
					</div>
					<!-- MODAL AJOUT INTERVENANT -->
			        <div class="modal fade modal_add_interv" tabindex="-1" role="dialog" aria-hidden="true">
			            <div class="modal-dialog modal-lg">
			              	<div class="modal-content">
			                	<div class="modal-header">
				                  	<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
				                  	</button>
				                 	 <h4 class="modal-title" id="myModalLabel" style="text-align:center">Ajout d'un intervenant</h4>
				                  	<!--<div id="div_loader" style="text-align:center;height:30px;">
				                    	<img src="<?php echo e(asset('images/loader.gif')); ?>" id="loader" style="height:30px;display:none" >
				                  	</div>-->
			                	</div>
				                <div class="modal-body">
					                <form id="form_interv">
					                    <?php echo e(csrf_field()); ?>

					                    <label class="control-label" for="name_interv">Nom :</label><br>
					                    <input type="text" id="name_interv" name="name_interv" class="form-control col-md-10" autocomplete="off" required/>
					                    <label for="email_interv">Email :</label>
					                    <input type="text" id="email_interv" class="form-control" name="email" autocomplete="off" required>
					                    <label for="entite_interv">Entite/Service :</label>
					                    <input type="text" id="entite_interv" class="form-control" name="entite" autocomplete="off" required>
					                    <label for="resp_domain_interv">Domaine de responsabilite :</label>
					                    <input type="text" id="resp_domain_interv" class="form-control" name="resp_domain" autocomplete="off" required><br>
                              <span id="error_mess_interv" style="font-style:italic;color:red;"></span>
					                    <div class="pull-right">
					                      <button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>
					                      <button id="add_interv_btn" type="button" class="btn btn-success">Ajouter</button>
					                    </div>
					                </form>
				                </div>
			                </div>
			            </div>
			        </div>
			        <!-- MODAL AJOUT DIFFUSION -->
          			<div class="modal fade modal_add_diff" tabindex="-1" role="dialog" aria-hidden="true">
            			<div class="modal-dialog modal-lg">
              				<div class="modal-content">
                				<div class="modal-header">
              						<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
                  					</button>
                  					<h4 class="modal-title" id="myModalLabel" style="text-align:center">Ajout d'une diffusion</h4>
                  					<!--<div id="div_loader" style="text-align:center;height:30px;">
                    					<img src="<?php echo e(asset('images/loader.gif')); ?>" id="loader_diff" style="height:30px;display:none">
                  					</div>-->
                				</div>
                				<div class="modal-body">
                  					<form id="form_diff">
                    					<?php echo e(csrf_field()); ?>

                    					<label class="control-label" for="name_diff">Nom :</label><br>
                						<input type="text" id="name_diff" name="name" class="form-control col-md-10" autocomplete="off" required/>
                    					<label for="entite_diff">Entite/Service :</label>
                						<input type="text" id="entite_diff" class="form-control" name="entite" autocomplete="off" required>
                    					<label for="objet_diff">Objet de la diffusion :</label>
                    					<select id="objet_diff" name="objet" class="form-control" autocomplete="off" required>
                      						<option>diffusion</option>
                  							<option>validation</option>
                    					</select>
                    					<br>
                              <span id="error_mess_diff" style="font-style:italic;color:red;"></span>
                    					<div class="pull-right">
                      						<button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>
                  							<button id="add_diff_btn" type="button" class="btn btn-success">Ajouter</button>
                    					</div>
                  					</form>
                            
                				</div>
              				</div>
            			</div>
          			</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script type="text/javascript">

$(function (){
    $('body').tooltip({
      selector : "[data-tooltip=tooltip]",
      container : "body",
      trigger : 'hover'
    });
});

// Action lors du clic d'ajout d'intervenants
$("#add_interv_btn").on("click",function(e){
  var _name = $("#name_interv").val();
  var _email = $("#email_interv").val();
  var _entite = $("#entite_interv").val();
  var _resp_domain = $("#resp_domain_interv").val();
  var _token = $('input[name=_token]').val();
  var formData = {
    name:_name, email:_email,entite:_entite,resp_domain:_resp_domain, _token: _token
  };
  if(_name !== "" && _email !== "" && _entite !== "" && _resp_domain !== ""){
    $.ajax({
      type: 'post',
      url: '/admin/templates/intervenants/add',
      data: formData,
      success:function(result){
        var row = '<tr class="interv_'+result+'"><td>'+_entite+'</td><td>'+_resp_domain+'</td><td>'+_name+'</td><td><button type="button" class="btn btn-danger btn-xs" onclick="del_interv('+result+')" data-toggle="tooltip" data-placement="top" title="Supprimer"><i class="fa fa-trash"></i></button></td></tr>';
        // Cache l'ensemble du modal
        $("#table_interv tbody").append(row);
        $(".modal").hide();
        $(".autocomplete-no-suggestion").hide();
        $('.autocomplete-suggestions').hide();
        $(".modal-backdrop").hide();
        // Remise a 0 des inputs
        $("#name_interv").val("");
        $("#email_interv").val("");
        $("#entite_interv").val("");
        $("#resp_domain_interv").val("");
        // Affichage d'une notification
        swal({
          title: "Ajout",
          text: "L'intervenant a bien été ajouté",
          type: "success",
          confirmButtonText: "Fermer"
        }); 
        $('body').tooltip({
          selector : "[data-tooltip=tooltip]",
          container : "body",
          trigger : 'hover'
        }); 
      }
    });
  }
  else{
    $("#error_mess_interv").html("Tous les champs doivent être remplis !");
  }
});

// Action lors du clic d'ajout de diffusion
$("#add_diff_btn").on("click",function(e){
  var _name = $("#name_diff").val();
  var _entite = $("#entite_diff").val();
  var _objet = $("#objet_diff").val();

  var _token = $('input[name=_token]').val();
  var formData = {
    name:_name,entite:_entite,objet:_objet, _token: _token
  };
  if(_name !== "" && _entite !== "" && _objet !== ""){
    $.ajax({
      type: 'post',
      url: '/admin/templates/diffusion/add',
      data: formData,
      success:function(result){
        var row = '<tr class="diff_'+result+'"><td>'+_entite+'</td><td>'+_name+'</td><td>'+_objet+'</td><td><button type="button" class="btn btn-danger btn-xs" onclick="del_diff('+result+')" data-toggle="tooltip" data-placement="top" title="Supprimer"><i class="fa fa-trash"></i></button></td></tr>';
          // Cache l'ensemble du modal
        $("#table_diff tbody").append(row);
        $(".modal").hide();
        $(".autocomplete-no-suggestion").hide();
        $('.autocomplete-suggestions').hide();
        $(".modal-backdrop").hide();
        // Remise a 0 des inputs
        $("#name_diff").val("");
        $("#entite_diff").val("");
        $("#objet_diff").val("");
        // Affichage d'une notification
        swal({
          title: "Ajout",
          text: "La nouvelle diffusion a bien été ajouté",
          type: "success",
          confirmButtonText: "Fermer"
        });  
        $('body').tooltip({
          selector : "[data-tooltip=tooltip]",
          container : "body",
          trigger : 'hover'
        });
      }
    });
  }
  else{
     $("#error_mess_diff").html("Tous les champs doivent être remplis !");
  }
});

function del_interv(id){
	var _token = $('input[name=_token]').val();
  	var formData = {
    	_token: _token
  	};
	$.ajax({
		type:'post',
		data: formData,
		url:'/admin/templates/intervenants/del/'+id,
		success:function(result){
			console.log("delete interv : "+result);
			$(".interv_"+id).css("display","none");
		}
	});
}

function del_diff(id){
	var _token = $('input[name=_token]').val();
  	var formData = {
    	_token: _token
  	};
	$.ajax({
		type: 'post',
		data: formData,
		url: '/admin/templates/diffusion/del'+id,
		success:function(result){
			console.log("delete diff : "+result);
			$(".diff_"+id).css("display","none");
		}
	});
}

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.panel'	, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<div class="ui breadcrumb">
  <div class="active section"><i class="fa fa-refresh"></i> Retour d'experience</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="clearfix"></div>
<div class="row"> 
  <div class="col-md-12 col-sm-12 col-xs-12">
    <div class="x_panel">
      <div class="x_title">
        Retour d'experience
      </div>
      <div class="x_content">                        
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <button id="add_report" class="btn btn-success pull-right" data-toggle="modal" data-target="#modal_add_report"><i class="fa fa-plus"></i> Ajouter</button>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
              <div class="x_content">
                <table class="table table-bordered" id="exps_table">
                  <thead>
                    <tr>
                      <th style="text-align:center">#</th>
                      <th>Page</th>
                      <th>Type</th>
                      <th>Date report</th>
                      <th>Date souhaitée</th>
                      <th>Date prévue</th>
                      <th>Statut</th>
                      <th>Criticite</th>
                      <th>Options</th>
                    </tr>
                  </thead>
                  <tbody>
                    <!-- Insertion des reports de l'utilisateur courant-->
                    <?php $__currentLoopData = $exps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exp): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <tr>
                      <td style="text-align:center">
                        <button type="button" class="btn btn-info btn-xs comment_btn" id="comment_btn<?php echo e($exp->id); ?>" data-toggle="collapse" data-target="#comment<?php echo e($exp->id); ?>" class="accordion-toggle" onclick="show_comment(<?php echo e($exp->id); ?>)"><i class="fa fa-search"></i></button>
                      </td>
                      <td><?php echo e($exp->page); ?></td>
                      <td><?php echo e($exp->type); ?></td>
                      <!-- Mise en forme de la date de creation -->
                      <?php 
                        $created_at = explode(" ",$exp->created_at);
                      ?>
                      <td><?php echo e($created_at[0]); ?></td>
                      <td><?php echo e($exp->wished_at); ?></td>
                      <td><?php echo e($exp->planned_at); ?></td>
                      <td>
                        <!-- Condition pour afficher la bonne couleur de label -->
                        <?php 
                        if($exp->status == "Envoyé"){
                          $class_label = "btn-info";
                        }
                        elseif ($exp->status == "En cours") {
                          $class_label = "btn-warning"; 
                        }
                        else{
                          $class_label = "btn-success";
                        }
                        ?>
                        <label class="btn btn-xs <?php echo($class_label) ?>"><?php echo e($exp->status); ?></label>
                      </td>
                      <td>
                        <?php 
                        if($exp->criticite == "haute"){
                          $class_label = "btn-danger";
                        }
                        elseif ($exp->criticite == "moyenne") {
                          $class_label = "btn-warning"; 
                        }
                        else{
                          $class_label = "btn-success";
                        }
                        ?>
                        <label class="btn btn-xs <?php echo($class_label) ?>"><?php echo e($exp->criticite); ?></label>
                      </td>
                      <td>
                        <button type="button" class="btn btn-xs btn-warning" data-toggle="modal" data-target=".modal_edit_<?php echo e($exp->id); ?>"><i class="fa fa-pencil"></i></button>
                        <button type="button" class="btn btn-xs btn-danger" data-toggle="modal" data-target=".modal_del_<?php echo e($exp->id); ?>"><i class="fa fa-trash"></i></button>
                      </td>
                    </tr>
                    <tr>
                      <td colspan="9" class="hiddenRow" style="padding:0px">
                        <div class="accordion-body collapse" id="comment<?php echo e($exp->id); ?>"><?php echo e($exp->comment); ?></div>
                      </td>
                    </tr>
                    <!-- Modal de suppression -->
                    <div class="modal fade modal_del_<?php echo e($exp->id); ?>" tabindex="-1" role="dialog" aria-hidden="true">
                      <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                          <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
                            </button>
                            <h4 class="modal-title" id="myModalLabel">Suppresion d'un report</h4>
                          </div>
                          <div class="modal-body">
                            <p>
                              Etes-vous sûr de vouloir supprimer le report #<?php echo e($exp->id); ?> ?
                            </p>
                          </div>
                          <div class="modal-footer">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Annuler</button>
                            <button id="btn_delexp" type="button" class="btn btn-danger" onclick="deleteReport(<?php echo e($exp->id); ?>)"><i class="fa fa-trash" id="icon_delexp"></i><span id="text_submit_delexp">Supprimer report</span><img id="loader_submit_delexp" src="<?php echo e(asset('images/7.gif')); ?>" style="height:15px;width:15px;display:none"></button>
                            </div>
                        </div>
                      </div>
                    </div>
                    <!-- End modal de suppression -->
                    <!-- Modal de modification -->
                    <div class="modal fade modal_edit_<?php echo e($exp->id); ?>" tabindex="-1" role="dialog" aria-hidden="true">
                      <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                          <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
                            </button>
                            <h4 class="modal-title" id="myModalLabel">Modification d'un report</h4>
                          </div>
                          <div class="modal-body">
                            <div class="form_group">
                              <label class="form-label" for="page_report_edit">Page du bug :</label>
                              <select id="page_report_edit" name="page_report_edit" class="select2_group form-control" required>
                                <optgroup label="Tableau de bord">
                                  <option value="Tableau de bord">Tableau de bord</option>
                                </optgroup>
                                <optgroup label="Projet">
                                  <option value="Liste des DAH">Liste des DAH</option>
                                  <option value="Création d'un DAH">Creation d'un DAH</option>
                                </optgroup>
                                <optgroup label="Utilisateurs">
                                  <option value="Liste des utilisateurs">Liste des utilisateurs</option>
                                  <option value="Création d'un utilisateur">Creation d'un utilisateur</option>
                                  <option value="Administration utilisateur">Administration utilisateurs</option>
                                </optgroup>
                                <optgroup label="Roles">
                                  <option value="Liste des rôles">Liste des rôles</option>
                                  <option value="Création d'un rôle">Creation d'un rôle</option>
                                </optgroup>
                                <optgroup label="Liste des permissions">
                                  <option value="Liste des permissions">Liste des permissions</option>
                                </optgroup>
                                <optgroup label="Templates">
                                  <option value="Liste des templates">Liste des templates</option>
                                  <option value="Création d'un template">Creation d'un template</option>
                                  <option value="Fusion templates">Fusion templates</option>
                                  <option value="Utilisateurs génériques">Utilisateurs génériques</option>
                                </optgroup>
                              </select>
                            </div><br>
                            <div class="form_group">
                              <label class="type_report" for="type_report_edit">Type de report : </label>
                              <select id="type_report_edit" name="type_report_edit" class="select2_group form-control" required>
                                <?php if($exp->type == 'bug'): ?>
                                <option value="bug" selected>Bug</option>
                                <option value="evolution">Evolution</option>
                                <?php else: ?>
                                <option value="bug">Bug</option>
                                <option value="evolution" selected>Evolution</option>
                                <?php endif; ?>
                              </select>
                            </div><br>
                            <input type="hidden" name="_token" value="<?php echo csrf_token() ?>">
                            <div class="form-group">
                              <label class="control-label" for="comment_report_edit">Description :</label>
                              <textarea id="comment_report_edit" name="comment_report_edit" class="form-control" rows="5" required><?php echo e($exp->comment); ?></textarea>
                            </div><br>
                            <div class="form-group">
                              <label class="control-label" for="criticite_report_edit">Criticite :</label>
                              <select id="criticite_report_edit" name="criticite_report_edit" class="select2_group form-control" required>
                                <?php if($exp->criticite == 'basse'): ?>
                                  <option value="basse" selected>Basse</option>
                                  <option value="moyenne">Moyenne</option>
                                  <option value="haute">Haute</option>
                                <?php elseif($exp->criticite == 'moyenne'): ?>
                                  <option value="basse">Basse</option>
                                  <option value="moyenne" selected>Moyenne</option>
                                  <option value="haute">Haute</option>
                                <?php else: ?>
                                  <option value="basse">Basse</option>
                                  <option value="moyenne">Moyenne</option>
                                  <option value="haute" selected>Haute</option>
                                <?php endif; ?>
                              </select>
                            </div><br>
                            <div class="form-group">
                              <?php 
                                $wishdate = explode("-",$exp->wished_at);
                              ?>
                              <label for="wishdate_report_edit">Date souhaitée :</label><br>
                              <input type="text" id="wishdate_report_edit" class="form-control col-md-9 date-picker" name="wishdate_report_edit" autocomplete="off" value="<?php echo($wishdate[1].'/'.$wishdate[2].'/'.$wishdate[0]); ?>" required><br>
                            </div><br>
                          </div>
                          <div class="modal-footer">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Annuler</button>
                            <button id="btn_delexp" type="button" class="btn btn-success" onclick="editReport(<?php echo e($exp->id); ?>)"><span id="text_submit_editexp">Modifier report</span><img id="loader_submit_editexp" src="<?php echo e(asset('images/7.gif')); ?>" style="height:15px;width:15px;display:none"></button>
                          </div>
                        </div>
                      </div>
                    </div>
                    <!-- End modal de modification -->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
        <!-- Modal d'ajout d'un report -->
        <div id="modal_add_report" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
          <div class="modal-dialog modal-lg">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
                </button>
                <h4 class="modal-title" id="myModalLabel">Ajout d'un report</h4>
              </div>
              <div class="modal-body">
                <div class="row">
                  <div class="col-md-12" style="text-align:center">
                    <form method="POST">
                      <div class="form_group">
                        <label class="form-label" for="page_report">Page du bug :</label>
                        <select id="page_report" name="page_report" class="select2_group form-control" required>
                          <optgroup label="Tableau de bord">
                            <option value="Tableau de bord">Tableau de bord</option>
                          </optgroup>
                          <optgroup label="Projet">
                            <option value="Liste des DAH">Liste des DAH</option>
                            <option value="Création d'un DAH">Creation d'un DAH</option>
                          </optgroup>
                          <optgroup label="Utilisateurs">
                            <option value="Liste des utilisateurs">Liste des utilisateurs</option>
                            <option value="Création d'un utilisateur">Creation d'un utilisateur</option>
                            <option value="Administration utilisateur">Administration utilisateurs</option>
                          </optgroup>
                          <optgroup label="Roles">
                            <option value="Liste des rôles">Liste des rôles</option>
                            <option value="Création d'un rôle">Creation d'un rôle</option>
                          </optgroup>
                          <optgroup label="Liste des permissions">
                            <option value="Liste des permissions">Liste des permissions</option>
                          </optgroup>
                          <optgroup label="Templates">
                            <option value="Liste des templates">Liste des templates</option>
                            <option value="Création d'un template">Creation d'un template</option>
                            <option value="Fusion templates">Fusion templates</option>
                            <option value="Utilisateurs génériques">Utilisateurs génériques</option>
                          </optgroup>
                        </select>
                      </div><br>
                      <div class="form_group">
                        <label class="type_report" for="type_report">Type de report : </label>
                        <select id="type_report" name="type_report" class="select2_group form-control" required>
                          <option value="bug">Bug</option>
                          <option value="evolution">Evolution</option>
                        </select>
                      </div><br>
                      <input type="hidden" name="_token" value="<?php echo csrf_token() ?>">
                      <div class="form-group">
                        <label class="control-label" for="comment_report">Description :</label>
                        <textarea id="comment_report" name="comment_report" class="form-control" rows="5" required></textarea>
                      </div><br>
                      <div class="form-group">
                        <label class="control-label" for="criticite_report">Criticite :</label>
                        <select id="criticite_report" name="criticite_report" class="select2_group form-control" required>
                          <option value="basse">Basse</option>
                          <option value="moyenne">Moyenne</option>
                          <option value="haute">Haute</option>
                        </select>
                      </div><br>
                      <div class="form-group">
                        <label for="wishdate_report">Date souhaitée :</label><br>
                        <input type="text" id="wishdate_report" class="form-control col-md-9 date-picker" name="wishdate_report" autocomplete="off" required><br>
                      </div><br>
                      <div class="row pull-right">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>
                        <button id="submit_btn" type="submit" class="btn btn-success"><span id="text_submit">Envoyer report</span><img id="loader_submit" src="<?php echo e(asset('images/7.gif')); ?>" style="height:15px;width:15px;display:none"></button>        
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- Fin du modal d'ajout de report-->
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script type="text/javascript">
  $('.collapse').on('show.bs.collapse', function () {
    $('.collapse.in').collapse('hide');
  });

  // Afficher le loader quand ajout exp
  $('#submit_btn').on('click',function(){
    if($("#page_report").val() !== '' && $("#type_report").val() !== '' && $("#comment_report").val() !== '' && $("#criticite_report").val() !== '' && $("#wishdate_report").val() !== ''){
      // Cache le text et affiche le loader
      $("#text_submit").css("display","none");
      $("#loader_submit").css("display","block");
    }
  });

  // Pour voir le contenu du report
  function show_comment(id){
    if($('#comment_btn'+id).hasClass("btn-info")){
      $(".comment_btn").removeClass("btn-danger");
      $(".comment_btn").addClass("btn-info");
      $('#comment_btn'+id).removeClass("btn-info");
      $('#comment_btn'+id).addClass("btn-danger");
    }else{

      $('#comment_btn'+id).removeClass("btn-danger");
      $('#comment_btn'+id).addClass("btn-info");
    }
  }

  function deleteReport(id){
    var _token = $('input[name=_token]').val();
    var FormData = {id:id, _token:_token};
    $.ajax({
      type: 'post',
      data: FormData,
      url : 'experiences/delete',
      beforeSend: function(xhr){
        $("#text_submit_delexp").css("display","none");
        $("#icon_delexp").css("display","none");
        $("#loader_submit_delexp").css("display","block");
      },
      success: function(result){
        // Cache du modal
        $(".modal_del_"+id).hide();
        $(".modal-backdrop").hide();
        // Reinitialisation du bouton de suppression
        $("#text_submit_delexp").css("display","block");
        $("#icon_delexp").css("display","block");
        $("#loader_submit_delexp").css("display","none");
        // Message de confirmation de suppression
        swal({
          title: "Suppression",
          text: "Le report a bien été supprimé",
          type: "success",
          confirmButtonText: "Fermer"
        });
        $("#exps_table tbody").html(result);
      },
    });
  }

  function editReport(id){
    var _token = $('input[name=_token]').val();
    var page_report = $(".modal_edit_"+id+" #page_report_edit").val();
    var type_report = $(".modal_edit_"+id+" #type_report_edit").val();
    var comment_report = $(".modal_edit_"+id+" #comment_report_edit").val();
    var criticite_report = $(".modal_edit_"+id+" #criticite_report_edit").val();
    var wishdate_report = $(".modal_edit_"+id+" #wishdate_report_edit").val();
    console.log(page_report+"-"+type_report+"-"+comment_report+"-"+criticite_report+"-"+wishdate_report);
    var FormData = {id:id,page_report:page_report,type_report:type_report,comment_report:comment_report,criticite_report:criticite_report,wishdate_report:wishdate_report, _token:_token};
    $.ajax({
      type:'post',
      data: FormData,
      url: 'experiences/edit',
      beforeSend: function(xhr){
        $("#text_submit_editexp").css("display","none");
        $("#loader_submit_editexp").css("display","block");
      },
      success:function(result){
        // Cache du modal
        $(".modal_edit_"+id).hide();
        $(".modal-backdrop").hide();
        // Reinitialisation du bouton de modificiation
        $("#text_submit_editexp").css("display","block");
        $("#loader_submit_editexp").css("display","none");
        // Message de confirmation de suppression
        swal({
          title: "Modification",
          text: "Le report a bien été modifié",
          type: "success",
          confirmButtonText: "Fermer"
        });
        $("#exps_table tbody").html(result);
        $('#wishdate_report_edit').daterangepicker({
          singleDatePicker: true,
          calender_style: "picker_4"
        });
      },
      
    });
  }

  $(function() {
    // Reinitialisation des inputs du formulaire
    $("#comment_report").val("");
    $('#wishdate_report').daterangepicker({
      singleDatePicker: true,
      calender_style: "picker_4"
    });
    $('#wishdate_report_edit').daterangepicker({
      singleDatePicker: true,
      calender_style: "picker_4"
    });
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.panel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php use App\User; ?>

<?php $__env->startSection('breadcrumb'); ?>
<div class="ui breadcrumb">
	<i class="fa fa-edit"></i>
	<a class="section" href="<?php echo e(route('Laralum::projects')); ?>"><?php echo e(trans('laralum.projects_list')); ?></a>
	/ <?php echo e($projects->name); ?>

</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title', trans('laralum.projects_edit')); ?>
<?php $__env->startSection('icon', "book"); ?>
<?php $__env->startSection('subtitle', trans('laralum.projects_edit')); ?>
<?php $__env->startSection('content'); ?>
<div class="x_panel">
	<div class="x_content">
		<div class="" role="tabpanel" data-example-id="togglable-tabs">
			<ul id="myTab" class="nav nav-tabs bar_tabs" role="tablist">
				<li role="presentation" class="active"><a href="#tab_content1" id="home-tab" role="tab" data-toggle="tab" aria-expanded="true">Profil</a>
				</li>
				<li role="presentation" class=""><a href="#tab_content2" role="tab" id="profile-tab" data-toggle="tab" aria-expanded="false">Historique</a>
				</li>
			</ul>
			<div id="myTabContent" class="tab-content">
				<div role="tabpanel" class="tab-pane fade active in" id="tab_content1" aria-labelledby="home-tab">
					<div class="row">           
					</div>
					<section class="col-md-3">
						<div class="x_panel">
							<div id="nameProj" class="x_title" style="text-align:center;"><h3 class="red"><?php echo e($projects->name); ?></h3></div>
							<div class="x_content">
								<label class="red">Description :</label><br>
								<p style="font-style:italic;" id="projectdesc">
									<?php echo e($projects->description); ?>

								</p>
								<label class="red">Createur :</label><br>
								<span><a href="<?php echo e(route('Laralum::users_profile', ['id' => $projects->user_id])); ?>">
									<i class="fa fa-user"></i> <?php echo e(User::find($projects->user_id)->name); ?></a></span><br><br>
									<label class="red">Date de creation :</label><br>
									<span><?php echo e(date('d F Y', strtotime($projects->created_at))); ?></span><br><br>
									<label class="red">Date de dernière mise a jour :</label><br>
									<span><?php echo e(date('d F Y', strtotime($projects->updated_at))); ?></span><br><br>
									<label class="red">Nombre d'applications :</label><br>
									<span><?php echo(count($applications)) ?></span><br><br>
									<div class="ln_solid"></div>
									<?php if(Laralum::loggedInUser()->hasPermission('refarc.projects.edit')): ?>
									<div style="text-align: center"><button type="button" class="btn btn-warning" data-toggle="modal" data-target=".modaleditapp"><i class="fa fa-pencil"></i> Modifier</button></div>
									<?php endif; ?>
									<div id="modal_app" class="modal fade modaleditapp" tabindex="-1" role="dialog" aria-hidden="true">
										<div class="modal-dialog modal-lg">
											<div class="modal-content">
												<div class="modal-header" style="text-align: center">
													<div class="modal-title"><h2>Modification de <?php echo e($projects->name); ?></h2></div>
													<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">X</span>
													</div>
													<div class="modal-body">
														<form id="edit_app" data-parsley-validate="" class="form-horizontal form-label-left" novalidate="" method="POST">
															<div class="form-group">
																<label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Projet <span class="required">*</span>
																</label>
																<div class="col-md-6 col-sm-6 col-xs-12">
																	<input id="project_name" name="name" required="required" class="form-control col-md-7 col-xs-12" type="text" value="<?php echo e(ucfirst($projects->name)); ?>">
																</div>
															</div>
															<div class="form-group">
																<label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Description
																</label>
																<div class="col-md-6 col-sm-6 col-xs-12">
																	<textarea  id="project_desc" name="description" class="form-control" rows="3" style="width: 414px; height: 91px;"><?php echo e($projects->description); ?></textarea>
																</div>
															</div>                           
															<input type="hidden" name="_token" value="<?php echo csrf_token() ?>">
														</div>
														<div class="modal-footer">
															<button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>
															<button id="updateproj" type="button" class="btn btn-success">Modifier</button>
														</div>
													</form>
												</div>
											</div>
										</div>
									</div>
								</section>
								<section class="col-md-9">
									<div class="x_panel">
										<div class="x_title" style="color:#E74C3C;font-size:18px;">Liste des applications</div>
										<div class="x_content">
											<div class="row">
												<div class="col-md-6">
													<label class="btn btn-success pull-left"  data-toggle="modal" data-target=".modaladdapp"><i class="fa fa-plus"></i> Ajouter une application</label>
												</div>
												<div id="modal_app_add" class="modal fade modaladdapp" tabindex="-1" role="dialog" aria-hidden="true">
													<div class="modal-dialog modal-lg">
														<div class="modal-content">
															<form id="add_app" data-parsley-validate="" class="form-horizontal form-label-left" method="POST" action="../<?php echo e($projects->id); ?>/applications/create/create">
																<div class="modal-header" style="text-align: center">
																	<div class="modal-title">
																		<h2>Ajouter application</h2>
																	</div>
																	<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">X</span></button>
																</div>
																<div class="modal-body">
																	<div class="form-group">
																		<label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Nom <span class="required">*</span>
																		</label>
																		<div class="col-md-6 col-sm-6 col-xs-12">
																			<input id="name" name="nameapp" required class="form-control col-md-7 col-xs-12" type="text" value="">
																		</div>
																	</div>
                                                                    <div class="form-group">
                                                                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="type_doc">Type de document
                                                                        </label>
                                                                        <div class="col-md-6 col-sm-6 col-xs-12">
                                                                            <select id="type_doc" name="type_doc"class="select2_group form-control">
                                                                                <?php $__currentLoopData = $tplType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                                                <optgroup label="<?php echo e($type->type); ?>">
                                                                                    <?php $__currentLoopData = $templates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $template): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                                                        <?php if($type->id == $template->type && $template->valid == 1): ?>
                                                                                            <option value="<?php echo e($template->id); ?>"><?php echo e($type->type); ?> version : <?php echo e($template->version); ?></option>
                                                                                        <?php endif; ?>
                                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                                                                </optgroup>
                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                                                            </select>
                                                                        </div>
                                                                    </div>
																	<div class="form-group">
																		<label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Ecolience
																		</label>
																		<div class="col-md-6 col-sm-6 col-xs-12">
																			<input id="name" name="ecolience" class="form-control col-md-7 col-xs-12" type="text" value="" required>
																		</div>
																	</div>
																	<div class="form-group">
																		<label class="control-label col-md-3 col-sm-3 col-xs-12">IRT</label>
																		<div class="col-md-6 col-sm-6 col-xs-12">
																			<input id="tags_irt" type="text" class="tags form-control" value="" name="irt" />
																		</div>
																	</div>
																	<div class="form-group">
																		<label class="control-label col-md-3 col-sm-3 col-xs-12">Trigramme</label>
																		<div class="col-md-6 col-sm-6 col-xs-12">
																			<input id="tags_trigramme" type="text" class="tags form-control" value="" name="trigramme" />
																		</div>
																	</div>
																	<div class="form-group">
																		<label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Criticité STAMP 
																		</label>
																		<div class="col-md-6 col-sm-6 col-xs-12">
																			<select id="name" name="criticite_stamp" class="form-control col-md-7 col-xs-12" type="text" value="" required>
																				<option value="Non prioritaire">Non prioritaire</option>
																				<option value="Secondaire">Secondaire</option>
																				<option value="Critique">Critique</option>
																				<option value="Vitale">Vitale</option>
																			</select>
																		</div>
																	</div>
																	<div class="form-group">
																		<label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Sensible groupe 
																		</label>
																		<div class="col-md-6 col-sm-6 col-xs-12">
																			<!--<input id="name" name="sensible_groupe" class="form-control col-md-7 col-xs-12" type="text" value="" required>-->
																			<select id="sensible_groupe" name="sensible_groupe" class="form-control col-md-7 col-xs-12" required>
																				<option value="1">Oui</option>
																				<option value="0">Non</option>
																			</select>
																		</div>
																	</div>
																	<div class="form-group">
																		<label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Niveau de sensibilité fraude 
																		</label>
																		<div class="col-md-6 col-sm-6 col-xs-12">
																			<select id="niv_sensible_fraude" name="niv_sensible_fraude" class="form-control col-md-7 col-xs-12" required>
																				<option value="1">1</option>
																				<option value="2">2</option>
																				<option value="3">3</option>
																				<option value="4">4</option>																				
																			</select>
																		</div>
																	</div>
																	<div class="form-group">
																		<label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Demande client 
																		</label>
																		<div class="col-md-6 col-sm-6 col-xs-12">
																			<textarea  name="demande_client" class="form-control" rows="3" style="width: 414px; height: 91px;" required></textarea>
																		</div>
																	</div>
																	<input type="hidden" name="_token" value="<?php echo csrf_token() ?>">
																	<input type="hidden" name="project_id" value="<?php echo e($projects->id); ?>">
																	<p id="validation_msg"></p>
																</div>
																<div class="modal-footer">
																	<button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>
																	<button id="addapps" type="submit" class="btn btn-success">Ajouter</button>
																</div>
															</form>
														</div>
													</div>
												</div>
											</div><br>
											<div class="row">
												<?php $__currentLoopData = $applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
												<div class="animated flipInY col-lg-6 col-md-6 col-sm-12 col-xs-12">
													<a href="<?php echo e(route('Laralum::applications', ['id' => $projects->id, 'idApp' => $application->id])); ?>"><div class="tile-stats" style="border:1px solid #26B99A">
														<div class="icon"><i class="fa fa-pencil" style="color:#26B99A;"></i></div>
														<div class="count">0%</div>
														<h3><?php echo e(ucfirst($application->name)); ?></h3><br>
														<div class="progress">
															<div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div>
														</div>
													</a>
												</div>
											</div>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>                                      
										</div>
									</div>              
								</section>
							</div>
							<div role="tabpanel" class="tab-pane fade" id="tab_content2" aria-labelledby="profile-tab">
								<div class="col-md-12">
									<div class="row" style="text-align:center">
										<label style="font-size:24px">Historique</label>
									</div>
									<ul class="list-unstyled timeline">
										<?php $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hist): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
										<li>
											<div class="block">
												<div class="tags">
													<a href="" class="tag">
														<span>Modification</span>
													</a>
												</div>
												<div class="block_content">
													<h2 class="title">
														<?php if($hist->namefield == 'name'): ?>
														<a>Le nom du projet a été modifié</a>
														<?php elseif($hist->namefield == 'description'): ?>
														<a>La description du projet a été modifié</a>
														<?php else: ?>
														<a>Le statut a été modifié</a>
														<?php endif; ?>
													</h2>
													<div class="byline">
														<span><?php echo e(date('d/m/Y h:i', strtotime($hist->updated_at))); ?></span> par <a class="red"><b><?php echo e(ucfirst(User::find($hist->user_id)->name)); ?></b></a>
													</div>
												</div>
											</div>
										</li>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
										<li>
											<div class="block">
												<div class="tags">
													<a href="" class="tag">
														<span>Creation</span>
													</a>
												</div>
												<div class="block_content">
													<h2 class="title">
														<a>Le projet a été crée</a>
													</h2>
													<div class="byline">
														<span><?php echo e(date('d/m/Y', strtotime($projects->created_at))); ?></span> par <a><?php echo e(ucfirst(User::find($projects->user_id)->name)); ?></a>
													</div>
												</div>
											</div>
										</li>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<?php $__env->stopSection(); ?>
		<?php $__env->startSection('js'); ?>
		<script type="text/javascript">
			$("#updateproj").on('click', function(e) {
				$.ajax({
					type: 'get',
					url: "update?name="+$("#project_name").val()+"&description="+$("#project_desc").val()+"",
          	success: function(result) { // Je récupère la réponse du fichier PHP
          		$("#nameProj").html($("#project_name").val());
          		$("#projectdesc").html($("#project_desc").val());
          		$('#modal_app').modal('hide');
          		location.reload();
          		swal({
          			title: "Modification",
          			text: "Le DAH a bien été modifié",
          			type: "success",
          			confirmButtonText: "Fermer"
          		});    
          	}
          });
			});

		/*$("#addapps").on('click', function(e) {
			console.log($("#tags_1").val());
   	  /*$.ajax({
	      type: 'get',
	      url: "applications/create/create?idproject=<?php echo $projects->id ?>&nameapp="+$('input[name=nameapp]').val()+"&ecolience="+$('input[name=ecolience]').val()+"&irt="+$('input[name=irt]').val()+"&trigramme="+$('input[name=trigramme]').val()+"&criticite_stamp="+$('select[name=criticite_stamp]').val()+"&sensible_groupe="+$('input[name=sensible_groupe]').val()+"&niv_sensible_fraude="+$('input[name=niv_sensible_fraude]').val()+"&demande_client="+$('textarea[name=demande_client]').val()+"",
        success: function(result) { // Je récupère la réponse du fichier PHP
          $("#nameProj").html($("#project_name").val());
          $("#projectdesc").html($("#project_desc").val());
          $('#modal_app_add').modal('hide');
          location.reload();
          swal({
            title: "Création",
            text: "L'application a bien été crée",
            type: "success",
            confirmButtonText: "Fermer"
          });      
        }
      });
  });*/
</script>
<script>
	function onAddTag(tag) {
		alert("Added a tag: " + tag);
	}

	function onRemoveTag(tag) {
		alert("Removed a tag: " + tag);
	}

	function onChangeTag(input, tag) {
		alert("Changed a tag: " + tag);
	}

	$(document).ready(function() {
		$('#tags_irt').tagsInput({
			width: 'auto'
		});
		$('#tags_trigramme').tagsInput({
			width: 'auto'
		});
		$("#tags_irt_tagsinput").css("height","50px");
		$("#tags_irt_tagsinput").css("min-height","50px");
		$("#tags_trigramme_tagsinput").css("height","50px");
		$("#tags_trigramme_tagsinput").css("min-height","50px");
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.panel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
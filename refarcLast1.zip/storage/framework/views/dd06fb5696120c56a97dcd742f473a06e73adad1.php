
<?php $__env->startSection('breadcrumb'); ?>
<div class="ui breadcrumb">
    <i class="fa fa-plus"></i>
    <a class="section" href="<?php echo e(route('Laralum::projects')); ?>"><?php echo e(trans('laralum.user_list')); ?></a>
    / <strong><?php echo e(trans('laralum.users_create_title')); ?></strong>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title', trans('laralum.users_create_title')); ?>
<?php $__env->startSection('icon', "plus"); ?>
<?php $__env->startSection('subtitle', trans('laralum.users_create_subtitle')); ?>
<?php $__env->startSection('content'); ?>
<div class="clearfix"></div>
  <div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
          <div class="x_title">
            <h2> </h2>
            <ul class="nav navbar-right panel_toolbox">
            </ul>
            <div class="clearfix"></div>
        </div>
        <div class="x_content">
          <br>
          <form class="form-horizontal form-label-left" method="POST">
            <div class="form-group">
              <label class="control-label col-md-3 col-sm-3 col-xs-3">Nom Prénom <span class="required">*</span></label>
              <div class="col-md-9 col-sm-9 col-xs-9">
                <input class="form-control  has-feedback-left" type="text" name="name" id="name" value="" required>                 
                <span class="fa fa-user form-control-feedback left" aria-hidden="true"></span>
              </div>
            </div>
            <div class="form-group">
              <label class="control-label col-md-3 col-sm-3 col-xs-3">Email <span class="required">*</span></label>
              <div class="col-md-9 col-sm-9 col-xs-9">
                <input class="form-control has-feedback-left" name="email" id="email" type="text" value="" required>
                <span class="fa fa-envelope form-control-feedback left" aria-hidden="true"></span>
              </div>
            </div>
            <div class="form-group">
              <label class="control-label col-md-3 col-sm-3 col-xs-3">Mot de passe <span class="required">*</span></label>
              <div class="col-md-9 col-sm-9 col-xs-9">
                <input class="form-control has-feedback-left" id="password" name="password" value="" type="password" value="" required>
                <span class="fa fa-lock form-control-feedback left" aria-hidden="true"></span>
              </div>
            </div>
            <div class="form-group">
              <label class="control-label col-md-3 col-sm-3 col-xs-3">Confirmer mot de passe <span class="required">*</span></label>
              <div class="col-md-9 col-sm-9 col-xs-9">
                <input  class="form-control has-feedback-left" id="password_confirmation" name="password_confirmation"  value="" type="password" value="" required>
                <span class="fa fa-lock form-control-feedback left" aria-hidden="true"></span>
              </div>
            </div>
            <div class="form-group">
              <label class="control-label col-md-3 col-sm-3 col-xs-12">Roles</label>
              <div class="col-md-9 col-sm-9 col-xs-12">
                <div class="" ss="">
                  <ul class="to_do">
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                      <?php if(!$role->su): ?>
                      <li>
                        <p>
                          <input type="checkbox" class="flat" name="<?php echo e($role->id); ?>"> <?php echo e($role->name); ?>

                        </p>
                      </li>
                      <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                  </ul>
                </div>
              </div>
            </div>
            <div class="form-group">
              <label class="control-label col-md-3 col-sm-3 col-xs-12"><?php echo e(trans('laralum.users_activate_user')); ?></label>
              <div class="col-md-3 col-sm-3 col-xs-12">
                <div class="">
                  <label>
                    <input name="active" id="active" type="checkbox" class="js-switch"/>
                  </label>
                </div>                                                
              </div>
            </div>
            <div class="form-group">
              <label class="control-label col-md-3 col-sm-3 col-xs-12"><?php echo e(trans('laralum.users_send_activation')); ?></label>
              <div class="col-md-3 col-sm-3 col-xs-12">
                <div class="">
                  <label>
                    <input name="send_activation" id="send_activation" type="checkbox" class="js-switch"/>
                  </label>
                </div>                                                
              </div>
            </div>
            <div class="form-group">
              <label class="control-label col-md-3 col-sm-3 col-xs-12"><?php echo e(trans('laralum.users_welcome_email')); ?></label>
              <div class="col-md-3 col-sm-3 col-xs-12">
                <div class="">
                  <label>
                    <input name="mail_checkbox" id="mail_checkbox" type="checkbox" class="js-switch"/>
                  </label>
                </div>                                                
              </div>
            </div>
            <div class="ln_solid"></div>
            <div class="form-group">
              <div class="col-md-9 col-md-offset-9">
                <?php echo e(csrf_field()); ?>

                <input class="form-control" type="hidden" name="country_code" id="country_code" value="FR">
                <a href="<?php echo e(route('Laralum::users')); ?>"><button type="button" class="btn btn-primary">Liste des utilisateurs</button></a>
                <button type="submit" class="btn btn-success">Valider</button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
    $('#active').change(function(){
        if(this.checked) {
            $('#send_activation').prop('checked', false);
        }
    });
    $('#send_activation').change(function(){
        if(this.checked) {
            $('#active').prop('checked', false);
        }
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.panel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
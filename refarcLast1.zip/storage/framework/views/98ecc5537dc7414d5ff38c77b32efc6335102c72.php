
<?php $__env->startSection('breadcrumb'); ?>
<div class="ui breadcrumb">
  <div class="active section"><i class="fa fa-list"></i> <?php echo e(trans('laralum.permissions_title')); ?></div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title', trans('laralum.permissions_title')); ?>
<?php $__env->startSection('icon', "lightning"); ?>
<?php $__env->startSection('subtitle', trans('laralum.permissions_subtitle')); ?>
<?php $__env->startSection('content'); ?>
<div class="row"> 

  <div class="col-md-12 col-sm-12 col-xs-12">
    <div class="x_panel">
      <div class="x_content">                    
        <table id="datatable-buttons" class="table table-striped table-bordered">
          <thead>
            <tr>
              <th><?php echo e(trans('laralum.name')); ?></th>
              <th><?php echo e(trans('laralum.description')); ?></th>
              <th><?php echo e(trans('laralum.slug')); ?></th>
              <th><?php echo e(trans('laralum.roles')); ?></th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perm): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <tr>
              <td>
                <div class="text">
                  <?php echo e(Laralum::permissionName($perm->slug)); ?>

                </div>          
              </td>
              <td>
                <div class="text">
                  <?php echo e(Laralum::permissionDescription($perm->slug)); ?>

                </div>
              </td>
              <td>
                <div class="text">
                  <?php echo e($perm->slug); ?>

                </div>
              </td>              
              <td>
                <?php echo e(trans('laralum.permissions_roles', ['number' => count($perm->roles)])); ?>

              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
  <?php $__env->stopSection(); ?>
  <?php $__env->startSection('js'); ?>
  <script type="text/javascript">
    $(document).ready(function() {
      var handleDataTableButtons = function() {
        if ($("#datatable-buttons").length) {
          $("#datatable-buttons").DataTable({
            dom: "Bfrtip",
            buttons: [
            {
              extend: "copy",
              className: "btn-sm"
            },
            {
              extend: "csv",
              className: "btn-sm"
            },
            {
              extend: "excel",
              className: "btn-sm"
            },
            {
              extend: "pdfHtml5",
              className: "btn-sm"
            },
            {
              extend: "print",
              className: "btn-sm"
            },
            ],
            
          });
        }
      };

      TableManageButtons = function() {
        "use strict";
        return {
          init: function() {
            handleDataTableButtons();
          }
        };
      }();


      $('#datatable-responsive').DataTable();        

      TableManageButtons.init(); 

      // Supprime les boutons d'export et le champ rechercher
      $("#datatable-buttons_filter").css("display","none");
      $(".dt-buttons").css("display","none");

    });       
  </script>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.panel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php
	use App\User;
	use App\TypeTpl;
	?>
	
	<?php $__env->startSection('breadcrumb'); ?>
	<div class="ui breadcrumb">
		<i class="fa fa-newspaper-o"></i>
		<a class="section" href="">Modification</a>
		
	</div>
	<?php $__env->stopSection(); ?>
	<?php $__env->startSection('content'); ?>
	<div class="clearfix"></div>	
	<?php if(Laralum::loggedInUser()->hasPermission('refarc.templates.edit') && $tpl->nbapps == 0 && $tpl->valid == 0): ?>
	<input id="auth" type="hidden" value="1">
	<?php else: ?>
	<input id="auth" type="hidden" value="0">
	<?php endif; ?>
	<div class="row">
		<div class="col-md-12 col-sm-12 col-xs-12">
			<div class="x_panel">
				<div class="x_content">
					<ul class="stats-overview">
				      <li>
				          <span class="name"> Type document </span>
				          <div class="value text-success" id="vers"><img src="../../../images/ajax-loader.gif"></div>
				        </li>
				        <li>
				          <span class="name"> Version </span>
				          <div id="Ver" class="value text-success" id="vers"><img src="../../../images/ajax-loader.gif"></div>
				        </li>
				        
				        <li class="hidden-phone">
				          <span class="name"> Dernière modification </span>
				          <span id="dm" class="value text-success"> <img src="../../../images/ajax-loader.gif"></span>
				        </li>
				      </ul>
			      <br>
				</div>
			</div>
		</div>
	</div>

	<div id="tpl" class="row">
	</div>
	<?php $__env->stopSection(); ?>
	<?php $__env->startSection('js'); ?>	
	<script type="text/javascript">
	var auth = $('#auth').val();	
	//$.ready(function(){
		$.ajax({
			type: 'get',
			url: 'tpls',
			success: function(result) {
				$("#loaders").css('display', 'none');
				$("#tpl").hide().html(result).fadeIn('slow');
				$("#vers").hide().html('<?php echo e(TypeTpl::find($tpl->type)->type); ?>').fadeIn('slow');
				$("#Ver").hide().html('<?php echo e($tpl->version); ?>').fadeIn('slow');
				$("#dm").hide().html('<?php echo e(date('d/m/Y', strtotime($tpl->updated_at))); ?>').fadeIn('slow');
				
				if (auth == 1) {
					var readO = 0;
				} else {
					var readO = 1;
				}				
				tinyMCE.init({
						mode : "specific_textareas",
						editor_selector : "mceEditorAdd",
						readonly : readO,
						autoresize_overflow_padding: 10,
						//theme: 'modern',						
						plugins: ['image', 'table', 'textcolor', 'colorpicker', 'fullscreen'],
						toolbar1: 'undo redo | styleselect | bold italic underline forecolor backcolor | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image | preview media | responsivefilemanager ',
						image_advtab: true,
						relative_urls: false,

						filemanager_title:"Dépot d'images",
						filemanager_crossdomain: false,
            			external_filemanager_path:"../../../templates/",
            			external_plugins: { "filemanager" : "/templates/plugin.min.js"},                       			
        			});
				$('span[id^="title_"]').each(function () {
					var el = (this.id).split('_');					
					tinyMCE.init({
						mode : "specific_textareas",
						editor_selector : "mceEditor_"+el[1],
						readonly : readO,						
						autoresize_overflow_padding: 10,
						//theme: 'modern',
						plugins: ['image', 'table', 'textcolor', 'colorpicker', 'fullscreen'],
						toolbar1: 'undo redo | styleselect | bold italic underline forecolor backcolor | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image | preview media | responsivefilemanager ',
						image_advtab: true,
						relative_urls: false,

						filemanager_title:"Dépot d'images",
						filemanager_crossdomain: false,
            			external_filemanager_path:"../../../templates/",
            			external_plugins: { "filemanager" : "/templates/plugin.min.js"},                       			
        			});
				});		  
			}
		});	
	//});
	function addParagraph(id, parag, niv, id_template) {
        var _text = $("#text_parent_add_"+id).val();
        var _text_stat = tinyMCE.get('text_stat_parent_add_'+id).getContent();
        var _numPrg = parag;
        var id_template = id_template;
        var _token = $('input[name=_token]').val();
        var formData = {
            id:id, text:_text, text_stat:_text_stat, niv:niv, numPrg:parag, _token: _token, id_template:id_template
        };
        var url = 'createParagraph';
        if(_text) {
            $("#modal_add_"+id).modal('hide');
            $("#loaders").css('display', '');
            $(".row").hide();
            $.ajax({
            type: 'post',
            data : formData,
            url: url,
            success: function(result) {                
                $.ajax({
                type: 'get',
                url: 'tpls',
                success: function(result) {
                    $("#loaders").css('display', 'none');
                    $("#tpl").hide().html(result).fadeIn('slow');
                    $(function () {
                        $.loadScript('../../../../laralum_public/js/tinymce/tinymce.min.js', {'charset': 'UTF-8'}, function () {
                            tinyMCE.init({
									mode : "specific_textareas",
									editor_selector : "mceEditorAdd",
									readonly : 0,
									autoresize_overflow_padding: 10,
									//theme: 'modern',
									plugins: ['image', 'table', 'textcolor', 'colorpicker', 'fullscreen'],
									toolbar1: 'undo redo | styleselect | bold italic underline forecolor backcolor | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image | preview media | responsivefilemanager ',
									image_advtab: true,
									relative_urls: false,

									filemanager_title:"Dépot d'images",
									filemanager_crossdomain: false,
									external_filemanager_path:"../../../templates/",
									external_plugins: { "filemanager" : "/templates/plugin.min.js"},                       			
								});
							$('span[id^="title_"]').each(function () {
								var el = (this.id).split('_');					
								tinyMCE.init({
									mode : "specific_textareas",
									editor_selector : "mceEditor_"+el[1],
									readonly : 0,
									autoresize_overflow_padding: 10,
									//theme: 'modern',
									plugins: ['image', 'table', 'textcolor', 'colorpicker', 'fullscreen'],
									toolbar1: 'undo redo | styleselect | bold italic underline forecolor backcolor | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image | preview media | responsivefilemanager ',
									image_advtab: true,
									relative_urls: false,

									filemanager_title:"Dépot d'images",
									filemanager_crossdomain: false,
									external_filemanager_path:"../../../templates/",
									external_plugins: { "filemanager" : "/templates/plugin.min.js"},                       			
								});
							});	
                       });
                    });    
                    swal({
                        title: "Ajout",
                        text: "La nouvelle partie "+ _text +" a bien été ajoutée",
                        type: "success",
                        confirmButtonText: "Fermer"
                    });
                }
            });
            }
        });
        }
		}
		
		function savetpl(id, obj) {
        var formData = '';
        var url = '';
        var _token = $('input[name=_token]').val();
        $("#modal_"+id).modal('hide');

        if (obj == 'title') {
            var text = $('#text_parent_'+id).val();
            var text_stat = tinyMCE.get('text_statFirsNiv_'+id).getContent();
            var formData = {id:id, text_stat:text_stat, text:text, _token: _token};
            url = "update";
            $("#title_"+id).html('<img src="../../../images/ajax-loader.gif">');
        } else {
            var title = $('#text_parent_'+id).val();
            var text = tinyMCE.get('text_statFirsNiv_'+id).getContent();
            var formData = {id:id, text_stat:text,text:title, _token: _token};
            url = "update";
            $("#loader_"+id).html('<img src="../../../images/ajax-loader.gif"> Modifier...');
        }                
        $.ajax({
            type: 'post',
            data : formData,
            url: url,
            success: function(result) {
                if (obj == 'title') {
                    $("#title_"+id).html(text);
                } else {
                    $("#loader_"+id).html('');
                }
				swal({
                title: 'Enregistrement des données',
                text: 'Les données sont bien enregistrées',
                type: "success",
                confirmButtonText: "Fermer"
            });
            }
        });
    }
		// Alert delete    
     function deletPrg(id, niv, numPrg, parentId)
     {
         swal({
          title: "Suppression",
          text: "Etes-vous sur de vouloir supprimer le paragraphe "+numPrg,
          type: "warning",
          showCancelButton: true,
          confirmButtonClass: "btn-danger",
          confirmButtonText: "Supprimer",
          closeOnConfirm: true
        },
        function(){
            var _token = $('input[name=_token]').val();
            var formData = {
                id:id, niv:niv, numPrg:numPrg, parentId:parentId, _token: _token
            };
            var url = 'deleteParagraph';
            $.ajax({
                type: 'post',
                data : formData,
                url: url,
                success: function(result) {
                    $.ajax({
                        type: 'get',
                        url: 'tpls',
                        success: function(result) {
                            $("#loaders").css('display', 'none');
                            $("#tpl").hide().html(result).fadeIn('slow');
                            $(function () {
                                $.loadScript('../../../../laralum_public/js/tinymce/tinymce.min.js', {'charset': 'UTF-8'}, function () {
                                    tinyMCE.init({
										mode : "specific_textareas",
										editor_selector : "mceEditorAdd",
										readonly : 0,
										autoresize_overflow_padding: 10,
										//theme: 'modern',
										plugins: ['image', 'table', 'textcolor', 'colorpicker', 'fullscreen'],
										toolbar1: 'undo redo | styleselect | bold italic underline forecolor backcolor | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image | preview media | responsivefilemanager ',
										image_advtab: true,
										relative_urls: false,

										filemanager_title:"Dépot d'images",
										filemanager_crossdomain: false,
										external_filemanager_path:"../../../templates/",
										external_plugins: { "filemanager" : "/templates/plugin.min.js"},                       			
									});
								$('span[id^="title_"]').each(function () {
									var el = (this.id).split('_');					
									tinyMCE.init({
										mode : "specific_textareas",
										editor_selector : "mceEditor_"+el[1],
										readonly : 0,
										autoresize_overflow_padding: 10,
										//theme: 'modern',
										plugins: ['image', 'table', 'textcolor', 'colorpicker', 'fullscreen'],
										toolbar1: 'undo redo | styleselect | bold italic underline forecolor backcolor | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image | preview media | responsivefilemanager ',
										image_advtab: true,
										relative_urls: false,

										filemanager_title:"Dépot d'images",
										filemanager_crossdomain: false,
										external_filemanager_path:"../../../templates/",
										external_plugins: { "filemanager" : "/templates/plugin.min.js"},                       			
									});
								});		  
                                });
                            });                    
                        }
                    });
                    swal("", "Le patragraphe a bien été supprimer.", "success");
                }
            });
        });
     }
	 
	 function addNewParagraph(id) {
    if ($('#text_new').val() == '') {
        $("#error_name_msg").html('Veuillez entrer un nom de partie !');
        $("#error_name_msg").css('display', 'block');
        return
    }
    var _text = $("#text_new").val();
    var _text_stat = tinyMCE.get('prgN').getContent();
    var _token = $('input[name=_token]').val();
    var formData = {
        id: id, text: _text, text_stat: _text_stat, _token: _token
    };
    var url = 'createNewParagraph';
    if (_text) {
        $("#modal_add_cmp").modal('hide');
        $("#loaders").css('display', '');
        //$("#tpl").hide().fadeIn('slow');
        $.ajax({
            type: 'post',
            data: formData,
            url: url,
            success: function (result) {
                $.ajax({
                    type: 'get',
                    url: 'tpls',
                    success: function (result) {
                        $("#loaders").css('display', 'none');
                        $("#tpl").hide().html(result).fadeIn('slow');
                        $(function () {
                                $.loadScript('../../../../laralum_public/js/tinymce/tinymce.min.js', {'charset': 'UTF-8'}, function () {
                                    tinyMCE.init({
										mode : "specific_textareas",
										editor_selector : "mceEditorAdd",
										readonly : 0,
										autoresize_overflow_padding: 10,
										//theme: 'modern',
										plugins: ['image', 'table', 'textcolor', 'colorpicker', 'fullscreen'],
										toolbar1: 'undo redo | styleselect | bold italic underline forecolor backcolor | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image | preview media | responsivefilemanager ',
										image_advtab: true,
										relative_urls: false,

										filemanager_title:"Dépot d'images",
										filemanager_crossdomain: false,
										external_filemanager_path:"<?php echo str_finish(asset('/templates'),'/'); ?>",
										external_plugins: { "filemanager" : "<?php echo str_finish(asset('/templates'),'/'); ?>/plugin.min.js"},                  			
									});
								$('span[id^="title_"]').each(function () {
									var el = (this.id).split('_');					
									tinyMCE.init({
										mode : "specific_textareas",
										editor_selector : "mceEditor_"+el[1],
										readonly : 0,
										autoresize_overflow_padding: 10,
										//theme: 'modern',
										plugins: ['image', 'table', 'textcolor', 'colorpicker', 'fullscreen'],
										toolbar1: 'undo redo | styleselect | bold italic underline forecolor backcolor | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image | preview media | responsivefilemanager ',
										image_advtab: true,
										relative_urls: false,

										filemanager_title:"Dépot d'images",
										filemanager_crossdomain: false,
										external_filemanager_path:"../../../templates/",
										external_plugins: { "filemanager" : "/templates/plugin.min.js"},                       			
									});
								});		  
                                });
                            }); 
                        swal({
                            title: "Ajout",
                            text: "La nouvelle partie " + _text + " a bien été ajoutée",
                            type: "success",
                            confirmButtonText: "Fermer"
                        });
                    }
                });
            }
        });
    }
}
	</script>
	<?php $__env->stopSection(); ?>
	
<?php echo $__env->make('layouts.admin.panel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
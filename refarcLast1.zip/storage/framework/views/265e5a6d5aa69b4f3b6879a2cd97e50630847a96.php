<?php $__env->startSection('breadcrumb'); ?>
<div class="ui breadcrumb">
  <div class="active section"><i class="fa fa-users"></i> <?php echo e(trans('laralum.user_list')); ?></div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title', trans('laralum.user_list')); ?>
<?php $__env->startSection('icon', "users"); ?>
<?php $__env->startSection('subtitle', trans('laralum.users_subtitle')); ?>
<?php $__env->startSection('content'); ?>

<div class="clearfix"></div>
<div class="row">             
  

  <div class="clearfix"></div>
  <div class="row"> 

    <div class="col-md-12 col-sm-12 col-xs-12">
      <div class="x_panel">
        <div class="x_title">
          <h2><?php echo e(trans('laralum.user_list')); ?></h2>
          <div class="clearfix"></div>
        </div>
        <div class="x_content">                    
          <table id="datatable-buttons" class="table table-striped table-bordered">
            <thead>
              <tr>
                <th><?php echo e(trans('laralum.name')); ?></th>
                <th><?php echo e(trans('laralum.email')); ?></th>
		<th>Role(s)</th>
                <th>Date de création</th>
                <th><?php echo e(trans('laralum.options')); ?></th>
              </tr>
            </thead>
            <tbody>
              <?php $countries = Laralum::countries(); ?>
              <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <tr>
                  <td>
                    <div class="text">
                        <a href="<?php echo e(route('Laralum::users_profile', ['id' => $user->id])); ?>"><?php echo e($user->name); ?></a>
                        <?php if($user->su): ?>
                          <div class="ui red tiny left pointing basic label pop" data-title="<?php echo e(trans('laralum.super_user')); ?>" data-variation="wide" data-content="<?php echo e(trans('laralum.super_user_desc')); ?>" data-position="top center" ><?php echo e(trans('laralum.super_user')); ?></div>
                        <?php endif; ?>
                    </div>         
                  </td>
                  <td>
                    <?php if($user->banned): ?>
                      <i data-position="top center" data-content="<?php echo e(trans('laralum.users_status_banned')); ?>" class="pop red close icon"></i>
                    <?php elseif(!$user->active): ?>
                      <i data-position="top center" data-content="<?php echo e(trans('laralum.users_status_unactive')); ?>" class="pop orange warning icon"></i>
                    <?php else: ?>
                      <i data-position="top center" data-content="<?php echo e(trans('laralum.users_status_ok')); ?>" class="pop green checkmark icon"></i>
                    <?php endif; ?>
                    <?php echo e($user->email); ?>

                  </td>
		  <td>
                    <!-- Boucle pour afficher les roles de chaque utilisateur -->
                    <?php $__currentLoopData = $roles_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role_user): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                      <!-- Si le role correspond au user courrant -->
                      <?php if($role_user->user_id == $user->id): ?>
                        <!-- Parcours de tous les roles pour afficher les noms et pas les id-->
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                          <!-- Si le role_user et le role correspondent-->
                          <?php if($role_user->role_id == $role->id): ?>
                            <!-- Si le role est le role admin -->
                            <?php if($role->su): ?>
                            <label class="label label-danger"><?php echo e(ucfirst(strtolower($role->name))); ?></label>
                            <?php else: ?>
                            <label class="label label-info"><?php echo e(ucfirst(strtolower($role->name))); ?></label>
                            <?php endif; ?>
                          <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                      <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                  </td>
                  <td>
                    <i class="fa fa-calendar"></i> <?php echo e(date('d/m/Y', strtotime($user->created_at))); ?>

                  </td>
                  <td style="text-align:center;">
                    <!-- Test droit modification utilisateur -->
                    <?php if(Laralum::permissionToAccess('refarc.users.edit')): ?>
                      <?php if(!$user->su): ?>
                        <a href="<?php echo e(route('Laralum::users_edit', ['id' => $user->id])); ?>" class="item">
                          <button type="button" class="btn btn-warning btn-xs" data-tooltip="tooltip" data-placement="top" title="Modifier l'utilisateur"><i class="fa fa-pencil"></i></button>
                        </a>
                      <?php else: ?>
                        <button type="button" class="btn btn-default btn-xs" data-tooltip="tooltip" data-placement="top" title="Modification impossible"><i class="fa fa-close"></i></button>
                      <?php endif; ?>
                    <?php else: ?>
                        <button type="button" class="btn btn-default btn-xs" data-tooltip="tooltip" data-placement="top" title="Modification impossible"><i class="fa fa-close"></i></button>
                    <?php endif; ?>
                    <!-- Test droit suppression utilisateur -->
                    <?php if(Laralum::permissionToAccess('refarc.users.delete')): ?>
                      <?php if(!$user->su): ?>
                        <a href="#" class="item" data-toggle="modal" data-target=".modal-<?php echo e($user->id); ?>">
                          <button type="button" class="btn btn-danger btn-xs" data-tooltip="tooltip" data-placement="top" title="Supprimer l'utilisateur"><i class="fa fa-trash"></i></button>
                        </a>
                      <?php else: ?>
                        <button type="button" class="btn btn-default btn-xs" data-tooltip="tooltip" data-placement="top" title="Suppression impossible"><i class="fa fa-close"></i></button>
                      <?php endif; ?>
                    <?php else: ?>
                      <button type="button" class="btn btn-default btn-xs" data-tooltip="tooltip" data-placement="top" title="Suppression impossible"><i class="fa fa-close"></i></button>
                    <?php endif; ?>
                  </td>                                       
                </tr>
                <div class="modal fade modal-<?php echo e($user->id); ?>" tabindex="-1" role="dialog" aria-hidden="true">
                  <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                      <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
                        </button>
                        <h4 class="modal-title" id="myModalLabel">Suppression d'un utilisateur</h4>
                       </div>
                        <div class="modal-body">
                          <p>Souhaitez-vous vraiment supprimer l'utilisateur "<?php echo e($user->name); ?>" ?</p>
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>
                          <a href="<?php echo e(route('Laralum::users_delete',['id' => $user->id])); ?>"><button type="button" class="btn btn-danger"><i class="fa fa-trash"></i> Supprimer</button></a>
                        </div>
                    </div>
                  </div>
                </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script type="text/javascript">
  $(document).ready(function() {
    var handleDataTableButtons = function() {
      if ($("#datatable-buttons").length) {
        $("#datatable-buttons").DataTable({
          dom: "Bfrtip",
          buttons: [
          {
            extend: "copy",
            className: "btn-sm"
          },
          {
            extend: "csv",
            className: "btn-sm"
          },
          {
            extend: "excel",
            className: "btn-sm"
          },
          {
            extend: "pdfHtml5",
            className: "btn-sm"
          },
          {
            extend: "print",
            className: "btn-sm"
          },
          ],
          //responsive: true
        });
      }
    };

    TableManageButtons = function() {
      "use strict";
      return {
        init: function() {
          handleDataTableButtons();
        }
      };
    }();
    TableManageButtons.init(); 
    $("#datatable-buttons_filter input").css("padding-top","0px");
    $("#datatable-buttons_filter input").css("padding-bottom","0px");

    $('body').tooltip({
      selector : "[data-tooltip=tooltip]",
      container : "body",
      trigger : 'hover'
    });
  });       
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.panel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
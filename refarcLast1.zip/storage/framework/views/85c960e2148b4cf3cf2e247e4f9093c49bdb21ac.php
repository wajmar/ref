
<?php $__env->startSection('breadcrumb'); ?>
<div class="ui breadcrumb">
  <i class="fa fa-cogs"></i>
    <strong><?php echo e(trans('laralum.users_settings')); ?></strong>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title', trans('laralum.users_settings_title')); ?>
<?php $__env->startSection('icon', "options"); ?>
<?php $__env->startSection('subtitle', trans('laralum.users_settings_subtitle')); ?>
<?php $__env->startSection('content'); ?>
<div class="x_panel">
  <div class="x_content">
    <br>
    <form id="edit_project" data-parsley-validate="" class="form-horizontal form-label-left" novalidate="" method="POST">
        <?php echo e(csrf_field()); ?>

      <div class="form-group">
        <label class="control-label col-md-3 col-sm-3 col-xs-12">Role par défaut</label>
        <div class="col-md-3 col-sm-3 col-xs-12">
          <select name="default_role" class="select2_single form-control" tabindex="-1">
            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <option <?php if($rows->default_role == $role->id){ echo "selected"; } ?> value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>          
        </select>
    </div>
</div>
<!--<div class="form-group">
<label class="control-label col-md-3 col-sm-3 col-xs-12">Location</label>
    <div class="col-md-3 col-sm-3 col-xs-12">
      <div class="">
        <label>
          <input name="location" type="checkbox" class="js-switch" <?php if($rows->location){ echo "checked"; } ?>/>
      </label>
  </div>                                                
</div>
</div>-->
<div class="form-group">
    <label class="control-label col-md-3 col-sm-3 col-xs-12">Autoriser l'inscription</label>
    <div class="col-md-3 col-sm-3 col-xs-12">
      <div class="">
        <label>
          <input name="register_enabled" type="checkbox" class="js-switch"  <?php if($rows->register_enabled){ echo "checked"; } ?> />
      </label>
  </div>                                                
</div>
</div>
<div class="form-group">
    <label class="control-label col-md-3 col-sm-3 col-xs-12">Activation</label>
    <div class="col-md-3 col-sm-3 col-xs-12">
      <select name="default_active" class="select2_single form-control" tabindex="-1">
        <?php $__currentLoopData = $select_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>        
        <option <?php if($rows->default_active == $key){ echo "selected"; } ?> value="<?php echo e($key); ?>"><?php echo e($val); ?></option> 
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>       
    </select>
</div>
</div>
<div class="form-group">
    <label class="control-label col-md-3 col-sm-3 col-xs-12"><?php echo e(trans('laralum.users_welcome_email')); ?></label>
    <div class="col-md-3 col-sm-3 col-xs-12">
      <div class="">
        <label>
          <input name="welcome_email" type="checkbox" class="js-switch"  <?php if($rows->welcome_email){ echo "checked"; } ?> />
      </label>
  </div>                                                
</div>
</div>
<div class="ln_solid"></div>
<div class="form-group">
    <div class="col-md-3 col-sm-6 col-xs-12 pull-right">
      <a href="<?php echo e(route('Laralum::users')); ?>"><button type="submit" class="btn btn-primary">Retour</button></a>
      <button type="submit" class="btn btn-success">Valider</button>
  </div>
</div>
</form>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
  $(document).ready(function() {

    $(".select2_single").select2({
      placeholder: "Select a state",
      allowClear: true
  });
    $(".select2_group").select2({});
    $(".select2_multiple").select2({
      maximumSelectionLength: 4,
      placeholder: "With Max Selection limit 4",
      allowClear: true
  });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.panel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
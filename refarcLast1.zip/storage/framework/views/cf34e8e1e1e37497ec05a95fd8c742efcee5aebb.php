<?php
use App\User;
use App\TypeTpl;
?>
<div class="col-md-12 col-sm-12 col-xs-12">
	<div class="x_panel">
		<div class="x_content">		      
			<form id="edit_app" data-parsley-validate="" class="form-horizontal form-label-left" novalidate="" method="POST">
				<?php echo e(csrf_field()); ?>

				<?php if(Laralum::loggedInUser()->hasPermission('refarc.templates.edit') && $tpl->nbapps == 0  && $tpl->valid == 0): ?>
				<div><button id="addprg" type="button" class="btn btn-success btn-xs" data-toggle="modal" data-target=".bs-modal_add_cmp"><i class="fa fa-plus"></i> Ajouter nouvelle partie</button></div>
				<div id="modal_add_cmp" class="modal fade bs-modal_add_cmp" tabindex="-1" role="dialog" aria-hidden="true" style="display: none;">
					<div class="modal-dialog modal-lg">
						<div class="modal-content">
							<div class="modal-header">
								<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
								</button>
								<h4 class="modal-title" id="myModalLabel">Ajouter paragraphe</h4>
							</div>
							<div class="modal-body">
								<div class="form-group">											<label class="control-label col-md-3 col-sm-3 col-xs-12" for=	"name">Titre du paragraphe <span class="required">*</span>
								</label>
								<div class="col-md-8">
									<input id="text_new" value="" class="form-control" name="text" type="text">        
								</div>
							</div>
							<div class="form-group">
								<label>Partie fixe :</label><br>
								<textarea id="prgN" class="mceEditorAdd form-control" rows="4"></textarea>
							</div>
							<div class="modal-footer">
								<button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>
								<button type="button" class="btn btn-success" onclick="addNewParagraph(<?php echo e($id); ?>);">Ajouter</button>
							</div>
						</div>
					</div>
				</div>
			</div>
			<?php endif; ?>
			<br><br>
			<div class="accordion" id="accordion" role="tablist" aria-multiselectable="true">
				<?php $__currentLoopData = $parents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				<?php 					
				$exp = explode('.', $parent->num_parag);
				$readonly = '';
				if (!Laralum::loggedInUser()->su) {
					$readonly = 'Readonly';
				}
				?>
				<div class="panel pan_<?php echo e($parent->ordre); ?>" style="border-top:1px solid red;">
					<div class="panel-heading">							
						<a role="tab" id="heading_<?php echo e($parent->ordre); ?>" data-toggle="collapse" data-parent="#accordion" href="#collapse_<?php echo e($parent->ordre); ?>" aria-expanded="true" aria-controls="collapseOne">
							<h4 class="panel-title" style="height:inherit">
								<span class="label label-danger"><?php echo e($parent->num_parag); ?></span>
								<span id="title_<?php echo e($parent->id); ?>"><?php echo e($parent->text); ?></span>
							</a>
							<span class="right">
							<?php if(Laralum::loggedInUser()->hasPermission('refarc.templates.edit') && $tpl->nbapps == 0  && $tpl->valid == 0): ?>
								<span id="loader_<?php echo e($parent->id); ?>"></span>
								<button type="button" class="btn btn-success btn-xs" data-toggle="modal" data-target=".bs-modal_add_<?php echo e($parent->id); ?>" id="modal_add_st_<?php echo e($parent->id); ?>">
									<i class="fa fa-plus"></i> Ajouter un sous-titre</button>
									<div id="modal_add_<?php echo e($parent->id); ?>" class="modal fade bs-modal_add_<?php echo e($parent->id); ?>" tabindex="-1" role="dialog" aria-hidden="true" style="display: none;">
										<div class="modal-dialog modal-lg">
											<div class="modal-content">
												<div class="modal-header">
													<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
													</button>
													<h4 class="modal-title" id="myModalLabel">Ajouter patragraphe</h4>
												</div>
												<div class="modal-body">
													<div class="form-group">											<label class="control-label col-md-3 col-sm-3 col-xs-12" for=	"name">Titre du patragraphe <span class="required">*</span>
													</label>
													<div class="col-md-8">
														<input id="text_parent_add_<?php echo e($parent->id); ?>" value="" class="editor form-control" name="text" type="text">        
													</div>
												</div>
												<div class="form-group">
													<label>Partie fixe :</label><br>												
													<textarea class="mceEditor_<?php echo e($parent->id); ?> form-control" rows="4" id="text_stat_parent_add_<?php echo e($parent->id); ?>"></textarea>
													<div id="editor"></div>
												</div>
												<div class="modal-footer">
													<button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>
													<button type="button" class="btn btn-success" onclick="addParagraph(<?php echo e($parent->id); ?>, <?php echo e($parent->num_parag); ?>, 1, <?php echo e($parent->id_template); ?>);">Ajouter</button>
												</div>
											</div>
										</div>
									</div>
								</div>
								<?php endif; ?>


								<?php if(Laralum::loggedInUser()->hasPermission('refarc.templates.edit') && $tpl->nbapps == 0  && $tpl->valid == 0): ?>
								<button type="button" class="btn btn-warning btn-xs" data-toggle="modal" data-target=".bs-modal_<?php echo e($parent->id); ?>"><i class="fa fa-pencil"></i> Modifier le titre</button>
								<div id="modal_<?php echo e($parent->id); ?>" class="modal fade bs-modal_<?php echo e($parent->id); ?>" tabindex="-1" role="dialog" aria-hidden="true" style="display: none;">
									<div class="modal-dialog modal-lg">
										<div class="modal-content">
											<div class="modal-header">
												<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
												</button>
												<h4 class="modal-title" id="myModalLabel">Titre du patragraphe</h4>
											</div>
											<div class="modal-body">
												<div class="form-group">											
													<div class="col-md-12">
														<input id="text_parent_<?php echo e($parent->id); ?>" value="<?php echo e($parent->text); ?>" class="form-control" name="text" type="text">        
													</div>
												</div>
												<div class="modal-footer">
													<button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>
													<button type="button" class="btn btn-warning" onclick="savetpl(<?php echo e($parent->id); ?>, 'title');">Modifier</button>
												</div>
											</div>
										</div>
									</div>
								</div>
								<button id="save" type="button" class="btn btn-info btn-xs"
								onclick="savetpl(<?php echo e($parent->id); ?>);"><i class="fa fa-save"></i> Valider le contenu</button>
								<button type="button" class="btn btn-danger btn-xs sweet-4"
								onclick="deletPrg(<?php echo e($parent->id); ?>, 0, <?php echo e($parent->num_parag); ?>, 0);"><i class="fa fa-trash"></i></button>
								<?php endif; ?>
							</span>
						</h4>
					</div>
					<div id="collapse_<?php echo e($parent->ordre); ?>" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading_<?php echo e($parent->ordre); ?>">
						<div class="panel-body">
							<label>Partie fixe :</label><br>
							<input type="hidden" name="version" value="<?php echo e($tpl->version); ?>">
							<input type="hidden" name="module" value="tpl">							
							<textarea id="text_statFirsNiv_<?php echo e($parent->id); ?>" name="text_stat" class="form-control mceEditor_<?php echo e($parent->id); ?>" rows="4" readonly="readonly"><?php echo e($parent->text_stat); ?></textarea>							
							<br>
							<?php $__currentLoopData = $first_nivs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $first_niv): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
							<?php if($first_niv->parent == $parent->id && $first_niv->niv == 1): ?>
							<div class="accordion_<?php echo e($parent->id); ?>_<?php echo e($first_niv->ordre); ?>" id="accordion_<?php echo e($parent->id); ?>_<?php echo e($first_niv->ordre); ?>" role="tablist" aria-multiselectable="true"><br>
								<div class="panel" style="border-top:2px solid lightblue;">
									<div class="panel-heading">
										<a role="tab" id="heading_<?php echo e($parent->id); ?>_<?php echo e($first_niv->ordre); ?>" data-toggle="collapse" data-parent="#accordion_<?php echo e($parent->id); ?>_<?php echo e($first_niv->ordre); ?>" href="#collapse_<?php echo e($parent->id); ?>_<?php echo e($first_niv->ordre); ?>" aria-expanded="true" aria-controls="collapseOne">						
											<h4 class="panel-title">											
												<span class="label label-info"><?php echo e($first_niv->num_parag); ?></span> <span id="title_<?php echo e($first_niv->id); ?>"><?php echo e($first_niv->text); ?></span>
											</a>
											<span class="right">
											<?php if(Laralum::loggedInUser()->hasPermission('refarc.templates.edit') && $tpl->nbapps == 0  && $tpl->valid == 0): ?>
												<span id="loader_<?php echo e($first_niv->id); ?>"></span>
												<button type="button" class="btn btn-success btn-xs" data-toggle="modal" data-target=".bs-modal_add_<?php echo e($first_niv->id); ?>" id="modal_add_st_<?php echo e($first_niv->id); ?>">
													<i class="fa fa-plus"></i> Ajouter un sous-titre</button>
													<div id="modal_add_<?php echo e($first_niv->id); ?>" class="modal fade bs-modal_add_<?php echo e($first_niv->id); ?>" tabindex="-1" role="dialog" aria-hidden="true" style="display: none;">
														<div class="modal-dialog modal-lg">
															<div class="modal-content">
																<div class="modal-header">
																	<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
																	</button>
																	<h4 class="modal-title" id="myModalLabel">Ajouter patragraphe</h4>
																</div>
																<div class="modal-body">
																	<div class="form-group">											<label class="control-label col-md-3 col-sm-3 col-xs-12" for=	"name">Titre du patragraphe <span class="required">*</span>
																	</label>
																	<div class="col-md-8">
																		<input id="text_parent_add_<?php echo e($first_niv->id); ?>" value="" class="form-control" name="text" type="text">        
																	</div>
																</div>
																<div class="form-group">
																	<label>Partie fixe :</label><br>
																	<textarea class="mceEditor_<?php echo e($first_niv->id); ?> form-control" rows="4" id="text_stat_parent_add_<?php echo e($first_niv->id); ?>"></textarea>
																</div>
																<div class="modal-footer">
																	<button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>
																	<button type="button" class="btn btn-success" onclick="addParagraph(<?php echo e($first_niv->id); ?>, <?php echo e($first_niv->num_parag); ?>, 2, <?php echo e($first_niv->id_template); ?>);">Ajouter</button>
																</div>
															</div>
														</div>
													</div>
												</div>
												<?php endif; ?>
												<?php if(Laralum::loggedInUser()->hasPermission('refarc.templates.edit') && $tpl->nbapps == 0  && $tpl->valid == 0): ?>
												<button type="button" class="btn btn-warning btn-xs" data-toggle="modal" data-target=".bs-modal_<?php echo e($first_niv->id); ?>"><i class="fa fa-pencil"></i> Modifier le titre</button>
												<div id="modal_<?php echo e($first_niv->id); ?>" class="modal fade bs-modal_<?php echo e($first_niv->id); ?>" tabindex="-1" role="dialog" aria-hidden="true" style="display: none;">
													<div class="modal-dialog modal-lg">
														<div class="modal-content">
															<div class="modal-header">
																<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
																</button>
																<h4 class="modal-title" id="myModalLabel">Titre du patragraphe</h4>
															</div>
															<div class="modal-body">
																<div class="form-group">											
																	<div class="col-md-12">
																		<input id="text_parent_<?php echo e($first_niv->id); ?>" value="<?php echo e($first_niv->text); ?>" class="form-control" name="text" type="text">        
																	</div>
																</div>

															</div>
															<div class="modal-footer">
																<button type="button" class="btn btn-default"
																data-dismiss="modal">Fermer</button>
																<button type="button" class="btn btn-warning"
																onclick="savetpl(<?php echo e($first_niv->id); ?>, 'title');">Modifier
															</button>
														</div>
													</div>
												</div>
											</div>											
											<button type="button" class="btn btn-info btn-xs"
											onclick="savetpl(<?php echo e($first_niv->id); ?>);"><i class="fa fa-save"></i> Valider le contenu</button>
											<button type="button" class="btn btn-danger btn-xs sweet-4"
											onclick="deletPrg(<?php echo e($first_niv->id); ?>, 1, <?php echo e($first_niv->num_parag); ?>,
											<?php echo e($parent->id); ?>);"><i class="fa fa-trash"></i></button>
											<?php endif; ?>
										</span>
									</h4>
								</div>
								<div id="collapse_<?php echo e($parent->id); ?>_<?php echo e($first_niv->ordre); ?>" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading_<?php echo e($parent->id); ?>_<?php echo e($first_niv->ordre); ?>">
									<div class="panel-body">
										<label>Partie fixe :</label><br>
										<input type="hidden" name="version" value="<?php echo e($tpl->version); ?>">
										<textarea class="mceEditor_<?php echo e($first_niv->id); ?> form-control" rows="4" <?php echo e($readonly); ?> id="text_statFirsNiv_<?php echo e($first_niv->id); ?>"><?php echo e($first_niv->text_stat); ?></textarea>
										<br>												
										<?php $__currentLoopData = $second_nivs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $second_niv): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
										<?php if($second_niv->parent == $first_niv->id && $second_niv->niv == 2): ?>
										<div class="accordion_<?php echo e($first_niv->id); ?>_<?php echo e($second_niv->ordre); ?>" id="accordion_<?php echo e($first_niv->id); ?>_<?php echo e($second_niv->ordre); ?>" role="tablist" aria-multiselectable="true"><br>
											<div class="panel" style="border-top:2px solid lightblue;">
												<div class="panel-heading">
													<a role="tab" id="heading_<?php echo e($first_niv->id); ?>_<?php echo e($second_niv->ordre); ?>" data-toggle="collapse" data-parent="#accordion_<?php echo e($first_niv->id); ?>_<?php echo e($second_niv->ordre); ?>" href="#collapse_<?php echo e($first_niv->id); ?>_<?php echo e($second_niv->ordre); ?>" aria-expanded="true" aria-controls="collapseOne">
														<h4 class="panel-title">															
															<span class="label label-warning"><?php echo e($second_niv->num_parag); ?></span>
															<span id="title_<?php echo e($second_niv->id); ?>"><?php echo e($second_niv->text); ?></span>
														</a>
														<span class="right">
														<?php if(Laralum::loggedInUser()->hasPermission('refarc.templates.edit') && $tpl->nbapps == 0  && $tpl->valid == 0): ?>
															<span id="loader_<?php echo e($second_niv->id); ?>"></span>
															<button type="button" class="btn btn-warning btn-xs" data-toggle="modal" data-target=".bs-modal_<?php echo e($second_niv->id); ?>"><i class="fa fa-pencil"></i> Modifier le titre</button>
															<div id="modal_<?php echo e($second_niv->id); ?>" class="modal fade bs-modal_<?php echo e($second_niv->id); ?>" tabindex="-1" role="dialog" aria-hidden="true" style="display: none;">
																<div class="modal-dialog modal-lg">
																	<div class="modal-content">
																		<div class="modal-header">
																			<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
																			</button>
																			<h4 class="modal-title" id="myModalLabel">Titre du patragraphe</h4>
																		</div>
																		<div class="modal-body">
																			<div class="form-group">											
																				<div class="col-md-12">
																					<input id="text_parent_<?php echo e($second_niv->id); ?>" value="<?php echo e($second_niv->text); ?>" class="form-control" name="text" type="text">        
																				</div>
																			</div>
																			<div class="modal-footer">
																				<button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>
																				<button type="button" class="btn btn-warning" onclick="savetpl(<?php echo e($second_niv->id); ?>, 'title');">Modifier</button>
																			</div>
																		</div>
																	</div>
																</div>
															</div>															
															<button type="button" class="btn btn-info btn-xs" 
															onclick="savetpl(<?php echo e($second_niv->id); ?>);"><i class="fa fa-save"></i> Valider le contenu</button>
															<button type="button" class="btn btn-danger btn-xs sweet-4"
															onclick="deletPrg(<?php echo e($second_niv->id); ?>, 2, '<?php echo e($second_niv->num_parag); ?>', <?php echo e($first_niv->id); ?>);"><i class="fa fa-trash"></i></button>
															<?php endif; ?>
														</span>
													</h4>
												</div>
												<div id="collapse_<?php echo e($first_niv->id); ?>_<?php echo e($second_niv->ordre); ?>" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading_<?php echo e($first_niv->id); ?>_<?php echo e($second_niv->ordre); ?>">
													<div class="panel-body">
														<label>Partie fixe :</label><br>
														<input type="hidden" name="version" value="<?php echo e($tpl->version); ?>">
														<textarea class="mceEditor_<?php echo e($second_niv->id); ?> form-control" rows="4" <?php echo e($readonly); ?> id="text_statFirsNiv_<?php echo e($second_niv->id); ?>"><?php echo e($second_niv->text_stat); ?></textarea><br>
													</div>
												</div>
											</div>										
										</div>
									</form>
									<?php endif; ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
								</div>
							</div>
						</div>										
					</div>
					<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
				</div>
			</div>
		</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	</div>
</div>
</div>
<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
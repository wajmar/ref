
<?php $__env->startSection('content'); ?>
  <body class="login">
    <img src="<?php echo e(asset('images/sg.png')); ?>" id="sg_logo" style="height:70px;margin-top:20px;">
    <div>
      <div class="login_wrapper">
      
        <div class=" form login_form">
          <section class="login_content">
            <form method="POST">
              <h1><i class="fa fa-archive"></i>  <b>REF'</b>ARC</h1>
              <?php echo e(csrf_field()); ?>

              <div>
                <input name="name" type="text" class="form-control" placeholder="Nom" required="" />
              </div>
              <div>
                <input name="id_sesame" type="text" class="form-control" placeholder="Identifiant SESAME" required="" />
              </div>
              <div>
                <input name="email" type="text" class="form-control" placeholder="Adresse mail" required="" />
              </div>
              <div>
                <input name="password" type="password" class="form-control" placeholder="Password" required="" />
              </div>
              <div>
                <input name="password_confirmation" type="password" class="form-control" placeholder="Confirm Password" required="" />
              </div>
              <div>
                <button type="submit" class="btn btn-danger submit btn-lg col-md-12" style="margin-bottom:20px;">Inscription</button>
              </div>
              <div class="clearfix"></div>

              <div class="separator">
                <p class="change_link"><h2>Deja un compte ?</h2><br/>
                  <a href="/login" class="to_register btn btn-danger btn-lg col-md-12"> Connexion </a>
                </p>
                <div class="clearfix"></div>
                <br />
              </div>
            </form>
          </section>
        </div>       
      </div>
    </div>
  </body>
  <script type="text/javascript">
    $("html").css('background-color','white');
    $(".content").css("background-color","white");
    $(".content").css("text-align","center");
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php
use App\User;
use App\TypeTpl;
?>

<?php $__env->startSection('breadcrumb'); ?>
<div class="ui breadcrumb">
  <i class="fa fa-newspaper-o"></i>
  <a class="section" href="">Gestion des types de template</a>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="clearfix"></div>
<div class="row"> 
  <div class="col-md-12 col-sm-12 col-xs-12">
    <div class="x_panel">
      <div class="x_title">
        <button type="button" id="addType_btn" class="btn btn-success" data-toggle="modal" data-target=".modalAdd"><i class="fa fa-plus"></i> Ajouter type</button>
        <div class="clearfix"></div>
      </div>
      <!-- Modal d'ajout de type-->
      <div class="modal fade modalAdd" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-sm">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
              </button>
              <h4 class="modal-title" id="myModalLabel">Ajout d'un type</h4>
            </div>
            <div class="modal-body">
              <label class="control-label" for="type_name_add">Nom du type :</label>
              <input type="text" id="type_name_add" name="type_name_add" class="form-control" required><br>
              <span id="error_add" style="color:red;font-style:italic;display:none;"></span>
              <input type="hidden" name="_token" value="<?php echo csrf_token() ?>">
            </div><br>
            <div class="modal-footer">
              <button type="button" class="btn btn-default" data-dismiss="modal">Annuler</button>
              <button type="button" class="btn btn-success" onclick="addType()"><span id="text_add">Ajouter</span><img id="loader_add" src="<?php echo e(asset('images/7.gif')); ?>" style="height:15px;width:15px;display:none"></button>
            </div>
          </div>
        </div>
      </div>
      <!-- Fin modal ajout type-->
      <div class="x_content">          
        <table id="table_types" class="table table-striped table-bordered">
          <thead>
            <tr>
              <th>Type</th>  
              <th>Date de création</th>
              <th>Nombres documents</th>
	      <th>Nombres templates</th>            
              <th>Options</th>
            </tr>
          </thead>
          <tbody>
          <?php $__currentLoopData = $tpl_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tpl_type): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <!-- Initialisation du compteur -->
            <?php 
              $count_tpl = 0; 
              $count_docs = 0;
            ?>
            <!-- Ecriture de la ligne -->
            <tr>
              <td><?php echo e($tpl_type->type); ?></td>
              <!-- Explode pour mise en forme de la date -->
              <?php $tpl_date = explode(" ",$tpl_type->created_at); ?>
              <td><?php  echo($tpl_date[0]) ?></td>

              <?php $__currentLoopData = $tpls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tpl): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <?php if($tpl_type->id == $tpl->type): ?>
                  <?php 
                    $count_tpl++;
                    $count_docs = $count_docs + $tpl->nbapps;
                  ?>
                <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
              <?php if($count_tpl > 0): ?>
                <!-- Modification/Suppression impossible-->
                <td><?php echo($count_docs) ?></td>
		<td><?php echo($count_tpl) ?></td>
                <!-- Présence template et documents -->
                <td>
                  <button class="btn btn-default btn-xs" data-toggle="tooltip" data-placement="top" title="Modification impossible"><i class="fa fa-close"></i></button>
                  <button type="button" class="btn btn-default btn-xs" data-toggle="tooltip" data-placement="top" title="Suppression impossible"><i class="fa fa-close"></i></button>
                </td>
              <?php else: ?>
                <!-- Modification/Suppression possible -->
                <td><?php echo($count_docs) ?></td>
		<td><?php echo($count_tpl) ?></td>
                <td>
                  <a data-toggle="tooltip" data-placement="top" title="Modifier"><button type="button" class="btn btn-warning btn-xs" data-toggle="modal" data-target=".modalEditType_<?php echo e($tpl_type->id); ?>" ><i class="fa fa-pencil"></i></button></a>
                  <a data-toggle="tooltip" data-placement="top" title="Supprimer"><button type="button" class="btn btn-danger btn-xs" data-toggle="modal" data-target=".modalDelType_<?php echo e($tpl_type->id); ?>"><i class="fa fa-trash"></i></button></a>
                </td>
              <?php endif; ?>
            </tr>
            <!-- Modal de modification -->
            <div class="modal fade modalEditType_<?php echo e($tpl_type->id); ?>" tabindex="-1" role="dialog" aria-hidden="true">
              <div class="modal-dialog modal-sm">
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
                    </button>
                    <h4 class="modal-title" id="myModalLabel">Modification de type</h4>
                  </div>
                  <div class="modal-body">
                    <label class="control-label" for="type_name">Nom du type :</label>
                    <input type="text" id="type_name" name="type_name" class="form-control" value="<?php echo e($tpl_type->type); ?>" required>
                  </div><br>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Annuler</button>
                    <button type="button" class="btn btn-warning" onclick="editType(<?php echo e($tpl_type->id); ?>)"><span id="text_edit_<?php echo e($tpl_type->id); ?>">Modifier</span><img id="loader_edit_<?php echo e($tpl_type->id); ?>" src="<?php echo e(asset('images/7.gif')); ?>" style="height:15px;width:15px;display:none"></button>
                  </div>
                </div>
              </div>
            </div>
            <!-- Fin du modal de modification -->
            <!-- Modal de suppression -->
            <div class="modal fade modalDelType_<?php echo e($tpl_type->id); ?>" tabindex="-1" role="dialog" aria-hidden="true">
              <div class="modal-dialog modal-sm">
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
                    </button>
                    <h4 class="modal-title" id="myModalLabel">Suppression de type</h4>
                  </div>
                  <div class="modal-body">
                    <p>Etes-vous sûr de vouloir supprimer ce type ?</p>
                  </div><br>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Annuler</button>
                    <button type="button" class="btn btn-danger" onclick="deleteType(<?php echo e($tpl_type->id); ?>)"><span id="text_del_<?php echo e($tpl_type->id); ?>">Supprimer</span><img id="loader_del_<?php echo e($tpl_type->id); ?>" src="<?php echo e(asset('images/7.gif')); ?>" style="height:15px;width:15px;display:none"></button>
                  </div>
                </div>
              </div>
            </div>
            <!-- Fin du modal de suppression -->
          <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </tbody>
      </table>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script type="text/javascript">

  function addType() {
    var type_name = $("#type_name_add").val();
    var _token = $('input[name=_token]').val();
    var formData = {type_name:type_name,_token:_token};
    $.ajax({
      type: 'post',
      data : formData,
      url: './add',
      beforeSend: function(xhr){
        $("#text_add").hide();
        $("#loader_add").show();
      },
      success: function(result){
        // On affiche le texte sur le bouton
        $("#text_add").show();
        $("#loader_add").hide();
        // Test unicite
        if (result == 'exist') {
          // affiche l'erreur
          $('#error_add').html('Le type '+type_name+' existe déjà !');
          $('#error_add').show();
          return false;
        } 
        else {
           // On cache le modal
          $('.modalAdd').modal('hide');
          $(".modal-backdrop").modal('hide');
          // Insertion du nouveau tableau
          $("#table_types tbody").html(result);
          // Message de confirmation de creation
          swal({
            title: "Creation",
            text: "Le type a bien été crée",
            type: "success",
            confirmButtonText: "Fermer"
          });
        }
      },
    });
  }

  function editType(id){

    var _token = $('input[name=_token]').val();
    var type = $('.modalEditType_'+id+' #type_name').val();
    var FormData = {id:id,type_name:type,_token:_token};

    if(type !== '' && type !== undefined){
      //fonction ajax pour modifier un type
      $.ajax({
        type: 'post',
        data: FormData,
        url: './edit',
        beforeSend: function(xhr){
          // on affiche le loader
          $("#text_edit_"+id).hide();
          $("#loader_edit_"+id).show();
        },
        success: function(result){
          // On affiche le texte sur le bouton
          $("#text_edit_"+id).show();
          $("#loader_edit_"+id).hide();
          // On cache le modal
          $('.modalEditType_'+id).modal('hide');
          $(".modal-backdrop").modal('hide');
          // Insertion du nouveau tableau
          $("#table_types tbody").html(result);
          // Message de confirmation de modification
          swal({
            title: "Modification",
            text: "Le type a bien été modifié",
            type: "success",
            confirmButtonText: "Fermer"
          });
        },
    });
    }
  }

  function deleteType(id){

    var _token = $('input[name=_token]').val();
    var FormData = {id:id,_token:_token};
    $.ajax({
      type: 'post',
      data: FormData,
      url: './delete',
      beforeSend: function(xhr){
        // on affiche le loader
        $("#text_del_"+id).hide();
        $("#loader_del_"+id).show();
      },
      success: function(result){
        // On affiche le texte sur le bouton
        $("#text_del_"+id).show();
        $("#loader_del_"+id).hide();
        // On cache le modal
        $('.modalDelType_'+id).modal('hide');
        $(".modal-backdrop").modal('hide');
        // Insertion du nouveau tableau
        $("#table_types tbody").html(result);
        swal({
          title: "Suppression",
          text: "Le type a bien été supprimé",
          type: "success",
          confirmButtonText: "Fermer"
        });
      }
    });
  }

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.panel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
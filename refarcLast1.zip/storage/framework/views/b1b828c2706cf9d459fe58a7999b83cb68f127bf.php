
<?php $__env->startSection('breadcrumb'); ?>
    <div class="ui breadcrumb">
        <a class="section" href="<?php echo e(route('Laralum::roles')); ?>"><i class="fa fa-list"></i> <?php echo e(trans('laralum.roles_title')); ?></a>
        / 
        <strong class="active section"><?php echo e(trans('laralum.roles_create_title')); ?></strong>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="x_panel">
                <div class="x_content">
                <form method="POST">
                    <?php echo e(csrf_field()); ?>

                    <div class="col-md-6">
                        <label for="name">Nom du role :</label>
                        <input type="text" class="form-control" name="name">
                    </div><br><br><br>
                    <div>
                    <?php
                        $tabPermGroup = [];
                    ?>
                    <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <?php 
                        $perm = explode('.',$permission['slug']);
                        if(in_array($perm[1],$tabPermGroup)){
                            ?>
                            <span>
                                <input type="checkbox" value="<?php echo e(trans('permissions.'.$permission['slug'])); ?>" class="js-switch"> <?php echo e(trans('permissions.'.$permission['slug'])); ?></input><br><br>
                            </span>
                            <?php
                        }
                        else{
                            echo('<h2>'.$perm[1].'</h2>');
                            array_push($tabPermGroup, $perm[1]);
                            ?>
                            <span>
                                <input type="checkbox" value="<?php echo e(trans('permissions.'.$permission['slug'])); ?>" class="js-switch"> <?php echo e(trans('permissions.'.$permission['slug'])); ?></input><br><br>
                            </span>
                        <?php
                        }
                        ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    </div>
                    <br>
                        <button type="submit" class="btn btn-success">Créer</button>
                </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.panel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
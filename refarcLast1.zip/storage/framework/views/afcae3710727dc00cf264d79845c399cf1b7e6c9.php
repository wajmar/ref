<?php use App\User; ?>

<?php $__env->startSection('breadcrumb'); ?>    
<div class="ui breadcrumb">
    <i class="fa fa-add"></i>
    <a class="section" href="<?php echo e(route('Laralum::projects')); ?>"><?php echo e(trans('laralum.projects_list')); ?></a>
    / <small><?php echo e(trans('laralum.projects_create')); ?></small>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title', trans('laralum.projects_create')); ?>
<?php $__env->startSection('icon', "add"); ?>
<?php $__env->startSection('content'); ?>

<div class="x_panel">
  <div class="x_title">
  </div>
  <div class="x_content">
    <br>
    <form id="add_project" data-parsley-validate class="form-horizontal form-label-left" method="POST">
      <div class="form-group">
        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Projet <span class="required">*</span>
        </label>
        <div class="col-md-6 col-sm-6 col-xs-12">
          <input id="name" name="name" required class="form-control col-md-7 col-xs-12" type="text" value="">
        </div>
      </div>
      <div class="form-group">
        <label class="control-label col-md-3 col-sm-3 col-xs-12">
          <?php echo e(trans('laralum.description')); ?>

        </label>
        <div class="col-md-9 col-sm-9 col-xs-12">
          <textarea  name="description" class="form-control" rows="3" style="width: 611px; height: 110px;" required="required"></textarea>
        </div>
      </div>
      <div class="form-group">
        <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">Date de création</label>
        <div class="control-group">
          <div class="controls">
            <div class="col-md-3 xdisplay_inputx form-group has-feedback">
              <input type="text" name="created_at" class="form-control has-feedback-left" id="single_cal4" placeholder="" aria-describedby="inputSuccess2Status4" required>
              <span class="fa fa-calendar-o form-control-feedback left" aria-hidden="true"></span>
              <span id="inputSuccess2Status4" class="sr-only">(success)</span>
            </div>
          </div>
        </div>
      </div>
      <input type="hidden" name="_token" value="<?php echo csrf_token() ?>">
      <div class="ln_solid"></div>
      <div class="form-group">
        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-7">
          <a href="<?php echo e(route('Laralum::projects')); ?>"><button type="button" class="btn btn-primary">Annuler</button></a>
          <button type="submit" class="btn btn-success">Submit</button>
        </div>
      </div>
    </form>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script type="text/javascript">
    $(document).ready(function() {
        $('#single_cal4').daterangepicker({
          singleDatePicker: true,
          singleClasses: "picker_4"
      }, function(start, end, label) {
          console.log(start.toISOString(), end.toISOString(), label);
      });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.panel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
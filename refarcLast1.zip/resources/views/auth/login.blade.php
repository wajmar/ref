@extends('layouts.main')
@section('content')
  <body class="login">
  <img src="{{ asset('images/sg.png') }}" id="sg_logo" style="height:70px;margin-top:20px;">
    <div>
      <div class="login_wrapper">
      
        <div class=" form login_form">
          <section class="login_content">
            <form method="POST">
              <h1><i class="fa fa-archive"></i>  <b>REF'</b>ARC</h1>
              {{ csrf_field() }}
              <div>
                <input name="email" type="text" class="form-control" placeholder="Adresse mail" required="" />
              </div>
              <div>
                <input name="password" type="password" class="form-control" placeholder="Password" required="" />
              </div>
              <div>
                <button type="submit" class="btn btn-danger submit btn-lg col-md-12" style="margin-bottom:20px;">Connexion</button>
              </div>
		@if(session('success'))
                <p style='font-size: 20px;color:green;'>{!! session('success') !!}<p>
              @endif
              @if(session('error'))
                <p style='font-size:20px;color:red;font-style:italic'>{!! session('error') !!}<p>
              @endif
                @if(session('warning'))
                <p style='font-size:20px;color:orange;'>{!! session('warning') !!}<p>
              @endif
              @if(session('info'))
                <p style='font-size:20px;color:blue;'>{!! session('info') !!}<p>
              @endif
                @if (session('status'))
                    <p style='font-size:40px;color:green;'>{!! session('status') !!}<p>
                @endif
              @if (count($errors) > 0)
                <?php foreach($errors->all() as $error){ echo "<p style='font-size:20px;color:red;font-style:italic'>$error<p>"; } ?>
              @endif
              <div class="clearfix"></div>

              <div class="separator">
                <p class="change_link"><h2>Pas encore de compte ?</h2><br/>
                  <a href="/register" class="to_register btn btn-danger btn-lg col-md-12"> Inscription </a>
                </p>
                <div class="clearfix"></div>
                <br />
              </div>
            </form>
          </section>
        </div>       
      </div>
    </div>
  </body>
  @endsection
@section('js')
  <script type="text/javascript">
    $("html").css('background-color','white');
    $(".content").css("background-color","white");
    $(".content").css("text-align","center");
  </script>
@endsection

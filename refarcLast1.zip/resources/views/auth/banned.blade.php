@extends('layouts.main')
@section('content')
    <div class="title m-b-md">
        {{ trans('laralum.account_banned') }}
    </div>
@endsection

<!-- Insertion des reports de l'utilisateur courant-->
                    @foreach($exps as $exp)
                    <tr>
                      <td style="text-align:center">
                        <button type="button" class="btn btn-info btn-xs comment_btn" id="comment_btn{{$exp->id}}" data-toggle="collapse" data-target="#comment{{$exp->id}}" class="accordion-toggle" onclick="show_comment({{$exp->id}})"><i class="fa fa-search"></i></button>
                      </td>
                      <td>{{ $exp->page }}</td>
                      <td>{{ $exp->type }}</td>
                      <!-- Mise en forme de la date de creation -->
                      <?php 
                        $created_at = explode(" ",$exp->created_at);
                      ?>
                      <td>{{ $created_at[0] }}</td>
                      <td>{{ $exp->wished_at }}</td>
                      <td>{{ $exp->planned_at }}</td>
                      <td>
                        <!-- Condition pour afficher la bonne couleur de label -->
                        <?php 
                        if($exp->status == "Envoyé"){
                          $class_label = "btn-info";
                        }
                        elseif ($exp->status == "En cours") {
                          $class_label = "btn-warning"; 
                        }
                        else{
                          $class_label = "btn-success";
                        }
                        ?>
                        <label class="btn btn-xs <?php echo($class_label) ?>">{{ $exp->status }}</label>
                      </td>
                      <td>
                        <?php 
                        if($exp->criticite == "haute"){
                          $class_label = "btn-danger";
                        }
                        elseif ($exp->criticite == "moyenne") {
                          $class_label = "btn-warning"; 
                        }
                        else{
                          $class_label = "btn-success";
                        }
                        ?>
                        <label class="btn btn-xs <?php echo($class_label) ?>">{{ $exp->criticite }}</label>
                      </td>
                      <td>
                        <button type="button" class="btn btn-xs btn-warning" data-toggle="modal" data-target=".modal_edit_{{$exp->id}}"><i class="fa fa-pencil"></i></button>
                        <button type="button" class="btn btn-xs btn-danger" data-toggle="modal" data-target=".modal_del_{{$exp->id}}"><i class="fa fa-trash"></i></button>
                      </td>
                    </tr>
                    <tr>
                      <td colspan="9" class="hiddenRow" style="padding:0px">
                        <div class="accordion-body collapse" id="comment{{$exp->id}}">{{ $exp->comment }}</div>
                      </td>
                    </tr>
                    <!-- Modal de suppression -->
                    <div class="modal fade modal_del_{{$exp->id}}" tabindex="-1" role="dialog" aria-hidden="true">
                      <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                          <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
                            </button>
                            <h4 class="modal-title" id="myModalLabel">Suppresion d'un report</h4>
                          </div>
                          <div class="modal-body">
                            <p>
                              Etes-vous sûr de vouloir supprimer le report #{{$exp->id}} ?
                            </p>
                          </div>
                          <div class="modal-footer">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Annuler</button>
                            <button id="btn_delexp" type="button" class="btn btn-danger" onclick="deleteReport({{ $exp->id }})"><i class="fa fa-trash" id="icon_delexp"></i><span id="text_submit_delexp">Supprimer report</span><img id="loader_submit_delexp" src="{{ asset('images/7.gif') }}" style="height:15px;width:15px;display:none"></button>
                            </div>
                        </div>
                      </div>
                    </div>
                    <!-- End modal de suppression -->
                    <!-- Modal de modification -->
                    <div class="modal fade modal_edit_{{$exp->id}}" tabindex="-1" role="dialog" aria-hidden="true">
                      <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                          <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
                            </button>
                            <h4 class="modal-title" id="myModalLabel">Modification d'un report</h4>
                          </div>
                          <div class="modal-body">
                            <div class="form_group">
                              <label class="form-label" for="page_report_edit">Page du bug :</label>
                              <select id="page_report_edit" name="page_report_edit" class="select2_group form-control" required>
                                <optgroup label="Tableau de bord">
                                  <option value="Tableau de bord">Tableau de bord</option>
                                </optgroup>
                                <optgroup label="Projet">
                                  <option value="Liste des DAH">Liste des DAH</option>
                                  <option value="Création d'un DAH">Creation d'un DAH</option>
                                </optgroup>
                                <optgroup label="Utilisateurs">
                                  <option value="Liste des utilisateurs">Liste des utilisateurs</option>
                                  <option value="Création d'un utilisateur">Creation d'un utilisateur</option>
                                  <option value="Administration utilisateur">Administration utilisateurs</option>
                                </optgroup>
                                <optgroup label="Roles">
                                  <option value="Liste des rôles">Liste des rôles</option>
                                  <option value="Création d'un rôle">Creation d'un rôle</option>
                                </optgroup>
                                <optgroup label="Liste des permissions">
                                  <option value="Liste des permissions">Liste des permissions</option>
                                </optgroup>
                                <optgroup label="Templates">
                                  <option value="Liste des templates">Liste des templates</option>
                                  <option value="Création d'un template">Creation d'un template</option>
                                  <option value="Fusion templates">Fusion templates</option>
                                  <option value="Utilisateurs génériques">Utilisateurs génériques</option>
                                </optgroup>
                              </select>
                            </div><br>
                            <div class="form_group">
                              <label class="type_report" for="type_report_edit">Type de report : </label>
                              <select id="type_report_edit" name="type_report_edit" class="select2_group form-control" required>
                                @if($exp->type == 'bug')
                                <option value="bug" selected>Bug</option>
                                <option value="evolution">Evolution</option>
                                @else
                                <option value="bug">Bug</option>
                                <option value="evolution" selected>Evolution</option>
                                @endif
                              </select>
                            </div><br>
                            <input type="hidden" name="_token" value="<?php echo csrf_token() ?>">
                            <div class="form-group">
                              <label class="control-label" for="comment_report_edit">Description :</label>
                              <textarea id="comment_report_edit" name="comment_report_edit" class="form-control" rows="5" required>{{ $exp->comment }}</textarea>
                            </div><br>
                            <div class="form-group">
                              <label class="control-label" for="criticite_report_edit">Criticite :</label>
                              <select id="criticite_report_edit" name="criticite_report_edit" class="select2_group form-control" required>
                                @if($exp->criticite == 'basse')
                                  <option value="basse" selected>Basse</option>
                                  <option value="moyenne">Moyenne</option>
                                  <option value="haute">Haute</option>
                                @elseif($exp->criticite == 'moyenne')
                                  <option value="basse">Basse</option>
                                  <option value="moyenne" selected>Moyenne</option>
                                  <option value="haute">Haute</option>
                                @else
                                  <option value="basse">Basse</option>
                                  <option value="moyenne">Moyenne</option>
                                  <option value="haute" selected>Haute</option>
                                @endif
                              </select>
                            </div><br>
                            <div class="form-group">
                              <?php 
                                $wishdate = explode("-",$exp->wished_at);
                              ?>
                              <label for="wishdate_report_edit">Date souhaitée :</label><br>
                              <input type="text" id="wishdate_report_edit" class="form-control col-md-9 date-picker" name="wishdate_report_edit" autocomplete="off" value="<?php echo($wishdate[1].'/'.$wishdate[2].'/'.$wishdate[0]); ?>" required><br>
                            </div><br>
                          </div>
                          <div class="modal-footer">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Annuler</button>
                            <button id="btn_delexp" type="button" class="btn btn-success" onclick="editReport({{ $exp->id }})"><span id="text_submit_editexp">Modifier report</span><img id="loader_submit_editexp" src="{{ asset('images/7.gif') }}" style="height:15px;width:15px;display:none"></button>
                          </div>
                        </div>
                      </div>
                    </div>
                    <!-- End modal de modification -->
                    @endforeach
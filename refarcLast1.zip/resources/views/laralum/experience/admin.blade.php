@extends('layouts.admin.panel')
@section('breadcrumb')
<div class="ui breadcrumb">
<div class="active section"><i class="fa fa-refresh"></i> Administration Retour d'experience</div>
</div>
@endsection
@section('content')

<div class="clearfix"></div>
<div class="row"> 
  <div class="col-md-12 col-sm-12 col-xs-12">
    <div class="x_panel">
      <div class="x_title">
        Administration Retour d'experience
      </div>
      <div class="x_content">
		    <table id="tab_exp_admin" class="table table-bordered">
          <thead>
            <tr>
              <th style="text-align:center">#</th>
              <th>Page</th>
              <th>Type</th>
              <th>Date report</th>
              <th>Date souhaitée</th>
              <th>Date prévue</th>
              <th>Statut</th>
              <th>Criticite</th>
              <th>Options</th>
            </tr>
          </thead>
          <tbody>
            <!-- Insertion des reports de l'utilisateur courant-->
            @foreach($exps as $exp)
            <tr>
              <td style="text-align:center">
                <button type="button" class="btn btn-info btn-xs comment_btn" id="comment_btn{{$exp->id}}" data-toggle="collapse" data-target="#comment{{$exp->id}}" class="accordion-toggle" ><i class="fa fa-search"></i></button>
              </td>
              <td>{{ $exp->page }}</td>
              <td>{{ $exp->type }}</td>
              <!-- Mise en forme de la date de creation -->
                <?php 
                  $created_at = explode(" ",$exp->created_at);
                ?>
              <td>{{ $created_at[0] }}</td>
              <td>{{ $exp->wished_at }}</td>
              <td>{{ $exp->planned_at }}</td>
              <td>
                <!-- Condition pour afficher la bonne couleur de label -->
                <?php 
                  if($exp->status == "StandBy"){
                    $class_label = "btn-default";
                  }
                  elseif ($exp->status == "A Analyser") {
                    $class_label = "btn-warning"; 
                  }
                  elseif($exp->status == "Traité")
                    $class_label = "btn-info";  
                  else{
                    $class_label = "btn-success";
                  }
                ?>
                <label class="btn btn-xs <?php echo($class_label) ?>">{{ $exp->status }}</label>
              </td>
              <td>
                <?php 
                  if($exp->criticite == "haute"){
                    $class_label = "btn-danger";
                  }
                  elseif ($exp->criticite == "moyenne") {
                    $class_label = "btn-warning"; 
                  }
                  else{
                    $class_label = "btn-success";
                  }
                ?>
                <label class="btn btn-xs <?php echo($class_label) ?>">{{ $exp->criticite }}</label>
              </td>
              <td>
              	<button type="button" class="btn btn-warning btn-xs" data-toggle="modal" data-target=".modaledit{{$exp->id}}"><i class="fa fa-pencil"></i></button>
                <button type="button" class="btn btn-danger btn-xs" data-toggle="modal" data-target=".modalsupp{{$exp->id}}"><i class="fa fa-trash"></i></button>
              </td>
            </tr>
            <tr>
              <td colspan="9" class="hiddenRow" style="padding:0px">
                <div class="accordion-body collapse" id="comment{{$exp->id}}">{{ $exp->comment }}</div>
              </td>
            </tr>
            <!-- Modal de modification-->
            <div class="modal fade modaledit{{$exp->id}}" tabindex="-1" role="dialog" aria-hidden="true">
	            <div class="modal-dialog modal-sm">
	                <div class="modal-content">
		                <form method="POST">
			                <div class="modal-header">
			                  	<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span>
			                  	</button>
			                  	<h4 class="modal-title" id="myModalLabel2">Modification report</h4>
			                </div>
			                <div class="modal-body">
			                	<div class="form_group">
			                  		<label class="control-label" for="statut_retexp">Statut du retour d'experience :</label>
			                  		<select class="form-control" id="statut_retexp" name="statut_retexp" required>
			                  			<option value="A Analyser">A Analyser</option>
			                  			<option value="StandBy">StandBy</option>
			                  			<option value="Traité">Traité</option>
			                  		</select>
			                  		<input type="hidden" name="_token" value="<?php echo csrf_token() ?>">
			                  		<input type="hidden" name="id_retexp" value="{{$exp->id}}">
			                  </div>
                        <div class="form_group">
                          <label class="form_control" for="date_retexp">Date prévue de réalisation :</label>
                          <input type="text" id="date_retexp_id" class="form-control col-md-9 date-picker date_retexp" name="date_retexp" autocomplete="off" value="" required><br>
                        </div><br>
			                </div>
			                <div class="modal-footer">
			                  <button type="button" class="btn btn-default" data-dismiss="modal">Annuler</button>
			                  <button type="submit" class="btn btn-success">Modifier</button>
			                </div>
			            </form>
	                </div>
	            </div>
	           </div>
             <!-- Fin modal de modificiation -->
             <!-- Modal de suppression -->
             <div class="modal fade modalsupp{{$exp->id}}" tabindex="-1" role="dialog" aria-hidden="true">
              <div class="modal-dialog modal-sm">
                  <div class="modal-content">
                    <form method="POST">
                      <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span>
                          </button>
                          <h4 class="modal-title" id="myModalLabel2">Suppresion report</h4>
                      </div>
                      <div class="modal-body">
                        <p>Etes-vous sûr de vouloir supprimer ce report ?</p>
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Annuler</button>
                        <button type="button" class="btn btn-danger" onclick="delreport({{$exp->id}})"><span id="text_del_btn" style="display:block;">Supprimer</span><img id="loader_del_btn" src="{{ asset('images/7.gif') }}" style="height:15px;width:15px;display:none"></button>
                      </div>
                  </form>
                  </div>
              </div>
             </div>
             <!-- fin modal de suppression -->
            @endforeach
          </tbody>
        </table>                      
      </div>
    </div>
  </div>
</div>
@endsection
@section('js')
<script type="text/javascript">
  $(function() {
    $('.date_retexp').daterangepicker({
      singleDatePicker: true,
      calender_style: "picker_4"
    });
  });

  function delreport(id){
    var _token = $('input[name=_token]').val();
    var type_del = 'admin';
    var FormData = {id:id,type_del:type_del, _token:_token};
    $.ajax({
      type: 'post',
      data: FormData,
      url: '/admin/experiences/delete',
      beforeSend: function(xhr){
        $("#text_del_btn").css("display","none");
        $("#loader_del_btn").css("display","block");
      },
      success:function(result){
        $("#text_del_btn").css("display","block");
        $("#loader_del_btn").css("display","none");
        $(".modalsupp"+id).hide()
        $(".modal-backdrop").hide();
        $("#tab_exp_admin tbody").html(result);
	swal({
          title: "Suppression",
          text: "Le report a bien ete supprime",
          type: "success",
          confirmButtonText: "Fermer"
        });
	$('.date_retexp').daterangepicker({
          singleDatePicker: true,
          calender_style: "picker_4"
        });
      },
    }); 
  }
</script>
@endsection
@extends('layouts.admin.panel')
@section('breadcrumb')
    <div class="ui breadcrumb">
        <a class="section" href="{{ route('Laralum::users') }}">{{ trans('laralum.user_list') }}</a>
        /
        <strong class="active section">{{ $user->name }}</strong>
    </div>
@endsection
@section('content')
    <div class="clearfix"></div>
    <div class="row">
        <div class="col-md-3">
            <div class="x_panel">
                <br>
                <label class="red">Nom de l'utilisateur :</label><br>
                <span>{{ $user->name }}</span><br><br>
                <label class="red">Identifiant SESAME :</label><br>
                <span>{{ $user->id_sesame }}</span><br><br>
                <label class="red">Adresse mail :</label><br>
                <span>{{ $user->email }}</span><br><br>
                <label class="red"> Rôle(s) :</label><br>
                <span>
                    <ul class="list-unstyled">
                        @foreach($roles_user as $role_user)
                            @foreach($roles as $role)
                                @if($role->id == $role_user->role_id)
                                    <li><label class="btn btn-info">{{ $role->name }}</label></li>        
                                @endif
                            @endforeach
                            
                        @endforeach
                    </ul>

                </span>
                <label class="red">Statut Compte :</label><br><br>
                <?php 
                    if($user->active == 1){
                        echo "<label class='btn btn-success btn-sm'><i class='fa fa-check'></i> Activé</label>";
                    }
                    else{
                        echo "<label class='btn btn-danger btn-sm'><i class='fa fa-warning'></i> Désactivé</label>";
                    }

                ?>
            </div> 
        </div> 
        <div class="col-md-9">
            <div class="x_panel">
                <div class="row panel-title">
                    <h3>Liste des applications de l'utilisateur</h3>
                </div><br>
                @if(count($projects) > 0)
                    @foreach($projects as $project)
                        <div class="animated flipInY col-lg-6 col-md-6 col-sm-12 col-xs-12" style="float:left">
                            <a href="">
                                <div class="tile-stats" style="border:1px solid #26B99A">
                                    <div class="icon"><i class="fa fa-pencil" style="color:#26B99A;"></i></div>
                                    <div class="count">0%</div>
                                    <h3>{{ ucfirst($project->name) }}</h3><br>
                                    <div class="progress">
                                        <div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div>
                                    </div>
                                </div>
                            </a>
                        </div>
                    @endforeach    
                @else
                    <span>Aucune application</span>
                @endif
            </div>
        </div>   
    </div>
    
@endsection

@extends('layouts.admin.panel')
@section('breadcrumb')
<div class="ui breadcrumb">
  <div class="active section"><i class="fa fa-users"></i> {{ trans('laralum.user_list') }}</div>
</div>
@endsection
@section('title', trans('laralum.user_list'))
@section('icon', "users")
@section('subtitle', trans('laralum.users_subtitle'))
@section('content')

<div class="clearfix"></div>
<div class="row">             
  

  <div class="clearfix"></div>
  <div class="row"> 

    <div class="col-md-12 col-sm-12 col-xs-12">
      <div class="x_panel">
        <div class="x_title">
          <h2>{{ trans('laralum.user_list') }}</h2>
          <div class="clearfix"></div>
        </div>
        <div class="x_content">                    
          <table id="datatable-buttons" class="table table-striped table-bordered">
            <thead>
              <tr>
                <th>{{ trans('laralum.name') }}</th>
                <th>{{ trans('laralum.email') }}</th>
		<th>Role(s)</th>
                <th>Date de création</th>
                <th>{{ trans('laralum.options') }}</th>
              </tr>
            </thead>
            <tbody>
              <?php $countries = Laralum::countries(); ?>
              @foreach($users as $user)
                <tr>
                  <td>
                    <div class="text">
                        <a href="{{ route('Laralum::users_profile', ['id' => $user->id]) }}">{{ $user->name }}</a>
                        @if($user->su)
                          <div class="ui red tiny left pointing basic label pop" data-title="{{ trans('laralum.super_user') }}" data-variation="wide" data-content="{{ trans('laralum.super_user_desc') }}" data-position="top center" >{{ trans('laralum.super_user') }}</div>
                        @endif
                    </div>         
                  </td>
                  <td>
                    @if($user->banned)
                      <i data-position="top center" data-content="{{ trans('laralum.users_status_banned') }}" class="pop red close icon"></i>
                    @elseif(!$user->active)
                      <i data-position="top center" data-content="{{ trans('laralum.users_status_unactive') }}" class="pop orange warning icon"></i>
                    @else
                      <i data-position="top center" data-content="{{ trans('laralum.users_status_ok') }}" class="pop green checkmark icon"></i>
                    @endif
                    {{ $user->email }}
                  </td>
		  <td>
                    <!-- Boucle pour afficher les roles de chaque utilisateur -->
                    @foreach($roles_user as $role_user)
                      <!-- Si le role correspond au user courrant -->
                      @if($role_user->user_id == $user->id)
                        <!-- Parcours de tous les roles pour afficher les noms et pas les id-->
                        @foreach($roles as $role)
                          <!-- Si le role_user et le role correspondent-->
                          @if($role_user->role_id == $role->id)
                            <!-- Si le role est le role admin -->
                            @if($role->su)
                            <label class="label label-danger">{{ucfirst(strtolower($role->name))}}</label>
                            @else
                            <label class="label label-info">{{ucfirst(strtolower($role->name))}}</label>
                            @endif
                          @endif
                        @endforeach
                      @endif
                    @endforeach
                  </td>
                  <td>
                    <i class="fa fa-calendar"></i> {{ date('d/m/Y', strtotime($user->created_at)) }}
                  </td>
                  <td style="text-align:center;">
                    <!-- Test droit modification utilisateur -->
                    @if(Laralum::permissionToAccess('refarc.users.edit'))
                      @if(!$user->su)
                        <a href="{{ route('Laralum::users_edit', ['id' => $user->id]) }}" class="item">
                          <button type="button" class="btn btn-warning btn-xs" data-tooltip="tooltip" data-placement="top" title="Modifier l'utilisateur"><i class="fa fa-pencil"></i></button>
                        </a>
                      @else
                        <button type="button" class="btn btn-default btn-xs" data-tooltip="tooltip" data-placement="top" title="Modification impossible"><i class="fa fa-close"></i></button>
                      @endif
                    @else
                        <button type="button" class="btn btn-default btn-xs" data-tooltip="tooltip" data-placement="top" title="Modification impossible"><i class="fa fa-close"></i></button>
                    @endif
                    <!-- Test droit suppression utilisateur -->
                    @if(Laralum::permissionToAccess('refarc.users.delete'))
                      @if(!$user->su)
                        <a href="#" class="item" data-toggle="modal" data-target=".modal-{{ $user->id }}">
                          <button type="button" class="btn btn-danger btn-xs" data-tooltip="tooltip" data-placement="top" title="Supprimer l'utilisateur"><i class="fa fa-trash"></i></button>
                        </a>
                      @else
                        <button type="button" class="btn btn-default btn-xs" data-tooltip="tooltip" data-placement="top" title="Suppression impossible"><i class="fa fa-close"></i></button>
                      @endif
                    @else
                      <button type="button" class="btn btn-default btn-xs" data-tooltip="tooltip" data-placement="top" title="Suppression impossible"><i class="fa fa-close"></i></button>
                    @endif
                  </td>                                       
                </tr>
                <div class="modal fade modal-{{ $user->id }}" tabindex="-1" role="dialog" aria-hidden="true">
                  <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                      <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
                        </button>
                        <h4 class="modal-title" id="myModalLabel">Suppression d'un utilisateur</h4>
                       </div>
                        <div class="modal-body">
                          <p>Souhaitez-vous vraiment supprimer l'utilisateur "{{ $user->name }}" ?</p>
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>
                          <a href="{{ route('Laralum::users_delete',['id' => $user->id]) }}"><button type="button" class="btn btn-danger"><i class="fa fa-trash"></i> Supprimer</button></a>
                        </div>
                    </div>
                  </div>
                </div>
              @endforeach
            </tbody>
          </table>
        </div>
      </div>
    </div>
@endsection
@section('js')
<script type="text/javascript">
  $(document).ready(function() {
    var handleDataTableButtons = function() {
      if ($("#datatable-buttons").length) {
        $("#datatable-buttons").DataTable({
          dom: "Bfrtip",
          buttons: [
          {
            extend: "copy",
            className: "btn-sm"
          },
          {
            extend: "csv",
            className: "btn-sm"
          },
          {
            extend: "excel",
            className: "btn-sm"
          },
          {
            extend: "pdfHtml5",
            className: "btn-sm"
          },
          {
            extend: "print",
            className: "btn-sm"
          },
          ],
          //responsive: true
        });
      }
    };

    TableManageButtons = function() {
      "use strict";
      return {
        init: function() {
          handleDataTableButtons();
        }
      };
    }();
    TableManageButtons.init(); 
    $("#datatable-buttons_filter input").css("padding-top","0px");
    $("#datatable-buttons_filter input").css("padding-bottom","0px");

    $('body').tooltip({
      selector : "[data-tooltip=tooltip]",
      container : "body",
      trigger : 'hover'
    });
  });       
</script>
@endsection
@extends('layouts.admin.panel')
@section('breadcrumb')
<div class="ui breadcrumb">
<div class="active section"><i class="fa fa-list-ul"></i> Liste des roles</div>
</div>
@endsection
@section('title', trans('laralum.roles_title'))
@section('icon', "star")
@section('subtitle', trans('laralum.roles_subtitle'))
@section('content')

<div class="clearfix"></div>
<div class="row"> 
  <div class="col-md-12 col-sm-12 col-xs-12">
    <div class="x_panel">
    <div class="x_content">                    
      <table id="datatable-buttons" class="table table-striped table-bordered">
        <thead>
          <tr>
            <th>{{ trans('laralum.name') }}</th>
            <th>{{ trans('laralum.users') }}</th>
            <th>{{ trans('laralum.permissions') }}</th>
            <th>Date de création</th>
            <th>{{ trans('laralum.options') }}</th>
          </tr>
        </thead>
        <tbody>
          @foreach($roles as $role)
          <tr>
            <td>
              <h3>{{ $role->name }}
                @if($role->su)
                <i class="fa fa-question" data-toggle="tooltip" data-placement="right" title="Super Administrateur" data-original-title=""></i>
                @endif
              </h3>
            </td>
            <td style="vertical-align:middle;">
              <i class="fa fa-users"></i> {{ trans('laralum.roles_users', ['number' => count($role->users)]) }}
            </td>
            <td style="vertical-align:middle;">
              <i class="fa fa-lock"></i> {{ trans('laralum.roles_permissions', ['number' => count($role->permissions)]) }}
            </td>
            <td style="vertical-align:middle;">
              <i class="fa fa-calendar"></i> {{ $role->created_at }}
            </td>
            <td style="text-align:center;vertical-align:middle;">
              @if($role->allow_editing or Laralum::loggedInUser()->su)
              <!-- Bouton pour modifier un rôle -->
		@if(!$role->su)
              <a><button type="button" class="btn btn-warning btn-xs" data-toggle="modal" data-target=".modal_{{ $role->id }}" data-tooltip="tooltip" data-placement='top' title='Modifier le rôle'><i class="fa fa-pencil" ></i></button></a>
              <!--  Modal pour la modification d'un role -->
              <div class="modal fade modal_{{ $role->id }}" tabindex="-1" role="dialog" aria-hidden="true">
                <div class="modal-dialog modal-sm">
                  <div class="modal-content">

                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
                      </button>
                      <h4 class="modal-title" id="myModalLabel" style="text-align:center">Modification d'un rôle</h4>
                    </div>
                    <form method="POST">
                    <div class="modal-body" style="text-align:center;">
                        <label>Nom du rôle : </label><br><br>
                        <input type="text" id="new_role_name_{{ $role->id }}" class="form-control" value="{{ $role->name }}"><br><br>
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-default" data-dismiss="modal">Annuler</button>
                      <button id="update_role" type="button" class="btn btn-warning" onclick="updateRole({{ $role->id }})">Modifier</button>
                    </div>
                    </form>
                  </div>
                </div>
              </div>
		@endif
              <!-- Bouton pour accéder aux permissions -->
              <a href="{{ route('Laralum::roles_permissions', ['id' => $role->id]) }}"><button type="button" class="btn btn-warning btn-xs" data-toggle='tooltip' data-placement='top' title='Modifier les permissions'><i class="fa fa-lock"></i></button></a> 
              <!-- Bouton pour supprimer un rôle -->
	      @if(!$role->su)
              <button type="button" class="btn btn-danger btn-xs" data-toggle="modal" data-target=".modal_del_{{ $role->id }}" data-tooltip="tooltip" data-placement="top" title="Supprimer ce rôle"><i class="fa fa-trash"></i></button>                                 
              <div class="modal fade modal_del_{{ $role->id }}" tabindex="-1" role="dialog" aria-hidden="true">
                <div class="modal-dialog modal-sm">
                  <div class="modal-content">

                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
                      </button>
                      <h4 class="modal-title" id="myModalLabel" style="text-align:center">Suppression d'un rôle</h4>
                    </div>
                    <div class="modal-body" style="text-align:center;">
                        <span>Etes-vous sûr de vouloir supprimer le rôle {{ $role->name }}</span>
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-default" data-dismiss="modal">Annuler</button>
                      <a href="{{ route('Laralum::roles_delete', ['id' => $role->id]) }}"><button id="del_role" type="button" class="btn btn-danger">Supprimer</button></a>
                    </div>
                  </div>
                </div>
              </div>
		@endif
            </div>
            @else
            <div class="ui disabled {{ Laralum::settings()->button_color }} icon button">
              <i class="lock icon"></i>
            </div>
            @endif
          </td>
        </tr>
        @endforeach
      </tbody>
    </table>
  </div>
</div>
</div>
@endsection
@section('js')
<script type="text/javascript">
  $(document).ready(function() {
    var handleDataTableButtons = function() {
      if ($("#datatable-buttons").length) {
        $("#datatable-buttons").DataTable({
          dom: "Bfrtip",
          buttons: [
          {
            extend: "copy",
            className: "btn-sm"
          },
          {
            extend: "csv",
            className: "btn-sm"
          },
          {
            extend: "excel",
            className: "btn-sm"
          },
          {
            extend: "pdfHtml5",
            className: "btn-sm"
          },
          {
            extend: "print",
            className: "btn-sm"
          },
          ],
          
        });
      }
    };

    TableManageButtons = function() {
      "use strict";
      return {
        init: function() {
          handleDataTableButtons();
        }
      };
    }();


    $('#datatable-responsive').DataTable();        

    TableManageButtons.init(); 

    $("#datatable-buttons_filter").css("display","none");
    $(".dt-buttons").css("display","none");
    $('body').tooltip({
      selector : "[data-tooltip=tooltip]",
      container : "body",
      trigger : 'hover'
    });
  });   
  function updateRole(id){
      $.ajax({
          type: 'get',
          url: "roles/"+id+"/update?name="+$("#new_role_name_"+id).val()+"",
          success: function(result) { // Je récupère la réponse du fichier PHP
              $('.modal').modal('hide');
              location.reload();
              swal({
                title: "Modification",
                text: "Le role a bien été modifié",
                type: "success",
                confirmButtonText: "Fermer"
              });    
          }
      });
    }    
</script>
@endsection
@extends('layouts.admin.panel')
@section('breadcrumb')
    <div class="ui breadcrumb">
        <a class="section" href="{{ route('Laralum::roles') }}"><i class="fa fa-list"></i> {{ trans('laralum.roles_title') }}</a>
        / 
        <strong class="active section">{{ trans('laralum.roles_create_title') }}</strong>
    </div>
@endsection
@section('content')
    <div class="row">
        <div class="col-md-12">
            <div class="x_panel">
                <div class="x_content">
                <form method="POST">
                    {{ csrf_field() }}
                    <div class="col-md-6">
                        <label for="name">Nom du role :</label>
                        <input type="text" class="form-control" name="name">
                    </div><br><br><br>
                    <div>
                    <?php
                        $tabPermGroup = [];
                    ?>
                    @foreach($permissions as $permission)
                    <?php 
                        $perm = explode('.',$permission['slug']);
                        if(in_array($perm[1],$tabPermGroup)){
                            ?>
                            <span>
                                <input type="checkbox" value="{{ trans('permissions.'.$permission['slug']) }}" class="js-switch"> {{ trans('permissions.'.$permission['slug']) }}</input><br><br>
                            </span>
                            <?php
                        }
                        else{
                            echo('<h2>'.$perm[1].'</h2>');
                            array_push($tabPermGroup, $perm[1]);
                            ?>
                            <span>
                                <input type="checkbox" value="{{ trans('permissions.'.$permission['slug']) }}" class="js-switch"> {{ trans('permissions.'.$permission['slug']) }}</input><br><br>
                            </span>
                        <?php
                        }
                        ?>
                    @endforeach
                    </div>
                    <br>
                        <button type="submit" class="btn btn-success">Créer</button>
                </form>
                </div>
            </div>
        </div>
    </div>
@endsection

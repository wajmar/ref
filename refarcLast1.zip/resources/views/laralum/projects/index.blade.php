<?php use App\User; ?>
@extends('layouts.admin.panel')
@section('breadcrumb')
<div class="ui breadcrumb">
    <i class="fa fa-folder"></i>
    <a class="section" href="">{{ trans('laralum.projects_list') }}</a>
</div>
@endsection
@section('content')
<div class="clearfix"></div>

<div class="clearfix"></div>
<div class="row"> 

  <div class="col-md-12 col-sm-12 col-xs-12">
    <div class="x_panel">
      <div class="x_title">
        <h2>DAH</h2>
        
        <div class="clearfix"></div>
      </div>
      <div class="x_content"> 
        <ul id="myTab" class="nav nav-tabs bar_tabs" role="tablist">
          <li role="presentation" class="active"><a href="#tab_all_dah" id="home-tab" role="tab" data-toggle="tab" aria-expanded="true">Tous les DAH</a>
          </li>
          <li role="presentation" class=""><a href="#tab_my_dah" role="tab" id="profile-tab" data-toggle="tab" aria-expanded="false">Mes DAH</a>
          </li>
        </ul>
        <div id="myTabContent" class="tab-content">
          <div role="tabpanel" class="tab-pane fade active in" id="tab_all_dah" aria-labelledby="home-tab">
            <div>
              <input type="checkbox" id="checkbox_archives"><span style="font-size:14px;"> Inclure les DAH archivés</span></input>
            </div>
            <div>
              <img src="{{ asset('images/7.gif') }}" id="loader_dah" style="height:30px;display:none" >
            </div>
            <table id="datatable-buttons" class="table table-striped table-bordered">
              <thead>
                <tr>
                  <th>{{ trans('laralum.name') }}</th>              
                  <th>Créateur</th>
                  <th>Date de création</th>
                  <th>Date de dernière modification</th>
                  <th>Progression</th>
                  <th><span data-toggle="tooltip" data-placement="top" title="Actif ou Archivé">Statut</span></th>
                  <th>{{ trans('laralum.options') }}</th>
                </tr>
              </thead>
              <tbody id="body_table_dah">
                @foreach($projects as $project)
                <tr>
                  <td>
                    <b>{{ ucfirst($project->name) }}</b>                
                  </td>
                  <td>
                    <div class="text">
                      <a href="{{ route('Laralum::users_profile', ['id' => $project->user_id]) }}">
                        <i class="fa fa-user"></i> {{ User::find($project->user_id)->name }}
                      </a>
                    </div>
                  </td>              
                  <td width="10%">
                    {{ date('d/m/Y', strtotime($project->created_at)) }}
                  </td>
                  <td width="10%">
                    {{ date('d/m/Y', strtotime($project->updated_at)) }}
                  </td>
                  <td class="project_progress">
                    <?php $val = rand(1, 100);?>
                    <div class="progress progress_sm">
                      <div class="progress-bar bg-green" role="progressbar" data-transitiongoal="0" style="width:0%;" aria-valuenow="0"></div>
                    </div>
                    <small>0% Complete</small>
                  </td>
                  <td>
                    @if($project->archived == 0)
                      <label class="btn btn-xs btn-success"><i class="fa fa-check"></i> Actif</label>
                    @else
                      <label class="btn btn-xs btn-info">Archivé</label>
                    @endif
                  </td>
                  <td>
                      <a href="{{ route('Laralum::projects_suivi', ['id' => $project->id]) }}" class="btn btn-primary btn-xs" data-toggle="tooltip" data-placement="top" title="Consulter"><i class="fa fa-search"></i></a>
                      <button id="archive_btn" type="button" class="btn btn-xs btn-warning" data-toggle="tooltip" data-placement="top" title="Archiver" onclick="archived_projects({{ $project->id }},1)"><i class="fa fa-folder"></i></button>
                  </td> 
                </tr>
                @endforeach
              </tbody>
            </table>
          </div>
          <div role="tabpanel" class="tab-pane fade" id="tab_my_dah" aria-labelledby="profile-tab">
            <div>
              <input type="checkbox" id="checkbox_my_archives"><span style="font-size:14px;"> Inclure mes DAH archivés</span></input>
            </div>
            <div>
              <img src="{{ asset('images/7.gif') }}" id="loader" style="height:30px;display:none" >
            </div>
            <table id="datatable-buttons_mine" class="table table-striped table-bordered">
              <thead>
                <tr>
                  <th>{{ trans('laralum.name') }}</th>              
                  <th>Date de création</th>
                  <th>Date de dernière modification</th>
                  <th>Progression</th>
                  <th><span data-toggle="tooltip" data-placement="top" title="Actif ou Archivé">Statut</span></th>
                  <th>{{ trans('laralum.options') }}</th>
                </tr>
              </thead>
              <tbody id="body_table_dah">
                @foreach($myprojects as $myproject)
                <tr>
                  <td>
                    <b>{{ ucfirst($myproject->name) }}</b>                
                  </td>             
                  <td width="10%">
                    {{ date('d/m/Y', strtotime($myproject->created_at)) }}
                  </td>
                  <td width="10%">
                    {{ date('d/m/Y', strtotime($myproject->updated_at)) }}
                  </td>
                  <td class="project_progress">
                    <?php $val = rand(1, 100);?>
                    <div class="progress progress_sm">
                      <div class="progress-bar bg-green" role="progressbar" data-transitiongoal="0" style="width:0%;" aria-valuenow="0"></div>
                    </div>
                    <small>0% Complete</small>
                  </td>
                  <td>
                    @if($myproject->archived == 0)
                      <label class="btn btn-xs btn-success"><i class="fa fa-check"></i> Actif</label>
                    @else
                      <label class="btn btn-xs btn-info">Archivé</label>
                    @endif
                  </td>
                  <td>
                      <a href="{{ route('Laralum::projects_suivi', ['id' => $project->id]) }}" class="btn btn-primary btn-xs" data-toggle="tooltip" data-placement="top" title="Consulter"><i class="fa fa-search"></i></a>
                      <button id="archive_btn" type="button" class="btn btn-xs btn-warning" data-toggle="tooltip" data-placement="top" title="Archiver" onclick="archived_projects({{ $myproject->id }},1)"><i class="fa fa-archive"></i></button>
                  </td> 
                </tr>
                @endforeach
              </tbody>
            </table> 
          </div>
        </div>
    </div>
  </div>
</div>
@endsection
@section('js')
<script type="text/javascript">
  $(document).ready(function() {
    var archived = 0;
    var my_archived = 0
    var handleDataTableButtons = function() {
      if ($("#datatable-buttons").length) {
        $("#datatable-buttons").DataTable({
          dom: "Bfrtip",
          buttons: [
          {
            extend: "copy",
            className: "btn-sm"
          },
          {
            extend: "csv",
            className: "btn-sm"
          },
          {
            extend: "excel",
            className: "btn-sm"
          },
          {
            extend: "pdfHtml5",
            className: "btn-sm"
          },
          {
            extend: "print",
            className: "btn-sm"
          },
          ],
          
        });
      }
    };

    TableManageButtons = function() {
      "use strict";
      return {
        init: function() {
          handleDataTableButtons();
        }
      };
    }();


    $('#datatable-responsive').DataTable();        

    TableManageButtons.init(); 
    $(".dt-buttons").css("display","none");
    $("#datatable-buttons_filter").css("display","none");

    // checkbox pour inclure/enlever les DAH archivés
    $('#checkbox_archives').on('click',function(){
      // Appel ajax pour récuperer tous les DAH y compris les DAH archivés
      if(archived == 0){
        // Si cocher
        $("#loader_dah").css("display","block");
        $.ajax({
          type: 'get',
          url: '/admin/projects/list/all',
          success:function(result){
            console.log(typeof(result));
            $("#loader_dah").css("display","none");
            $("#datatable-buttons tbody").html("");
            result.forEach(function(element){
              // traitement pour le formatage des dates de mises a jour et de creation
              var date_elem_created = element.created_at.split(" ");
              var date_elem_updated = element.updated_at.split(" ");
              var date_elem_created = date_elem_created[0].split("-");
              var date_elem_updated = date_elem_updated[0].split("-");
              var true_date_elem_created = date_elem_created[2]+"/"+date_elem_created[1]+"/"+date_elem_created[0];
              var true_date_elem_updated = date_elem_updated[2]+"/"+date_elem_updated[1]+"/"+date_elem_updated[0];
              element.created_at = true_date_elem_created;
              element.updated_at = true_date_elem_updated;

              // Cellule du nom du projet
              if(element.archived == 1){
                var cell_1 = "<tr class='tr_archived'><td><b>"+element.name+"</b></td>";
              }
              else{
                var cell_1 = "<tr><td><b>"+element.name+"</b></td>";
              }
              // Cellule du createur
              var cell_2 = "<td><i class='fa fa-user'></i> "+element.user+"</td>";
              // Cellule de creation
              var cell_3 = "<td>"+element.created_at+"</td>";
              // Cellule de mise a jour
              var cell_4 = "<td>"+element.updated_at+"</td>";
              // Celle de progression
              var cell_5 = "<td><div class='progress progress_sm'><div class='progress-bar bg-green' role='progressbar' data-transitiongoal='0' style='width:0%;'' aria-valuenow='0'></div></div><small>0% Complete</small></td>";
              // Cellule du statut
              if(element.archived == 0){
                var cell_6 = "<td><label class='btn btn-xs btn-success'><i class='fa fa-check'></i> Actif</label></td>"
              }
              else{
                var cell_6 = "<td><label class='btn btn-xs btn-info'>Archivé</label></td>"
              }
              // Cellule des options
              // Test pour savoir si le document a été archivé
              if(element.archived == 0){
                var cell_7 = "<td><a href='' class='btn btn-primary btn-xs '><i class='fa fa-search'></i></a><button id='archive_btn' type='button' class='btn btn-xs btn-warning' data-toggle='tooltip' data-placement='top' title='Archiver' onclick='archived_projects("+element.id+",1)'><i class='fa fa-folder'></i></button></td>";
              }
              else{
                var cell_7 = "<td><a href='' class='btn btn-primary btn-xs '><i class='fa fa-search'></i></a><button id='archive_btn' type='button' class='btn btn-xs btn-danger' data-toggle='tooltip' data-placement='top' title='Désarchiver' onclick='archived_projects("+element.id+",2)'><i class='fa fa-folder-open'></i></button></td>";
              }
              
              var row = cell_1+cell_2+cell_3+cell_4+cell_5+cell_6+cell_7;
              $(row).appendTo("#datatable-buttons tbody");
            });
            $(".progress").css("margin-bottom",'5px');
            $('[data-toggle="tooltip"]').tooltip({
              trigger : 'hover'
            });
            archived = 1;
          }
        });    
      }
      else{
        // Si decocher
        $(".tr_archived").remove();
        archived = 0;
      }
    });

    // Checkbox pour afficher/enlever mes DAH archivés
    $('#checkbox_my_archives').on('click',function(){
      if(my_archived == 0){
        $("#loader").css("display","block");
        $.ajax({
          type: 'get',
          url: '/admin/projects/mylist/all',
          success:function(result){
            console.log(typeof(result));
            $("#loader").css("display","none");
            $("#datatable-buttons_mine tbody").html("");
            var result = Object.keys(result).map(function(k) { return result[k] });
            result.forEach(function(element){
            // traitement pour le formatage des dates de mises a jour et de creation
              var date_elem_created = element.created_at.split(" ");
              var date_elem_updated = element.updated_at.split(" ");
              var date_elem_created = date_elem_created[0].split("-");
              var date_elem_updated = date_elem_updated[0].split("-");
              var true_date_elem_created = date_elem_created[2]+"/"+date_elem_created[1]+"/"+date_elem_created[0];
              var true_date_elem_updated = date_elem_updated[2]+"/"+date_elem_updated[1]+"/"+date_elem_updated[0];
              element.created_at = true_date_elem_created;
              element.updated_at = true_date_elem_updated;

              // Cellule du nom du projet
              if(element.archived == 1){
                var cell_1 = "<tr class='tr_my_archived'><td><b>"+element.name+"</b></td>";
              }
              else{
                var cell_1 = "<tr><td><b>"+element.name+"</b></td>";
              }
              // Cellule de creation
              var cell_2 = "<td>"+element.created_at+"</td>";
              // Cellule de mise a jour
              var cell_3 = "<td>"+element.updated_at+"</td>";
              // Celle de progression
              var cell_4 = "<td><div class='progress progress_sm'><div class='progress-bar bg-green' role='progressbar' data-transitiongoal='0' style='width:0%;'' aria-valuenow='0'></div></div><small>0% Complete</small></td>";
              // Cellule du statut
              if(element.archived == 0){
                var cell_5 = "<td><label class='btn btn-xs btn-success'><i class='fa fa-check'></i> Actif</label></td>"
              }
              else{
                var cell_5 = "<td><label class='btn btn-xs btn-info'>Archivé</label></td>"
              }
              // Cellule des options
              if(element.archived == 0){
                var cell_6 = "<td><a href='' class='btn btn-primary btn-xs'><i class='fa fa-search'></i></a><button id='archive_btn' type='button' class='btn btn-xs btn-warning' data-toggle='tooltip' data-placement='top' title='Archiver' onclick='archived_projects("+element.id+",1)'><i class='fa fa-folder'></i></button></td>";
              }
              else{
                var cell_6 = "<td><a href='' class='btn btn-primary btn-xs'><i class='fa fa-search'></i></a><button id='archive_btn' type='button' class='btn btn-xs btn-danger' data-toggle='tooltip' data-placement='top' title='Desarchiver' onclick='archived_projects("+element.id+",2)'><i class='fa fa-folder-open'></i></button></td>";
              }
              var row = cell_1+cell_2+cell_3+cell_4+cell_5+cell_6;
              $(row).appendTo("#datatable-buttons_mine tbody");
            });
            $(".progress").css("margin-bottom",'5px');
            $('[data-toggle="tooltip"]').tooltip({
              trigger : 'hover'
            });
            my_archived = 1;
          }
        }); 
      }
      else{
        $(".tr_my_archived").remove();
        my_archived = 0;
      }
    }); 

    $('[data-toggle="tooltip"]').tooltip({
      trigger : 'hover'
    })  
  });  

  function archived_projects(id,state){
    window_h = (window.innerHeight)/2;
    $("body").append("<div id='loader_archive' style='height:100%;width:100%;background-color:black;position:absolute;top:0;z-index:10000;opacity:0.5;'><img src='{{ asset('images/7.gif') }}' style='width:60px;display:block;margin:auto;vertical-align:center;margin-top:"+window_h+"px'></div>");
    $.ajax({
      type: 'get',
      url: '/admin/projects/archives/'+id+'/'+state,
      success:function(result){
        //$("#loader_archive").css("display","none");
        console.log(result);
        if(result.archived == 0){
          console.log("desarchived");
        }
        else{
          console.log("archived"); 
        }
        location.reload();
      }
    });
  }

</script>

@endsection
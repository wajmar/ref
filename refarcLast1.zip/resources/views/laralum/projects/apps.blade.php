<?php
use App\User;
use App\TypeTpl;
?>
<div class="col-md-12 col-sm-12 col-xs-12">
    <div class="x_panel">
        <div class="x_content">
            <div align="center" class="value text-success">{{ round($percent,2) }}%</div>
            <div class="progress">
                <?php
                if (0 < round($percent,2) &&  round($percent,2) < 49) {
                    $clr = 'progress-bar-danger';
                } elseif (50 < round($percent,2) && round($percent,2) < 99) {
                    $clr = 'progress-bar-warning';
                }else {
                    $clr = 'progress-bar-success';
                }
                ?>
                <div class="progress-bar {{ $clr }} progress-bar-striped" role="progressbar"
                     aria-valuenow="12.5" aria-valuemin="0" aria-valuemax="100"
                     style="width:{{ $percent }}%">
                </div>
            </div>
            <br><br>
            <ul class="stats-overview">
                <li>
                    <span class="name"> Version de l'application </span>

                    <div class="value text-success" id="vers">{{ $version }}</div>
                </li>
                <li>
                    <span class="name"> Version du template </span>
                    <span class="value text-success"> {{ TypeTpl::find($tpl->type)->type }} : {{ $tpl->version }} </span>
                </li>
                <li class="hidden-phone">
                    <span class="name"> Dernière modification </span>
                    <span class="value text-success"> {{ date('d/m/Y', strtotime($appsParams->updated_at)) }} </span>
                </li>
            </ul>
            <br>
            @if(Laralum::loggedInUser()->hasPermission('refarc.applications.edit'))
                <div id="versionCtr" style="display: none;float:left;">
                    <form id="edit_app" data-parsley-validate="" class="form-horizontal form-label-left" novalidate=""
                          method="POST">
                        {{ csrf_field() }}
                        <div>
                            <button type="button" class="btn btn-success btn" data-toggle="modal"
                                    data-target=".bs-example-modal-lg"><i class="fa fa-save"></i> Enregistrer
                            </button>
                        </div>
                        <div id="modalAdd" class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog"
                             aria-hidden="true" style="display: none;">
                            <div class="modal-dialog modal-lg">
                                <div class="modal-content">

                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">×</span>
                                        </button>
                                        <h4 class="modal-title" id="myModalLabel2">Enregistrement des données</h4>
                                    </div>
                                    <div class="modal-body">
                                        <h4>Vous-voulez enregistrer les modifications ?</h4>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-default" data-dismiss="modal">Close
                                        </button>
                                        <button type="button" class="btn btn-success" onclick="saveDataApps('0');"><i
                                                    class="fa fa-save"></i> Enregistrer
                                        </button>
                                        @if(!$modified)
                                            <button type="button" class="btn btn-success" onclick="saveDataApps('1');"><i class="fa fa-level-up"></i>
                                                Enregistrer en version mineure
                                            </button>
                                            <button type="button" class="btn btn-success" onclick="saveDataApps('2');"><i class="fa fa-level-up"></i>
                                                Enregistrer en version majeure
                                            </button>
                                        @endif
                                    </div>

                                </div>
                            </div>
                        </div>
                        <input type="hidden" name="appname" id="appname" value="{{ $appsParams->id }}">
                    </form>

                </div>
                <a href="{{ route('Laralum::pdf',['id' => $appsParams->id ])}}">
                    <button type='button' class='btn btn-success' pull-right><i class='fa fa-file-pdf-o'></i> Generer
                        PDF
                    </button>
                </a>
            @endif
            <span id="loaderGlog"></span>
            <br>

            <form id="edit_app" data-parsley-validate="" class="form-horizontal form-label-left" novalidate=""
                  method="POST">
                {{ csrf_field() }}
                <div class="accordion" id="accordion" role="tablist" aria-multiselectable="true">
                    @foreach ($parents as $parent)
                        <?php
                        $readonly = '';
                        if (!Laralum::loggedInUser()->hasPermission('refarc.applications.edit')) {
                            $readonly = 'Readonly';
                        }
                        ?>
                        <div class="panel pan_{{ $parent->ordre }}" style="border-top:1px solid red;">
                            <div class="panel-heading">
                                <a role="tab" id="heading_{{ $parent->ordre }}" data-toggle="collapse"
                                   data-parent="#accordion" href="#collapse_{{ $parent->ordre }}" aria-expanded="true"
                                   aria-controls="collapseOne">
                                    <h4 class="panel-title" style="height:inherit">
                                        <span class="label label-danger">{{ $parent->num_parag }}</span>
                                        <span id="title_{{ $parent->id }}">{{ $parent->text }}</span>
                                </a>
              <span class="right">
              <span id="loader_{{ $parent->id }}"></span>

                  @if(Laralum::loggedInUser()->hasPermission('refarc.applications.edit'))
                      <?php
                      if ($parent->modified) {
                          echo '<span id="check_' . $parent->id . '"><i class="btn btn-success btn-xs fa fa-check" data-toggle="tooltip" data-placement="top"
                    data-original-title="Cette partie a été modifié"></i></span>';
                      } else {
                          echo '<span id="nocheck_' . $parent->id . '"><i class="btn btn-danger btn-xs fa fa-exclamation" data-toggle="tooltip" data-placement="top"
                    data-original-title="Cette partie n\'a pas été modifié"></i></span>';
                      }
                      ?>
                  @endif

                  <button type="button" class="btn btn-info btn-xs" data-toggle="modal"
                          data-target=".bs-modal_add_{{ $parent->id }}" id="modal_add_st_{{ $parent->id }}"
                          onclick="wizyAffiche({{ $parent->id }}, 1)">
                      Aide <i class="fa fa-question"></i></button>
                  <div id="modal_add_{{ $parent->id }}" class="modal fade bs-modal_add_{{ $parent->id }}" tabindex="-1"
                       role="dialog" aria-hidden="true" style="display: none;">
                      <div class="modal-dialog modal-lg">
                          <div class="modal-content">
                              <div class="modal-header">
                                  <button type="button" class="close" data-dismiss="modal"><span
                                              aria-hidden="true">×</span>
                                  </button>
                                  <h4 class="modal-title" id="myModalLabel">Aide</h4>
                              </div>
                              <div class="modal-body">
                                  <form id="edit_help" data-parsley-validate="" class="form-horizontal form-label-left"
                                        method="POST">
                                      {{ csrf_field() }}
                                      <div class="form-group">
                                          <textarea id="aideInput_{{ $parent->id }}"
                                                    class="aidedit_{{ $parent->id }}">{{ $parent->aide }}</textarea>
                                      </div>
                                      <div class="modal-footer">
                                          @if(Laralum::loggedInUser()->hasPermission('refarc.applications.edit'))
                                              <div id="mdf_{{ $parent->id }}">
                                                  <button onclick="modifComment({{ $parent->id }});" type="button"
                                                          class="btn btn-warning">
                                                      <i class="fa fa-pencil"></i> Modifier
                                                  </button>
                                              </div>
                                              <div id="ftr_{{ $parent->id }}" style="display: none;">
                                                  <button type="button" class="btn btn-default" data-dismiss="modal">
                                                      Fermer
                                                  </button>
                                                  <button type="button" class="btn btn-success"
                                                          onclick="addHelp({{ $parent->id }}, {{ $parent->num_parag }}, 1, {{ $parent->id_template }});">
                                                      Valider
                                                  </button>
                                  </form>
                                  @endif
                              </div>
                          </div>
                      </div>
                  </div>
                            </div>
                        </div>


                        </span>
                        </h4>
                </div>
                <div id="collapse_{{ $parent->ordre }}" class="panel-collapse collapse" role="tabpanel"
                     aria-labelledby="heading_{{ $parent->ordre }}">
                    <div class="panel-body">
                        <label>Partie fixe :</label><br>
                        <input type="hidden" name="version" value="{{ $tpl->version }}">
                        <input type="hidden" id="tplId" name="template_id" value="{{ $idTpl }}">
                        <input type="hidden" name="module" value="tpl">
                        <input type="hidden" id="num_parag_{{$parent->id}}" name="num_parag"
                               value="{{ $parent->num_parag }}">
                        <input type="hidden" id="niv_{{$parent->id}}" name="niv" value="{{ $parent->niv }}">
                        <input type="hidden" id="text_{{$parent->id}}" name="text" value="{{ $parent->text }}">
                        <input type="hidden" id="parent_{{$parent->id}}" name="parent" value="{{ $parent->parent }}">
                        <input type="hidden" id="ordre_{{$parent->id}}" name="ordre" value="{{ $parent->ordre }}">

                        <input type="hidden" id="id_parent_tpl_{{$parent->id}}" name="template_id"
                               value="{{$parent->id}}">
                        <textarea id="text_statFirsNiv_{{ $parent->id }}_{{ $parent->num_parag }}" name="text_stat"
                                  class="form-control mceEditor_{{$parent->id}}" rows="4">{{ $parent->text_stat }}</textarea>
                        <br>
                        @foreach ($first_nivs as $first_niv)
                            @if($first_niv->parent == $parent->id && $first_niv->niv == 1)
                                <div class="accordion_{{$parent->id}}_{{$first_niv->ordre}}"
                                     id="accordion_{{$parent->id}}_{{$first_niv->ordre}}" role="tablist"
                                     aria-multiselectable="true"><br>

                                    <div class="panel" style="border-top:2px solid lightblue;">
                                        <div class="panel-heading">
                                            <a role="tab" id="heading_{{$parent->id}}_{{$first_niv->ordre}}"
                                               data-toggle="collapse"
                                               data-parent="#accordion_{{$parent->id}}_{{$first_niv->ordre}}"
                                               href="#collapse_{{$parent->id}}_{{$first_niv->ordre}}"
                                               aria-expanded="true" aria-controls="collapseOne">
                                                <h4 class="panel-title">
                                                    <span class="label label-info">{{ $first_niv->num_parag }}</span>
                                                    <span id="title_{{ $first_niv->id }}">{{ $first_niv->text }}</span>
                                            </a>
                      <span class="right">
                      @if(Laralum::loggedInUser()->hasPermission('refarc.applications.edit'))
                              <?php
                              if ($first_niv->modified) {
                                  echo '<span id="check_' . $first_niv->id . '"><i class="btn btn-success btn-xs fa fa-check" data-toggle="tooltip" data-placement="top"
                          data-original-title="Cette partie a été modifié"></i></span>';
                              } else {
                                  echo '<span id="nocheck_' . $first_niv->id . '"><i id="danger" class="btn btn-danger btn-xs fa fa-exclamation" data-toggle="tooltip" data-placement="top"
                          data-original-title="Cette partie n\'a pas été modifié"></i></span>';
                              }
                              ?>
                              <span id="loader_{{ $first_niv->id }}"></span>
                          @endif
                    </span>
                                            </h4>
                                        </div>
                                        <div id="collapse_{{$parent->id}}_{{$first_niv->ordre}}"
                                             class="panel-collapse collapse" role="tabpanel"
                                             aria-labelledby="heading_{{$parent->id}}_{{$first_niv->ordre}}">
                                            <div class="panel-body">
                                                <label>Partie fixe :</label><br>
                                                <input type="hidden" name="version" value="{{ $tpl->version }}">
                                                <input type="hidden" name="module" value="tpl">
                                                <input type="hidden" id="num_parag_{{$first_niv->id}}" name="num_parag"
                                                       value="{{ $first_niv->num_parag }}">
                                                <input type="hidden" id="niv_{{$first_niv->id}}" name="niv"
                                                       value="{{ $first_niv->niv }}">
                                                <input type="hidden" id="text_{{$first_niv->id}}" name="text"
                                                       value="{{ $first_niv->text }}">
                                                <input type="hidden" id="parent_{{$first_niv->id}}" name="parent"
                                                       value="{{ $first_niv->parent }}">
                                                <input type="hidden" id="ordre_{{$first_niv->id}}" name="ordre"
                                                       value="{{ $first_niv->ordre }}">
                                                <input type="hidden" id="tpl_{{$first_niv->id}}" name="template_id"
                                                       value="{{ $first_niv->id_template }}">
                                                <input type="hidden" id="id_parent_tpl_{{$first_niv->id}}"
                                                       name="template_id" value="{{$first_niv->id}}">
                                                <textarea class="mceEditor_{{ $first_niv->id }} form-control" rows="4"
                                                          id="text_statFirsNiv_{{ $first_niv->id }}_{{ str_replace('.', '_', $first_niv->num_parag) }}">{{ $first_niv->text_stat }}</textarea>
                                                <br>
                                                @foreach ($second_nivs as $second_niv)
                                                    @if($second_niv->parent == $first_niv->id && $second_niv->niv == 2)
                                                        <div class="accordion_{{$first_niv->id}}_{{$second_niv->ordre}}"
                                                             id="accordion_{{$first_niv->id}}_{{$second_niv->ordre}}"
                                                             role="tablist" aria-multiselectable="true"><br>

                                                            <div class="panel" style="border-top:2px solid lightblue;">
                                                                <div class="panel-heading">
                                                                    <a role="tab"
                                                                       id="heading_{{$first_niv->id}}_{{$second_niv->ordre}}"
                                                                       data-toggle="collapse"
                                                                       data-parent="#accordion_{{$first_niv->id}}_{{$second_niv->ordre}}"
                                                                       href="#collapse_{{$first_niv->id}}_{{$second_niv->ordre}}"
                                                                       aria-expanded="true" aria-controls="collapseOne">
                                                                        <h4 class="panel-title">
                                                                            <span class="label label-warning">{{ $second_niv->num_parag }}</span>
                                                                            <span id="title_{{ $second_niv->id }}">{{ $second_niv->text }}</span>
                                                                    </a>
                            <span class="right">
                            @if(Laralum::loggedInUser()->hasPermission('refarc.applications.edit'))
                                    <?php
                                    if ($second_niv->modified) {
                                        echo '<span id="check_' . $second_niv->id . '"><i class="btn btn-success btn-xs fa fa-check" data-toggle="tooltip" data-placement="top"
                                  data-original-title="Cette partie a été modifié"></i></span>';
                                    } else {
                                        echo '<span id="nocheck_' . $second_niv->id . '"><i class="btn btn-danger btn-xs fa fa-exclamation" data-toggle="tooltip" data-placement="top"
                                  data-original-title="Cette partie n\'a pas été modifié"></i></span>';
                                    }
                                    ?>
                                    <span id="loader_{{ $second_niv->id }}"></span>
                                @endif
                            </span>
                                                                    </h4>
                                                                </div>
                                                                <div id="collapse_{{$first_niv->id}}_{{$second_niv->ordre}}"
                                                                     class="panel-collapse collapse" role="tabpanel"
                                                                     aria-labelledby="heading_{{$first_niv->id}}_{{$second_niv->ordre}}">
                                                                    <div class="panel-body">
                                                                        <label>Partie fixe :</label><br>
                                                                        <input type="hidden" name="version"
                                                                               value="{{ $tpl->version }}">
                                                                        <input type="hidden" name="module" value="tpl">
                                                                        <input type="hidden"
                                                                               id="num_parag_{{$second_niv->id}}"
                                                                               name="num_parag"
                                                                               value="{{ $second_niv->num_parag }}">
                                                                        <input type="hidden"
                                                                               id="niv_{{$second_niv->id}}" name="niv"
                                                                               value="{{ $second_niv->niv }}">
                                                                        <input type="hidden"
                                                                               id="text_{{$second_niv->id}}" name="text"
                                                                               value="{{ $second_niv->text }}">
                                                                        <input type="hidden"
                                                                               id="parent_{{$second_niv->id}}"
                                                                               name="parent"
                                                                               value="{{ $second_niv->parent }}">
                                                                        <input type="hidden"
                                                                               id="ordre_{{$second_niv->id}}"
                                                                               name="ordre"
                                                                               value="{{ $second_niv->ordre }}">
                                                                        <input type="hidden"
                                                                               id="tpl_{{$second_niv->id}}"
                                                                               name="template_id"
                                                                               value="{{ $second_niv->id_template }}">
                                                                        <input type="hidden"
                                                                               id="id_parent_tpl_{{$second_niv->id}}"
                                                                               name="template_id"
                                                                               value="{{$second_niv->id}}">
                                                                        <textarea class="mceEditor_{{$second_niv->id}} form-control"
                                                                                  rows="4"
                                                                                  id="text_statFirsNiv_{{ $second_niv->id }}_{{ str_replace('.', '_', $second_niv->num_parag) }}">{{ $second_niv->text_stat }}</textarea><br>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
            </form>
            @endif
            @endforeach
        </div>
    </div>
</div>
</div>
@endif
@endforeach
</div>
</div>
</div>
@endforeach
</div>
</div>
</div>
@section('js')
    <script type="text/javascript">
    </script>
@endsection

    <?php use App\User; ?>
    @extends('layouts.admin.panel')
    @section('breadcrumb')    
    <div class="ui breadcrumb">
    <i class="fa fa-edit"></i>
        <a class="section" href="{{ route('Laralum::projects') }}">{{ trans('laralum.projects_list') }}</a>
        / <small>{{ trans('laralum.projects_edit') }}</small>
    </div>
    @endsection
    @section('title', trans('laralum.projects_edit'))
    @section('icon', "edit")
    @section('subtitle', ucfirst($rows->name))
    @section('content')
    
    <div class="x_panel">
      <div class="x_title">
      <?php 
        if($rows->statu == 0) {
            $class = 'alert-danger';
            $txt = 'Draft';
        } else {
            $class = 'alert-success';
            $txt = 'Validé';
        }
      ?>
        <div class="alert <?php echo $class; ?> alert-dismissible fade in" role="alert">
            <strong><?php echo $txt; ?>!</strong>
        </div>
        <ul class="nav navbar-right panel_toolbox">
    </ul>
    </div>
    <div class="x_content">
        <br>
        <form id="edit_project" data-parsley-validate="" class="form-horizontal form-label-left" novalidate="" method="POST">

          <div class="form-group">
            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Projet <span class="required">*</span>
            </label>
            <div class="col-md-6 col-sm-6 col-xs-12">
              <input id="name" name="name" required="required" class="form-control col-md-7 col-xs-12" type="text" value="{{ ucfirst($rows->name) }}">
          </div>
      </div>
      <div class="form-group">
        <label class="control-label col-md-3 col-sm-3 col-xs-12">
            {{ trans('laralum.description') }}
        </label>
        <div class="col-md-9 col-sm-9 col-xs-12">
          <textarea  name="description" class="form-control" rows="3" style="width: 611px; height: 110px;">{{ $rows->description }}</textarea>
      </div>
    </div>
    <div class="form-group">
        <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">Date de création</label>
        <div class="col-md-2">
        <input value="{{ date('d/m/Y', strtotime($rows->created_at)) }}" class="form-control has-feedback-left" name="created_at" type="text" readonly="true">
        <span class="fa fa-calendar form-control-feedback left" aria-hidden="true"></span>
      </div>
      <div class="col-md-2">
        <input value="{{ User::find($rows->user_id)->name }}" class="form-control has-feedback-left" name="user" type="text" readonly="true">
        <span class="fa fa-user form-control-feedback left" aria-hidden="true"></span>
      </div>
    </div>
    <div class="form-group">
        <label class="control-label col-md-3 col-sm-3 col-xs-12">Nombre d'applications
        </label>
        <div class="col-md-1">
        <input value="{{ $rows->nb_apps }}" class="form-control has-feedback-left" name="nb_apps" type="text" readonly="true">        
      </div>
    </div>
    <input type="hidden" name="user_id" value="{{$rows->user_id}}">
    <input type="hidden" name="_token" value="<?php echo csrf_token() ?>">
    <div class="ln_solid"></div>
    <div class="form-group">
        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-7">
          <a href="{{ route('Laralum::projects') }}"><button type="submit" class="btn btn-primary">Cancel</button></a>
          <button type="submit" class="btn btn-success">Submit</button>
      </div>
    </div>
    </form>
    </div>
    </div>
    @endsection
    
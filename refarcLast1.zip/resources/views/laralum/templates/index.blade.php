<?php
use App\User;
use App\TypeTpl;
?>
@extends('layouts.admin.panel')
@section('breadcrumb')
<div class="ui breadcrumb">
  <i class="fa fa-newspaper-o"></i>
  <a class="section" href="">Gestion des template</a>
</div>
@endsection
@section('content')
<div class="clearfix"></div>
<div class="row"> 
  <div class="col-md-12 col-sm-12 col-xs-12">
    <div class="x_panel">
      <div class="x_title">
        
        @if(Laralum::loggedInUser()->hasPermission('refarc.templates.create'))
                 <div class="col-md-6">
          <label onclick="delType();" class="btn btn-success pull-left" data-toggle="modal" data-target=".modaladdapp"><i class="fa fa-plus"></i> Ajouter template</label>
          </div>
                 @endif
                 <div id="modal_app" class="modal fade modaladdapp" tabindex="-1" role="dialog" aria-hidden="true">
                   <div class="modal-dialog modal-lg">
                     <div class="modal-content">
                       <div class="modal-header" style="text-align: center">
                         <div class="modal-title"><h2>Ajouter nouveau template</h2></div>
                         <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">X</span>
                         </div>
                         <div class="modal-body">
                           <form id="edit_app" data-parsley-validate="" class="form-horizontal form-label-left" novalidate="" method="POST">
                           <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Type du document <span class="required">*</span>
                              </label>
                              <div class="col-md-6 col-sm-6 col-xs-12">
                                <select id="type" name="type" class="form-control">
                                  @foreach($tpltype as $type)
                                  <option value="{{ $type->id }}">{{ $type->type }}</option>
                                  @endforeach
                                </select>
                              </div>
                            </div>
                            <div id="adTypeDisc" class="form-group">
                              <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Description
                              </label>
                              <div class="col-md-6 col-sm-6 col-xs-12">
                                <textarea  id="comment" name="comment" class="form-control" rows="3" style="width: 414px; height: 91px;"></textarea>
                              </div>
                            </div>                                                                                
                            <input type="hidden" name="_token" value="<?php echo csrf_token() ?>">
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>
                          <button id="updateproj" type="button" class="btn btn-success"  onclick="createTpl();">
                          <i class="fa fa-plus"></i> Ajouter template</button>
                        </div>
                        </form>
                      </div>
                  </div>
                 </div>
        <ul class="nav navbar-right panel_toolbox">
          <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
          </li>
          <li class="dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
          </li>
          </li>
        </ul>
        <div class="clearfix"></div>
      </div>
      <div class="x_content">                    
        <table id="datatable-buttons" class="table table-striped table-bordered">
          <thead>
            <tr>
              <th>Version</th>  
              <th>Commentaire</th>             
              <th>Créateur</th>
              <th>Type</th>
              <th>Date de création</th>
              <th>Date de dernière modification</th>
              <th>{{ trans('laralum.options') }}</th>
            </tr>
          </thead>
          <tbody>
            @foreach($templates as $template)
            <tr>
              <td>
                <b>{{ ucfirst($template->version) }}</b>                
              </td>
              <td>
                {{ $template->comment }}
              </td>
              <td>
                <div class="text">
                  <a href="{{ route('Laralum::users_profile', ['id' => $template->user_id]) }}">
                   <i class="fa fa-user"></i> {{ User::find($template->user_id)->name }}
                 </a>
               </div>
             </td>
             <td>
                {{ TypeTpl::find($template->type)->type }}
             </td>              
             <td>
              {{ date('d/m/Y', strtotime($template->created_at)) }}
            </td>
            <td width="10%">
              {{ date('d/m/Y', strtotime($template->updated_at)) }}
            </td>            
             <td>
				<div align="center">
					@if( $template->nbapps == 0 )
						<form id="deltpl" data-parsley-validate="" class="form-horizontal form-label-left" method="POST">
							<button onclick="delTpl({{ $template->id }})" type="button" class="btn btn-danger btn-xs"><i class="fa fa-trash"></i></button>
							{{ csrf_field() }}
					@else
							<button onclick="" disabled type="button" class="btn btn-danger btn-xs"><i class="fa fa-trash"></i></button>
					@endif
							<a href="{{ route('Laralum::templates_suivi', ['id' => $template->id]) }}"
							   class="btn btn-primary btn-xs"><i class="fa fa-search"></i></a>
					@if( $template->nbapps == 0 && $template->valid == 0)
						<form id="validtpl" data-parsley-validate="" class="form-horizontal form-label-left" method="POST">
							<button onclick="validTpl({{ $template->id }})" type="button" class="btn btn-success btn-xs"><i class="fa fa-check"></i></button>
							{{ csrf_field() }}
						</form>
					@else
							<button disabled onclick="" type="button" class="btn btn-danger btn-xs"><i class="fa fa-close"></i></button>
					@endif
				</div>
				</form>
			</td>
          </tr>
          @endforeach
        </tbody>
      </table>
    </div>
  </div>
</div>
@endsection
@section('js')
<script type="text/javascript">
  $(document).ready(function() {
    var handleDataTableButtons = function() {
      if ($("#datatable-buttons").length) {
        $("#datatable-buttons").DataTable({
          dom: "Bfrtip",
          buttons: [
          {
            extend: "copy",
            className: "btn-sm"
          },
          {
            extend: "csv",
            className: "btn-sm"
          },
          {
            extend: "excel",
            className: "btn-sm"
          },
          {
            extend: "pdfHtml5",
            className: "btn-sm"
          },
          {
            extend: "print",
            className: "btn-sm"
          },
          ],
          
        });
      }
    };

    TableManageButtons = function() {
      "use strict";
      return {
        init: function() {
          handleDataTableButtons();
        }
      };
    }();


    $('#datatable-responsive').DataTable();        

    TableManageButtons.init(); 

  }); 
  function createTpl() {
    var comment = $('#comment').val();
    var type = $('#type').val();  
    
    var _token = $('input[name=_token]').val();
    var formData = {type:type, comment:comment, _token: _token};
    url = "create";
    $('#modal_app').hide();
    $.ajax({
      type: 'post',
      data : formData,
      url: url,
      success: function(result) {       
        if (result) {
          var url = '{{ route('Laralum::templates_suivi', ":id") }}';
          url = url.replace(':id', result);
          document.location.href = url;
        }
      }
    });
  }
  function delTpl(id) {
	var _token = $('input[name=_token]').val();
	var formData = {idTpl: id, _token: _token};
	swal({
		title: "Supprimer template",
		text: "Voulez-vous supprimer le template ?",
		//type: "info",
		showCancelButton: true,
		closeOnConfirm: false,
		showLoaderOnConfirm: true
	}, function () {
		$.ajax({
			type: 'post',
			url: 'templates/delTpls',
			data: formData,
			success: function (result) {
				location.reload();
				//setTimeout(function () {
				//swal("Le template "+version+" a bien �t� supprim�!");
				//});
			}
		});
	});
}
function validTpl(id) {
	var _token = $('input[name=_token]').val();
	var formData = {idTpl: id, _token: _token};
	swal({
		title: "Validation template",
		text: "Attention, une fois validé le template ne sera plus modifiable!",
		type: "info",
		showCancelButton: true,
		closeOnConfirm: false,
		showLoaderOnConfirm: true
	}, function () {
		$.ajax({
			type: 'post',
			url: 'templates/validTpl',
			data: formData,
			success: function (result) {
				location.reload();
			}
		});
	});
}
</script>
@endsection

<?php
use App\User;
use App\TypeTpl;
?>
<div class="col-md-12 col-sm-12 col-xs-12">
	<div class="x_panel">
		<div class="x_content">		      
			<form id="edit_app" data-parsley-validate="" class="form-horizontal form-label-left" novalidate="" method="POST">
				{{ csrf_field() }}
				@if(Laralum::loggedInUser()->hasPermission('refarc.templates.edit') && $tpl->nbapps == 0  && $tpl->valid == 0)
				<div><button id="addprg" type="button" class="btn btn-success btn-xs" data-toggle="modal" data-target=".bs-modal_add_cmp"><i class="fa fa-plus"></i> Ajouter nouvelle partie</button></div>
				<div id="modal_add_cmp" class="modal fade bs-modal_add_cmp" tabindex="-1" role="dialog" aria-hidden="true" style="display: none;">
					<div class="modal-dialog modal-lg">
						<div class="modal-content">
							<div class="modal-header">
								<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
								</button>
								<h4 class="modal-title" id="myModalLabel">Ajouter paragraphe</h4>
							</div>
							<div class="modal-body">
								<div class="form-group">											<label class="control-label col-md-3 col-sm-3 col-xs-12" for=	"name">Titre du paragraphe <span class="required">*</span>
								</label>
								<div class="col-md-8">
									<input id="text_new" value="" class="form-control" name="text" type="text">        
								</div>
							</div>
							<div class="form-group">
								<label>Partie fixe :</label><br>
								<textarea id="prgN" class="mceEditorAdd form-control" rows="4"></textarea>
							</div>
							<div class="modal-footer">
								<button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>
								<button type="button" class="btn btn-success" onclick="addNewParagraph({{$id}});">Ajouter</button>
							</div>
						</div>
					</div>
				</div>
			</div>
			@endif
			<br><br>
			<div class="accordion" id="accordion" role="tablist" aria-multiselectable="true">
				@foreach ($parents as $parent)
				<?php 					
				$exp = explode('.', $parent->num_parag);
				$readonly = '';
				if (!Laralum::loggedInUser()->su) {
					$readonly = 'Readonly';
				}
				?>
				<div class="panel pan_{{ $parent->ordre }}" style="border-top:1px solid red;">
					<div class="panel-heading">							
						<a role="tab" id="heading_{{ $parent->ordre }}" data-toggle="collapse" data-parent="#accordion" href="#collapse_{{ $parent->ordre }}" aria-expanded="true" aria-controls="collapseOne">
							<h4 class="panel-title" style="height:inherit">
								<span class="label label-danger">{{ $parent->num_parag }}</span>
								<span id="title_{{ $parent->id }}">{{ $parent->text }}</span>
							</a>
							<span class="right">
							@if(Laralum::loggedInUser()->hasPermission('refarc.templates.edit') && $tpl->nbapps == 0  && $tpl->valid == 0)
								<span id="loader_{{ $parent->id }}"></span>
								<button type="button" class="btn btn-success btn-xs" data-toggle="modal" data-target=".bs-modal_add_{{ $parent->id }}" id="modal_add_st_{{ $parent->id }}">
									<i class="fa fa-plus"></i> Ajouter un sous-titre</button>
									<div id="modal_add_{{ $parent->id }}" class="modal fade bs-modal_add_{{ $parent->id }}" tabindex="-1" role="dialog" aria-hidden="true" style="display: none;">
										<div class="modal-dialog modal-lg">
											<div class="modal-content">
												<div class="modal-header">
													<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
													</button>
													<h4 class="modal-title" id="myModalLabel">Ajouter patragraphe</h4>
												</div>
												<div class="modal-body">
													<div class="form-group">											<label class="control-label col-md-3 col-sm-3 col-xs-12" for=	"name">Titre du patragraphe <span class="required">*</span>
													</label>
													<div class="col-md-8">
														<input id="text_parent_add_{{ $parent->id }}" value="" class="editor form-control" name="text" type="text">        
													</div>
												</div>
												<div class="form-group">
													<label>Partie fixe :</label><br>												
													<textarea class="mceEditor_{{ $parent->id }} form-control" rows="4" id="text_stat_parent_add_{{ $parent->id }}"></textarea>
													<div id="editor"></div>
												</div>
												<div class="modal-footer">
													<button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>
													<button type="button" class="btn btn-success" onclick="addParagraph({{ $parent->id }}, {{ $parent->num_parag }}, 1, {{ $parent->id_template }});">Ajouter</button>
												</div>
											</div>
										</div>
									</div>
								</div>
								@endif


								@if(Laralum::loggedInUser()->hasPermission('refarc.templates.edit') && $tpl->nbapps == 0  && $tpl->valid == 0)
								<button type="button" class="btn btn-warning btn-xs" data-toggle="modal" data-target=".bs-modal_{{ $parent->id }}"><i class="fa fa-pencil"></i> Modifier le titre</button>
								<div id="modal_{{ $parent->id }}" class="modal fade bs-modal_{{ $parent->id }}" tabindex="-1" role="dialog" aria-hidden="true" style="display: none;">
									<div class="modal-dialog modal-lg">
										<div class="modal-content">
											<div class="modal-header">
												<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
												</button>
												<h4 class="modal-title" id="myModalLabel">Titre du patragraphe</h4>
											</div>
											<div class="modal-body">
												<div class="form-group">											
													<div class="col-md-12">
														<input id="text_parent_{{ $parent->id }}" value="{{ $parent->text }}" class="form-control" name="text" type="text">        
													</div>
												</div>
												<div class="modal-footer">
													<button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>
													<button type="button" class="btn btn-warning" onclick="savetpl({{ $parent->id }}, 'title');">Modifier</button>
												</div>
											</div>
										</div>
									</div>
								</div>
								<button id="save" type="button" class="btn btn-info btn-xs"
								onclick="savetpl({{ $parent->id }});"><i class="fa fa-save"></i> Valider le contenu</button>
								<button type="button" class="btn btn-danger btn-xs sweet-4"
								onclick="deletPrg({{ $parent->id }}, 0, {{ $parent->num_parag }}, 0);"><i class="fa fa-trash"></i></button>
								@endif
							</span>
						</h4>
					</div>
					<div id="collapse_{{ $parent->ordre }}" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading_{{ $parent->ordre }}">
						<div class="panel-body">
							<label>Partie fixe :</label><br>
							<input type="hidden" name="version" value="{{ $tpl->version }}">
							<input type="hidden" name="module" value="tpl">							
							<textarea id="text_statFirsNiv_{{ $parent->id }}" name="text_stat" class="form-control mceEditor_{{ $parent->id }}" rows="4" readonly="readonly">{{ $parent->text_stat }}</textarea>							
							<br>
							@foreach ($first_nivs as $first_niv)
							@if($first_niv->parent == $parent->id && $first_niv->niv == 1)
							<div class="accordion_{{$parent->id}}_{{$first_niv->ordre}}" id="accordion_{{$parent->id}}_{{$first_niv->ordre}}" role="tablist" aria-multiselectable="true"><br>
								<div class="panel" style="border-top:2px solid lightblue;">
									<div class="panel-heading">
										<a role="tab" id="heading_{{$parent->id}}_{{$first_niv->ordre}}" data-toggle="collapse" data-parent="#accordion_{{$parent->id}}_{{$first_niv->ordre}}" href="#collapse_{{$parent->id}}_{{$first_niv->ordre}}" aria-expanded="true" aria-controls="collapseOne">						
											<h4 class="panel-title">											
												<span class="label label-info">{{ $first_niv->num_parag }}</span> <span id="title_{{ $first_niv->id }}">{{ $first_niv->text }}</span>
											</a>
											<span class="right">
											@if(Laralum::loggedInUser()->hasPermission('refarc.templates.edit') && $tpl->nbapps == 0  && $tpl->valid == 0)
												<span id="loader_{{ $first_niv->id }}"></span>
												<button type="button" class="btn btn-success btn-xs" data-toggle="modal" data-target=".bs-modal_add_{{ $first_niv->id }}" id="modal_add_st_{{ $first_niv->id }}">
													<i class="fa fa-plus"></i> Ajouter un sous-titre</button>
													<div id="modal_add_{{ $first_niv->id }}" class="modal fade bs-modal_add_{{ $first_niv->id }}" tabindex="-1" role="dialog" aria-hidden="true" style="display: none;">
														<div class="modal-dialog modal-lg">
															<div class="modal-content">
																<div class="modal-header">
																	<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
																	</button>
																	<h4 class="modal-title" id="myModalLabel">Ajouter patragraphe</h4>
																</div>
																<div class="modal-body">
																	<div class="form-group">											<label class="control-label col-md-3 col-sm-3 col-xs-12" for=	"name">Titre du patragraphe <span class="required">*</span>
																	</label>
																	<div class="col-md-8">
																		<input id="text_parent_add_{{ $first_niv->id }}" value="" class="form-control" name="text" type="text">        
																	</div>
																</div>
																<div class="form-group">
																	<label>Partie fixe :</label><br>
																	<textarea class="mceEditor_{{ $first_niv->id }} form-control" rows="4" id="text_stat_parent_add_{{ $first_niv->id }}"></textarea>
																</div>
																<div class="modal-footer">
																	<button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>
																	<button type="button" class="btn btn-success" onclick="addParagraph({{ $first_niv->id }}, {{ $first_niv->num_parag }}, 2, {{ $first_niv->id_template }});">Ajouter</button>
																</div>
															</div>
														</div>
													</div>
												</div>
												@endif
												@if(Laralum::loggedInUser()->hasPermission('refarc.templates.edit') && $tpl->nbapps == 0  && $tpl->valid == 0)
												<button type="button" class="btn btn-warning btn-xs" data-toggle="modal" data-target=".bs-modal_{{ $first_niv->id }}"><i class="fa fa-pencil"></i> Modifier le titre</button>
												<div id="modal_{{ $first_niv->id }}" class="modal fade bs-modal_{{ $first_niv->id }}" tabindex="-1" role="dialog" aria-hidden="true" style="display: none;">
													<div class="modal-dialog modal-lg">
														<div class="modal-content">
															<div class="modal-header">
																<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
																</button>
																<h4 class="modal-title" id="myModalLabel">Titre du patragraphe</h4>
															</div>
															<div class="modal-body">
																<div class="form-group">											
																	<div class="col-md-12">
																		<input id="text_parent_{{ $first_niv->id }}" value="{{ $first_niv->text }}" class="form-control" name="text" type="text">        
																	</div>
																</div>

															</div>
															<div class="modal-footer">
																<button type="button" class="btn btn-default"
																data-dismiss="modal">Fermer</button>
																<button type="button" class="btn btn-warning"
																onclick="savetpl({{ $first_niv->id }}, 'title');">Modifier
															</button>
														</div>
													</div>
												</div>
											</div>											
											<button type="button" class="btn btn-info btn-xs"
											onclick="savetpl({{ $first_niv->id }});"><i class="fa fa-save"></i> Valider le contenu</button>
											<button type="button" class="btn btn-danger btn-xs sweet-4"
											onclick="deletPrg({{ $first_niv->id }}, 1, {{ $first_niv->num_parag }},
											{{ $parent->id }});"><i class="fa fa-trash"></i></button>
											@endif
										</span>
									</h4>
								</div>
								<div id="collapse_{{$parent->id}}_{{$first_niv->ordre}}" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading_{{$parent->id}}_{{$first_niv->ordre}}">
									<div class="panel-body">
										<label>Partie fixe :</label><br>
										<input type="hidden" name="version" value="{{ $tpl->version }}">
										<textarea class="mceEditor_{{ $first_niv->id }} form-control" rows="4" {{$readonly}} id="text_statFirsNiv_{{ $first_niv->id }}">{{ $first_niv->text_stat }}</textarea>
										<br>												
										@foreach ($second_nivs as $second_niv)
										@if($second_niv->parent == $first_niv->id && $second_niv->niv == 2)
										<div class="accordion_{{$first_niv->id}}_{{$second_niv->ordre}}" id="accordion_{{$first_niv->id}}_{{$second_niv->ordre}}" role="tablist" aria-multiselectable="true"><br>
											<div class="panel" style="border-top:2px solid lightblue;">
												<div class="panel-heading">
													<a role="tab" id="heading_{{$first_niv->id}}_{{$second_niv->ordre}}" data-toggle="collapse" data-parent="#accordion_{{$first_niv->id}}_{{$second_niv->ordre}}" href="#collapse_{{$first_niv->id}}_{{$second_niv->ordre}}" aria-expanded="true" aria-controls="collapseOne">
														<h4 class="panel-title">															
															<span class="label label-warning">{{ $second_niv->num_parag }}</span>
															<span id="title_{{ $second_niv->id }}">{{ $second_niv->text }}</span>
														</a>
														<span class="right">
														@if(Laralum::loggedInUser()->hasPermission('refarc.templates.edit') && $tpl->nbapps == 0  && $tpl->valid == 0)
															<span id="loader_{{ $second_niv->id }}"></span>
															<button type="button" class="btn btn-warning btn-xs" data-toggle="modal" data-target=".bs-modal_{{ $second_niv->id }}"><i class="fa fa-pencil"></i> Modifier le titre</button>
															<div id="modal_{{ $second_niv->id }}" class="modal fade bs-modal_{{ $second_niv->id }}" tabindex="-1" role="dialog" aria-hidden="true" style="display: none;">
																<div class="modal-dialog modal-lg">
																	<div class="modal-content">
																		<div class="modal-header">
																			<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
																			</button>
																			<h4 class="modal-title" id="myModalLabel">Titre du patragraphe</h4>
																		</div>
																		<div class="modal-body">
																			<div class="form-group">											
																				<div class="col-md-12">
																					<input id="text_parent_{{ $second_niv->id }}" value="{{ $second_niv->text }}" class="form-control" name="text" type="text">        
																				</div>
																			</div>
																			<div class="modal-footer">
																				<button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>
																				<button type="button" class="btn btn-warning" onclick="savetpl({{ $second_niv->id }}, 'title');">Modifier</button>
																			</div>
																		</div>
																	</div>
																</div>
															</div>															
															<button type="button" class="btn btn-info btn-xs" 
															onclick="savetpl({{ $second_niv->id }});"><i class="fa fa-save"></i> Valider le contenu</button>
															<button type="button" class="btn btn-danger btn-xs sweet-4"
															onclick="deletPrg({{ $second_niv->id }}, 2, '{{ $second_niv->num_parag }}', {{ $first_niv->id }});"><i class="fa fa-trash"></i></button>
															@endif
														</span>
													</h4>
												</div>
												<div id="collapse_{{$first_niv->id}}_{{$second_niv->ordre}}" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading_{{$first_niv->id}}_{{$second_niv->ordre}}">
													<div class="panel-body">
														<label>Partie fixe :</label><br>
														<input type="hidden" name="version" value="{{ $tpl->version }}">
														<textarea class="mceEditor_{{ $second_niv->id }} form-control" rows="4" {{$readonly}} id="text_statFirsNiv_{{ $second_niv->id }}">{{ $second_niv->text_stat }}</textarea><br>
													</div>
												</div>
											</div>										
										</div>
									</form>
									@endif
									@endforeach
								</div>
							</div>
						</div>										
					</div>
					@endif
					@endforeach
				</div>
			</div>
		</div>
		@endforeach
	</div>
</div>
</div>
@section('js')
@endsection
@foreach($tpl_types as $tpl_type)
            <!-- Initialisation du compteur -->
            <?php 
              $count_tpl = 0; 
              $count_docs = 0;
            ?>
            <!-- Ecriture de la ligne -->
            <tr>
              <td>{{ $tpl_type->type }}</td>
              <!-- Explode pour mise en forme de la date -->
              <?php $tpl_date = explode(" ",$tpl_type->created_at); ?>
              <td><?php  echo($tpl_date[0]) ?></td>

              @foreach($tpls as $tpl)
                @if($tpl_type->id == $tpl->type)
                  <?php 
                    $count_tpl++;
                    $count_docs = $count_docs + $tpl->nbapps;
                  ?>
                @endif
              @endforeach
              @if($count_tpl > 0)
                <!-- Modification/Suppression impossible-->
                <td><?php echo($count_docs) ?></td>
                <td><?php echo($count_tpl) ?></td>
                <!-- Pr�sence template et documents -->
                <td>
                  <button class="btn btn-default btn-xs" data-toggle="tooltip" data-placement="top" title="Modification impossible"><i class="fa fa-close"></i></button>
                  <button type="button" class="btn btn-default btn-xs" data-toggle="tooltip" data-placement="top" title="Suppression impossible"><i class="fa fa-close"></i></button>
                </td>
              @else
                <!-- Modification/Suppression possible -->
                <td><?php echo($count_docs) ?></td>
                <td><?php echo($count_tpl) ?></td>
                <td>
                  <a data-toggle="tooltip" data-placement="top" title="Modifier"><button type="button" class="btn btn-warning btn-xs" data-toggle="modal" data-target=".modalEditType_{{$tpl_type->id}}" ><i class="fa fa-pencil"></i></button></a>
                  <a data-toggle="tooltip" data-placement="top" title="Supprimer"><button type="button" class="btn btn-danger btn-xs" data-toggle="modal" data-target=".modalDelType_{{$tpl_type->id}}"><i class="fa fa-trash"></i></button></a>
                </td>
              @endif
            </tr>
            <!-- Modal de modification -->
            <div class="modal fade modalEditType_{{$tpl_type->id}}" tabindex="-1" role="dialog" aria-hidden="true">
              <div class="modal-dialog modal-sm">
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">�</span>
                    </button>
                    <h4 class="modal-title" id="myModalLabel">Modification de type</h4>
                  </div>
                  <div class="modal-body">
                    <label class="control-label" for="type_name">Nom du type :</label>
                    <input type="text" id="type_name" name="type_name" class="form-control" value="{{$tpl_type->type}}" required>
                  </div><br>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Annuler</button>
                    <button type="button" class="btn btn-warning" onclick="editType({{ $tpl_type->id }})"><span id="text_edit_{{ $tpl_type->id}}">Modifier</span><img id="loader_edit_{{ $tpl_type->id}}" src="{{ asset('images/7.gif') }}" style="height:15px;width:15px;display:none"></button>
                  </div>
                </div>
              </div>
            </div>
            <!-- Fin du modal de modification -->
            <!-- Modal de suppression -->
            <div class="modal fade modalDelType_{{$tpl_type->id}}" tabindex="-1" role="dialog" aria-hidden="true">
              <div class="modal-dialog modal-sm">
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">�</span>
                    </button>
                    <h4 class="modal-title" id="myModalLabel">Suppression de type</h4>
                  </div>
                  <div class="modal-body">
                    <p>Etes-vous s�r de vouloir supprimer ce type ?</p>
                  </div><br>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Annuler</button>
                    <button type="button" class="btn btn-danger" onclick="deleteType({{ $tpl_type->id }})"><span id="text_del_{{ $tpl_type->id}}">Supprimer</span><img id="loader_del_{{ $tpl_type->id}}" src="{{ asset('images/7.gif') }}" style="height:15px;width:15px;display:none"></button>
                  </div>
                </div>
              </div>
            </div>
            <!-- Fin du modal de suppression -->
          @endforeach
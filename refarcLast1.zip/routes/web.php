<?php

Route::group(['middleware' => 'laralum.base'], function () {

	/*
	|--------------------------------------------------------------------------
	| Add your website routes here
	|--------------------------------------------------------------------------
	|
	| The laralum.base middleware will be applied
	|
	*/
	# Welcome route
	Route::get('/', function () {
	    return view('auth/register');
	});

    Auth::routes();
});

Route::group(['middleware' => ['auth', 'laralum.base']], function () {

	/*
	|--------------------------------------------------------------------------
	| Add your website routes here (users are forced to login to access those)
	|--------------------------------------------------------------------------
	|
	| The laralum.base and auth middlewares will be applied
	|
	*/

	# Default home route
	//Route::match('/admin', 'HomeController@index');
});

Route::group(['middleware' => ['auth', 'laralum.base'], 'as' => 'Laralum::'], function () {

	Route::get('activate/{token?}', 'Auth\ActivationController@activate')->name('activate_account');
    Route::post('activate', 'Auth\ActivationController@activateWithForm')->name('activate_form');
    Route::get('/banned', function() {
        return view('auth/banned');
    })->name('banned');

});

Route::group(['middleware' => ['laralum.base'], 'namespace' => 'Laralum', 'as' => 'Laralum::'], function () {

	# Public document downloads
	Route::get('/document/{slug}', 'DownloadsController@downloader')->name('document_downloader');
	Route::post('/document/{slug}', 'DownloadsController@download');

	# Social auth
	Route::get('/social/{provider}', 'SocialController@redirectToProvider')->name('social');
	Route::get('/social/{provider}/callback', 'SocialController@handleProviderCallback')->name('social_callback');

	# Public language changer
	Route::get('/locale/{locale}', 'LocaleController@set')->name('locale');

});

Route::group(['middleware' => ['laralum.base'], 'prefix' => 'admin', 'namespace' => 'Laralum', 'as' => 'Laralum::'], function () {

	# Public document downloads
	Route::get('/install', 'InstallerController@locale')->name('install_locale');
	Route::get('/install/{locale}', 'InstallerController@show')->name('install');
	Route::post('/install/{locale}', 'InstallerController@installConfig');
	Route::get('/install/{locale}/confirm', 'InstallerController@install')->name('install_confirm');

});

Route::group(['middleware' => ['auth', 'laralum.base', 'laralum.auth'], 'prefix' => 'admin', 'namespace' => 'Laralum', 'as' => 'Laralum::'], function () {

	# Home Controller
    Route::get('/', 'DashboardController@index')->name('dashboard');

    # Users Routes
    Route::get('/users', 'UsersController@index')->name('users');

    Route::get('/users/create', 'UsersController@create')->name('users_create');
    Route::post('/users/create', 'UsersController@store');

    Route::get('/users/settings', 'UsersController@editSettings')->name('users_settings');
    Route::post('/users/settings', 'UsersController@updateSettings');

    Route::get('/users/{id}', 'UsersController@show')->name('users_profile');

	Route::get('/users/{id}/edit', 'UsersController@edit')->name('users_edit');
    Route::post('/users/{id}/edit', 'UsersController@update');

    Route::get('/users/{id}/roles', 'UsersController@editRoles')->name('users_roles');
    Route::post('/users/{id}/roles', 'UsersController@setRoles');

    Route::get('/users/{id}/delete', 'UsersController@destroy')->name('users_delete');
    Route::post('/users/{id}/delete', 'UsersController@destroy');

    # Projects Routes
    Route::get('/projects', 'ProjectsController@index')->name('projects');

    Route::get('/projects/create', 'ProjectsController@create')->name('projects_create');
    Route::post('/projects/create', 'ProjectsController@store');
    
    Route::get('/projects/{id}', 'ProjectsController@posts')->name('projects_posts');

	Route::get('/projects/{id}/edit', 'ProjectsController@edit')->name('projects_edit');
	Route::get('/projects/{id}/update', 'ProjectsController@update');

	Route::get('/projects/{id}/delete', 'SecurityController@confirm')->name('projects_delete');
	Route::post('/projects/{id}/delete', 'ProjectsController@destroy');

	Route::get('/projects/{id}/suivi', 'ProjectsController@suivi')->name('projects_suivi');
	Route::get('/projects/archives/{id}/{state}','ProjectsController@archived')->name('projects_archived');

	Route::get('/projects/list/all','ProjectsController@projects_all')->name('projects_all');
	Route::get('/projects/mylist/all','ProjectsController@my_all_projects')->name('my_projects_all');

	# Applications Routes
	Route::get('/projects/{id}/applications/{idApp}', 'ApplicationsController@index')->name('applications');
	Route::post('/projects/{id}/applications/up/updates', 'ApplicationsController@update');
	Route::get('/projects/{id}/applications/create/create', 'ApplicationsController@create')->name('create_app');
	Route::post('/projects/{id}/applications/create/create', 'ApplicationsController@create');
	Route::get('/projects/{id}/applications/{idApp}/apps', 'ApplicationsController@apps')->name('apps');
	Route::post('/projects/{id}/applications/activeEdit', 'ApplicationsController@activeEdit');
	Route::post('/projects/{id}/applications/createParagrapApp', 'ApplicationsController@createParagrapApp');
	Route::post('/projects/{id}/applications/versionup', 'ApplicationsController@versionup');

	Route::post('/projects/{id}/applications/{idApp}/addJalon','ApplicationsPlanningController@add_jalon');
	Route::post('/projects/{id}/applications/{idApp}/delJalon/{idJalon}','ApplicationsPlanningController@del_jalon');
	
	# Template
	Route::get('/templates', 'TemplatesParamsController@index')->name('templates');
	Route::get('/templates/{id}/suivi', 'TemplatesController@suivi')->name('templates_suivi');
	Route::get('/templates/{id}/tpls', 'TemplatesController@tpls')->name('tpls');
	Route::post('/create', 'TemplatesParamsController@create');
	Route::post('/templates/{id}/update', 'TemplatesController@update');
	Route::post('/templates/{id}/createParagraph', 'TemplatesController@createParagraph');
	Route::post('/templates/{id}/createNewParagraph', 'TemplatesController@createNewParagraph');
	Route::post('/templates/{id}/deleteParagraph', 'TemplatesController@deleteParagraph');
	Route::post('/templates/{id}/upload', 'TemplatesController@upload');

	Route::get('/templates/fusion', 'TemplatesParamsController@fusion')->name('fusion');
    Route::post('/templates/getdataFusion', 'TemplatesParamsController@getdataFusion');
	Route::post('/templates/createTplFusion', 'TemplatesParamsController@createTplFusion');
	Route::post('/templates/delTpls', 'TemplatesParamsController@delTpls');
    Route::post('/templates/validTpl', 'TemplatesParamsController@validTpl');
	
	# Templates generics users
	Route::get('/templates/generic_users', 'TemplatesController@generic_users')->name('templates_users');

	# Templates types
	Route::get('/templates/types','TemplatesParamsController@types')->name('templates_types');
	Route::post('/templates/edit','TemplatesParamsController@edit_type');
	Route::post('/templates/delete','TemplatesParamsController@delete_type');
	Route::post('/templates/add', 'TemplatesParamsController@add_type')->name('addtype');

    # Roles Routes
    Route::get('/roles', 'RolesController@index')->name('roles');

    Route::get('/roles/create', 'RolesController@create')->name('roles_create');
    Route::post('/roles/create', 'RolesController@store');

    Route::get('/roles/{id}', 'RolesController@show')->name('roles_show');

    Route::get('/roles/{id}/edit', 'RolesController@edit')->name('roles_edit');
    Route::get('/roles/{id}/update', 'RolesController@update')->name('roles_update');

    Route::get('/roles/{id}/permissions', 'RolesController@editPermissions')->name('roles_permissions');
    Route::post('/roles/{id}/permissions', 'RolesController@setPermissions');

    //Route::get('/roles/{id}/delete', 'SecurityController@confirm')->name('roles_delete');
    Route::get('/roles/{id}/delete', 'RolesController@destroy')->name('roles_delete');


    # Permissions Routes
    Route::get('/permissions', 'PermissionsController@index')->name('permissions');

    Route::get('/permissions/create', 'PermissionsController@create')->name('permissions_create');
    Route::post('/permissions/create', 'PermissionsController@store');

    Route::get('/permissions/{id}/edit', 'PermissionsController@edit')->name('permissions_edit');
    Route::post('/permissions/{id}/edit', 'PermissionsController@update');

    Route::get('/permissions/{id}/delete', 'SecurityController@confirm')->name('permissions_delete');
    Route::post('/permissions/{id}/delete', 'PermissionsController@destroy');

	# Blogs Routes
	Route::get('/blogs', 'BlogsController@index')->name('blogs');

	Route::get('/blogs/create', 'BlogsController@create')->name('blogs_create');
	Route::post('/blogs/create', 'BlogsController@store');

	Route::get('/blogs/{id}', 'BlogsController@posts')->name('blogs_posts');

	Route::get('/blogs/{id}/edit', 'BlogsController@edit')->name('blogs_edit');
	Route::post('/blogs/{id}/edit', 'BlogsController@update');

	Route::get('/blogs/{id}/roles', 'BlogsController@roles')->name('blogs_roles');
	Route::post('/blogs/{id}/roles', 'BlogsController@updateRoles');

	Route::get('/blogs/{id}/delete', 'SecurityController@confirm')->name('blogs_delete');
	Route::post('/blogs/{id}/delete', 'BlogsController@destroy');

	# Posts Routes
	Route::get('/posts/{id}', 'PostsController@index')->name('posts');

	Route::get('/posts/create/{id}', 'PostsController@create')->name('posts_create');
	Route::post('/posts/create/{id}', 'PostsController@store');

	Route::get('/posts/{id}/edit', 'PostsController@edit')->name('posts_edit');
	Route::post('/posts/{id}/edit', 'PostsController@update');

	Route::get('/posts/{id}/graphics', 'PostsController@graphics')->name('posts_graphics');

	Route::get('/posts/{id}/delete', 'SecurityController@confirm')->name('posts_delete');
	Route::post('/posts/{id}/delete', 'PostsController@destroy');

	# Comments Routes
	Route::post('/comments/create/{id}', 'CommentsController@create')->name('comments_create');

	Route::get('/comments/{id}/edit', 'CommentsController@edit')->name('comments_edit');
	Route::post('/comments/{id}/edit', 'CommentsController@update');

	Route::get('/comments/{id}/delete', 'SecurityController@confirm')->name('comments_delete');
	Route::post('/comments/{id}/delete', 'CommentsController@destroy');


	# Database CRUD
	Route::get('/CRUD', 'CRUDController@index')->name('CRUD');

	Route::get('/CRUD/{table}', 'CRUDController@table')->name('CRUD_table');

	Route::get('/CRUD/{table}/create', 'CRUDController@create')->name('CRUD_create');
	Route::post('/CRUD/{table}/create', 'CRUDController@createRow');

	Route::get('/CRUD/{table}/{id}', 'CRUDController@row')->name('CRUD_edit');
	Route::post('/CRUD/{table}/{id}', 'CRUDController@saveRow');

	Route::get('/CRUD/{table}/{id}/delete', 'SecurityController@confirm')->name('CRUD_delete');
	Route::post('/CRUD/{table}/{id}/delete', 'CRUDController@deleteRow');

	# API
	Route::get('/API', 'APIController@index')->name('API');

	# File Manager
	Route::get('/files', 'FilesController@files')->name('files');

	Route::get('/files/upload', 'FilesController@showUpload')->name('files_upload');
	Route::post('/files/upload', 'FilesController@upload');

	Route::get('/documents/{file}/create', 'DocumentsController@showCreate')->name('documents_create');
	Route::post('/documents/{file}/create', 'DocumentsController@createDocument');

	Route::get('/documents/{slug}/edit', 'DocumentsController@edit')->name('documents_edit');
	Route::post('/documents/{slug}/edit', 'DocumentsController@update');

	Route::get('/documents/{slug}/delete', 'SecurityController@confirm')->name('documents_delete');
	Route::post('/documents/{slug}/delete', 'DocumentsController@delete');

	Route::get('/files/{file}/delete', 'SecurityController@confirm')->name('files_delete');
	Route::post('/files/{file}/delete', 'FilesController@delete');

	Route::get('/files/{file}/download', 'FilesController@fileDownload')->name('files_download');

	# Settings
	Route::get('/settings', 'SettingsController@edit')->name('settings');
	Route::post('/settings', 'SettingsController@update');

	# Profile
    Route::get('/profile', 'ProfileController@edit')->name('profile');
	Route::post('/profile', 'ProfileController@update');

	# About
    Route::get('/about', 'AboutController@index')->name('about');

    # PDF
    Route::get('/{id}/pdf','PdfController@index')->name('pdf');
    Route::get('/{id}/pdf/templates','PdfController@pdf_template')->name('pdf_templates');
	 Route::get('/{id_app}/pdf/{version}', 'PdfController@pdf_Version_Hist')->name('pdf_Version_Hist');

    # Intervenants
    Route::post('/intervenants/add','IntervenantsController@add_interv');
    Route::get('/intervenants/list','IntervenantsController@list_name');
    Route::get('/intervenants/list/entite','IntervenantsController@list_entite');
    Route::get('/intervenants/list/resp_domain','IntervenantsController@list_resp_domain');
    Route::post('/intervenants/del/{id}','IntervenantsController@del_interv');

    # Diffusion
    Route::post('/diffusion/add','DiffusionController@add_diff');
    Route::get('/diffusion/list','DiffusionController@list_name_diff');
    Route::get('/diffusion/list/entite','DiffusionController@list_entite');
    Route::post('/diffusion/del/{id}','DiffusionController@del_diff');

    # Intervenants Templates
    Route::post('/templates/intervenants/add','TemplatesController@add_interv_tpls');
    Route::get('/templates/intervenants/list','TemplatesController@list_name_interv');
    Route::get('/templates/intervenants/list/entite','TemplatesController@list_entite_interv');
    Route::get('/templates/intervenants/list/resp_domain','TemplatesController@list_resp_domain_interv');
    Route::post('/templates/intervenants/del/{id}','TemplatesController@del_interv_tpls');

    # Diffusion Templates
    Route::post('/templates/diffusion/add','TemplatesController@add_diff_tpls');
    Route::get('/templates/diffusion/list','TemplatesController@list_name_diff');
    Route::get('/templates/diffusion/list/entite','TemplatesController@list_entite_diff');
    Route::post('/templates/diffusion/del/{id}','TemplatesController@del_diff_tpls');

    # Retour experience

    Route::get('/experiences','ExperienceController@index')->name('experiences');
    Route::post('/experiences','ExperienceController@add_report');
    Route::get('/experiences/admin','ExperienceController@admin')->name('experiences_admin');
    Route::post('/experiences/admin','ExperienceController@edit');
    Route::post('/experiences/delete','ExperienceController@delete');
    Route::post('/experiences/edit','ExperienceController@edit_report');

});

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Request;
use Location;
use Laralum;

class TemplatesParams extends Model
{
    protected $table = 'templates_params';  

   public function addtpl($request)
    {

        $tpl = new TemplatesParams();
        $tpl->version = $request->version;
        $tpl->comment = $request->comment;
        $tpl->user_id = $request->user_id;
        $tpl->type    = $request->type;
       
        $tpl->save();
        return true;
    }
}
<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Http\Requests;
use App\Templates;
use App\TemplatesParams;
use App\Applications;

class ApplicationsContent extends Model
{
    protected $table = 'applications_content';

          
    public function addAppContent($req)
    {
        $tplParams = TemplatesParams::where('id', '=', $req->id_template)->first();
        $nb = ++$tplParams->nbapps;
        $tplParams->nbapps = $nb;
        $tplParams->save();
        
        $templates = new Templates();
        $data = Templates::where('id_template', '=', $req->id_template)->get()->each(
            function ($item) use ($req) {
            $application = new ApplicationsContent();                   
                $application->text = $item->text;
                $application->niv = $item->niv;
                $application->parent = $item->parent;
                $application->text_stat = $item->text_stat;
                $application->ordre = $item->ordre;
                $application->num_parag = $item->num_parag;
                $application->id_template = $item->id_template;
                $application->user_id = $item->user_id;
                $application->id_app = $req->id_app;
                if ($item->num_parag == $req->numPrg) {
                    $application->text_stat = $req->text_stat;
                    $application->modified = 1;
                }
                $application->save();
        });
        // Update parent first Niv
        $dataUpdateFirstNiv = ApplicationsContent::where('id_template', '=', $req->id_template)
        ->where('niv', '=', 1)->get()->each(
            function ($item) use ($req) {
            $expOne = explode('.', $item->num_parag);
            $parent = ApplicationsContent::where('id_template', '=', $item->id_template)
                    ->where('num_parag', '=', $expOne[0])->where('niv', '=', 0)->first();
                    $applicationNivOne = ApplicationsContent::where('id','=',$item->id)->first();
                    $applicationNivOne->text = $item->text;
                    $applicationNivOne->niv = $item->niv;
                    $applicationNivOne->text_stat = $item->text_stat;
                    $applicationNivOne->ordre = $item->ordre;
                    $applicationNivOne->num_parag = $item->num_parag;
                    $applicationNivOne->id_template = $item->id_template;
                    $applicationNivOne->user_id = $item->user_id;
                    $applicationNivOne->id_app = $item->id_app;
                    $applicationNivOne->parent =  $parent['id'];
                    $applicationNivOne->save();               
        });
        // Update parent Second Niv
        $dataUpdateSecondNiv = ApplicationsContent::where('id_template', '=', $req->id_template)
        ->where('niv', '=', 2)->get()->each(
            function ($item) use ($req) {
            $expTwo = explode('.', $item->num_parag);
            $numprg = $expTwo[0].'.'.$expTwo[1];
            $fniv = ApplicationsContent::where('id_template', '=', $item->id_template)
                    ->where('num_parag', '=', $numprg)->where('niv', '=', 1)->first();
                    $applicationNivTwo = ApplicationsContent::where('id','=',$item->id)->first();
                    $applicationNivTwo->text = $item->text;
                    $applicationNivTwo->niv = $item->niv;
                    $applicationNivTwo->text_stat = $item->text_stat;
                    $applicationNivTwo->ordre = $item->ordre;
                    $applicationNivTwo->num_parag = $item->num_parag;
                    $applicationNivTwo->id_template = $item->id_template;
                    $applicationNivTwo->user_id = $item->user_id;
                    $applicationNivTwo->id_app = $item->id_app;
                    $applicationNivTwo->parent =  $fniv['id'];
                    $applicationNivTwo->save();               
        });
        return 'ajoutApp';
    }

    public function editAppContent($req, $id)
    {
        $application = ApplicationsContent::where('id','=',$id)->first();
        
        $application->text_stat = $req->text_stat;
        $application->modified = 1;
        $application->save();

        $appsParams = new Applications();
        $version = Applications::where('id', '=', $req->id_app)->first();
    
        if (empty($version['version'])) {
            $newVersion = 1;
        } else {
            $exp = explode('.', $version['version']);
            if (!empty($exp[1]) && $exp[1] != 9) {
                $newVersion = $exp[0].'.'.++$exp[1];
            } elseif (!empty($exp[1]) && $exp[1] == 9) {
                $newVersion = ++$exp[0];
            } else {
                $newVersion = $version['version'].'.1';
            } 
        }

        $version->version = $newVersion;
        $version->save();
        
        return $newVersion;
    }

    
}

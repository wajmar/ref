<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Request;
use Location;
use Laralum;

class Pictures extends Model
{
    protected $table = 'pictures';

    
}
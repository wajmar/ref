<?php 

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Http\Requests;

class Intervenants extends Model{

	protected $table = "intervenants";

	public function add_interv($req){

		$intervenant = new Intervenants();
		$intervenant->nom = $req['name'];
		$intervenant->email = $req['email'];
		$intervenant->entite = $req['entite'];
		$intervenant->resp_domain = $req['resp_domain'];
		$intervenant->id_user = $req['user_id'];
		$intervenant->id_app = $req->id_app;
		$intervenant->save();
		return true;

	}

	public function del_interv(){

	}

}

?>
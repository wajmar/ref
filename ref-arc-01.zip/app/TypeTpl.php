<?php
namespace App;
use Illuminate\Database\Eloquent\Model;
use Request;
use Location;
use Laralum;
class TypeTpl extends Model
{
    protected $table = 'typetpl';  
}
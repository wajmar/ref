<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Request;
use Location;
use Laralum;

class Templates extends Model
{
    protected $table = 'templates';

    /**
     * Modifier les paragraphes
     * @param  int   $id  ID
     * @param  array $req Data
     * @return bool
     */
    public function editTpl($id, $req)
    {
    	$templates = Templates::where('id','=',$id)->first();

    	$templates->text_stat = $req['text_stat'];  
    	$templates->text = $req['text'];  

    	$templates->save();

    	return true;
    }

    /**
     * Returner l'ordre maximum
     * @param  int $id Identifiant
     * @return int 
     */
    private function getMaxOrdre($id)
    {
    	$maxOrder = Templates::where('id_template', '=', $id)->max('ordre');
        return ++$maxOrder;
    }

    /**
     * Ajouter sous paragraphe
     * @param int   $newNumPrg NewNumPrg
     * @param array $request
     */
    public function addPrg($newNumPrg, $request)
    {
    	$templates = new Templates();

    	$templates->text_stat = $request['text_stat'];  
    	$templates->text = $request['text']; 
    	$templates->id_template = $request['id_template'];
    	$templates->niv = $request['niv'];
    	$templates->num_parag = $newNumPrg;
    	$templates->parent = $request['id'];
    	$templates->ordre = self::getMaxOrdre($request['id_template']);
    	$templates->user_id = $request['user_id'];
    	$templates->type = 1;   

    	$templates->save();

    	return true;
    }

    /**
     * Ajouter paragraphe
     * @param int   $newNumPrg NewNumPrg
     * @param int   $id        Identifiant
     * @param array $request
     */
    public function addNewPrg($newPrgNum, $id, $request)
    {
        $templates = new Templates();

        $templates->text_stat = $request['text_stat'];  
        $templates->text = $request['text']; 
        $templates->id_template = $id;
        $templates->niv = 0;
        $templates->num_parag = $newPrgNum;
        $templates->parent = 0;
        $templates->ordre = self::getMaxOrdre($id);
        $templates->user_id = $request['user_id'];
        $templates->type = 1;   

        $templates->save();

        return true;
    }

    /**
     * Supprimer une paragraphe
     * @param  int $idTpl  Id template
     * @param  int $id     Identifiant
     * @param  int $niv    Niveau
     * @param  int $numPrg Num de paragraphe
     * @return bool
     */
    public function deletePrg($idTpl, $id, $niv, $numPrg, $parentId)
    {
        $templates = new Templates();        
        
        if ($niv == 0) {
            $lastPrgs = Templates::where('niv', '=', $niv)->where('id_template', '=', $idTpl)->get();
            $maxPrg = count($lastPrgs);
            try {
                $del = Templates::where('id', $id)->first();
                self::delNivOne($idTpl, $id);
                if($del) {
                    $del->delete();
                }
            } catch (Exception $e) {
                throw $e;
            }
            if (count($lastPrgs) == $numPrg) {
                return;
            }
            for ($i=$numPrg+1; $i <= $maxPrg; $i++) { 
                $data = Templates::where('niv', '=', $niv)->where('id_template', '=', $idTpl)                
                ->where('num_parag', '=', $i)->get();
                foreach ($data as $value) {
                    try {
                        $dataNivOne = Templates::where('niv', '=', 1)->where('id_template', '=', $idTpl)
                        ->where('parent', '=', $value->id)->get()->each(
                        function ($item) {                    
                            if($item->num_parag) {
                                $exp = explode('.', $item->num_parag);
                                $newNbPrg = --$exp[0].'.'.$exp[1];
                                $item->num_parag = $newNbPrg;
                                $item->save();
                            }
                            $dataNivTwo = Templates::where('niv', '=', 2)
                            ->where('parent', '=', $item->id)->get()->each(
                            function ($el) {                    
                                if($el->num_parag) {
                                    $expNivTwo = explode('.', $el->num_parag);
                                    $newNbPrgNivTwo = --$expNivTwo[0].'.'.$expNivTwo[1].'.'.$expNivTwo[2];
                                    $el->num_parag = $newNbPrgNivTwo;
                                    $el->save();
                                }
                            });
                        });
                    } catch (Exception $e) {
                        throw $e;
                    }
                    $value->num_parag = --$value->num_parag;
                    $value->save();
                }
            }            
        } elseif ($niv == 1) {
            $lastPrgs = Templates::where('niv', '=', $niv)->where('id_template', '=', $idTpl)
            ->where('parent', '=', $parentId)->get();
            $maxPrg = count($lastPrgs);
            try {
                $del = Templates::where('id', $id)->first();
                self::delNivTwo($id);
                if($del) {
                    $del->delete();
                }
            } catch (Exception $e) {
                throw $e;
            }
            $expNPrg = explode('.', $numPrg);
            if (count($lastPrgs) == $expNPrg[0]) {
                return;
            }
            for ($i=$expNPrg[1]+1; $i <= $maxPrg; $i++) {
                $data = Templates::where('niv', '=', $niv)->where('id_template', '=', $idTpl)
                ->where('num_parag', '=', $expNPrg[0].'.'.$i)->get();
                foreach ($data as $value) {
                    try {
                        $dataNivTwo = Templates::where('niv', '=', 2)
                            ->where('parent', '=', $value->id)->get()->each(
                            function ($el) {                    
                                if($el->num_parag) {
                                    $expNivTwo = explode('.', $el->num_parag);
                                    $newNbPrgNivTwo = $expNivTwo[0].'.'.--$expNivTwo[1].'.'.$expNivTwo[2];
                                    $el->num_parag = $newNbPrgNivTwo;
                                    $el->save();
                                }
                            });
                    } catch (Exception $e) {
                        throw $e;
                    }
                    $exp = explode('.', $value->num_parag);
                    $newNbPrg = $exp[0].'.'.--$exp[1];

                    $value->num_parag = $newNbPrg;
                    $value->save();
                }
            }
        } elseif ($niv == 2) {
           $lastPrgs = Templates::where('niv', '=', $niv)->where('id_template', '=', $idTpl)
            ->where('parent', '=', $parentId)->get();
            $maxPrg = count($lastPrgs);
            
            try {
                $del = Templates::where('id', $id)->first();
                if($del) {
                    $del->delete();
                }
            } catch (Exception $e) {
                throw $e;
            }
            $expNPrg = explode('.', $numPrg);
            
            if (count($lastPrgs) == $expNPrg[2]) {
                return;
            }
            for ($i=$expNPrg[2]+1; $i <= $maxPrg; $i++) {
                $data = Templates::where('niv', '=', $niv)->where('id_template', '=', $idTpl)
                ->where('parent', '=', $parentId)
                ->where('num_parag', '=', $expNPrg[0].'.'.$expNPrg[1].'.'.$i)->get();
                foreach ($data as $value) {
                    $exp = explode('.', $value->num_parag);
                    $newNbPrg = $exp[0].'.'.$exp[1].'.'.--$exp[2];
                    $value->num_parag = $newNbPrg;
                    try {
                        $value->save();
                    } catch (Exception $e) {
                        throw $e;
                    }
                }
            }
        }
     return true;
    }

    /**
     * Supprimer les paragraphe du premier niveau ex:1.1
     * @param  int $idTpl    ID template
     * @param  int $idParent ID parent
     * @return bool
     */
    private function delNivOne($idTpl, $idParent)
    {
        if ($idTpl && $idParent) {
            try {
                $dataNivOne = Templates::where('niv', '=', 1)->where('id_template', '=', $idTpl)
                ->where('parent', '=', $idParent)->get()->each(function ($item) {                    
                    self::delNivTwo($item->id);               
                    $item->delete();
                });
            } catch (Exception $e) {
                throw $e;
            }
        }
    }

    /**
     * Supprimer les paragraphe du deuxiemme niveau ex:1.1.1
     * @param  int $idTpl    ID template
     * @param  int $idParent ID parent
     * @return bool
     */
    private function delNivTwo($idParent)
    {
        if ($idParent) {
            try {
                $dataNivTwo = Templates::where('niv', '=', 2)
                ->where('parent', '=', $idParent)->get()->each(
                    function ($item) {
                        $item->delete();
                    });
            } catch (Exception $e) {
                throw $e;
            }
        }
    }
}
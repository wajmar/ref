<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Http\Requests;

class Applications extends Model
{
    protected $table = 'applications';

    public function editApp($id, $req)
    {

    	$application = Applications::where('id','=',$id)->first();

    	$application->name = $req['name'];
    	$application->ecolience = $req['ecolience'];
    	$application->irt = $req['irt'];
    	$application->trigramme = $req['trigramme'];
    	$application->criticite_stamp = $req['criticite_stamp'];
    	$application->sensible_groupe = $req['sensible_groupe'];
    	$application->niv_sensible_fraude = $req['niv_sensible_fraude'];
    	$application->demande_client = $req['demande_client'];

    	$application->save();
    	return true;
    }

    public function addApp($req)
    {

        $application = new Applications();
        $application->name = $req['nameapp'];
        $application->ecolience = $req['ecolience'];
        $application->irt = $req['irt'];
        $application->trigramme = $req['trigramme'];
        $application->criticite_stamp = $req['criticite_stamp'];
        $application->sensible_groupe = $req['sensible_groupe'];
        $application->niv_sensible_fraude = $req['niv_sensible_fraude'];
        $application->demande_client = $req['demande_client'];
        $application->user_id = $req['user_id'];
        $application->project_id = $req['idproject'];

        $application->save();
        return true;
    }
   
}

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Request;
use Location;
use Laralum;

class Projects extends Model
{
    protected $table = 'projects';  

    public function saveProfilProject($id, $req){

    	$projects = Projects::where('id','=',$id)->first();
    	$projects->name = $req['name'];
    	$projects->description = $req['description'];

    	$projects->save();
    	return true;
    }
}

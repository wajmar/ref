<?php

namespace App\Http\Controllers\Laralum;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Laralum;

class HistApplicationsController extends Controller
{

    public function index()
    {
        
    } 

}

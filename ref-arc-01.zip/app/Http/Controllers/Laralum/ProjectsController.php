<?php

namespace App\Http\Controllers\Laralum;

use Illuminate\Http\Request;
use App\Projects;
use App\User;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Laralum;
use Carbon\Carbon;

class ProjectsController extends Controller
{

    /**
     * [index description]
     * @return [type] [description]
     */
    public function index()
    {
        # Check projects permissions
        Laralum::permissionToAccess('refarc.projects.access');

        $projects = Laralum::projects()->where('archived',0);
        # Get all users
        //$users = Laralum::users();
        $id_user = Laralum::loggedInUser()->id;
        $myprojects = Laralum::projects()->where('user_id',$id_user)->where('archived',0);
        
        # Return the view
        return view('laralum/projects/index', ['projects' =>  $projects,'myprojects' => $myprojects]);
    } 

    /**
     * retourner data line du projet
     * @param  int   $id Identifiant
     * @return array DataProjects
     */
    public function suivi($id)
    {
        # Check projects permissions
        Laralum::permissionToAccess('refarc.projects.access');

        $projects = Laralum::project('id', $id);
        # Get all applications->project
        $applications = Laralum::applications('project_id', $id);
        # Get all users
        $users = Laralum::users();
        # Get all history
        $history = Laralum::projectHist('id_original', $id);
        # Return the view
        return view(
            'laralum/projects/suivi',
            [
            'projects' =>  $projects,
            'users' =>  $users,
            'applications' =>  $applications,
            'history' =>  $history
            ]
            );
    } 

    

    public function create()
    {
        Laralum::permissionToAccess('refarc.projects.access');

        # Check permissions
        Laralum::permissionToAccess('refarc.projects.create');


        # Get all the data
        $data_index = 'projects';
        require('Data/Create/Get.php');

        # Return the view
        return view('laralum/projects/create', [
            'fields'    =>  $fields,
            'confirmed' =>  $confirmed,
            'encrypted' =>  $encrypted,
            'hashed'    =>  $hashed,
            'masked'    =>  $masked,
            'table'     =>  $table,
            'code'      =>  $code,
            'wysiwyg'   =>  $wysiwyg,
            'relations' =>  $relations,
            ]);
    }

    public function store(Request $request)
    {
        Laralum::permissionToAccess('refarc.projects.access');

        # Check permissions
        Laralum::permissionToAccess('refarc.projects.create');

        # create the projet
        $row = Laralum::newProject();
        $row->user_id = Laralum::loggedInUser()->id;
        $row->name = $request->name;
        $row->description = $request->description;
        
        $row->save();

        # Return the admin to the posts page with a success message
        return redirect()->route('Laralum::projects')->with('success', trans('laralum.project_success'));
    }

    public function edit($id)
    {
        Laralum::permissionToAccess('refarc.projects.access');

        # Check permissions
        Laralum::permissionToAccess('refarc.projects.edit');

        # Find the project
        $rows = Laralum::project('id', $id);
        
        if (!empty($rows)) {
            # Return the view
            return view('laralum/projects/edit', ['rows' =>  $rows]);
        }

        # Check if admin access
        //Laralum::mustNotBeAdmin($row); très importatnt cas d'un admin
    }

    public function update($id, Request $request)
    {
        Laralum::permissionToAccess('refarc.projects.access');

        # Check permissions
        Laralum::permissionToAccess('refarc.projects.edit');

        $project = new Projects();
        $project->saveProfilProject($id,$request);

        $row = Laralum::projects('id', $id);

        return json_encode($row);          

    }


    public function destroy($id)
    {
        Laralum::permissionToAccess('refarc.posts.access');
        
        # Check permissions
        Laralum::permissionToAccess('refarc.posts.delete');

        # Find The Post
        $post = Laralum::post('id', $id);

        # Check blog permissions
        Laralum::mustHaveBlog($post->blog->id);

        $post->delete();

        return redirect()->route('Laralum::blogs_posts', ['id' => $post->blog->id])->with('success', trans('laralum.msg_post_deleted'));
    }

    public function archived($id,$state){
        if($state == 1){
            $project = Laralum::project('id',$id);
            $project->archived = 1;
            $project->save();
            $project = Laralum::project('id',$id);
        }
        else{
            $project = Laralum::project('id',$id);
            $project->archived = 0;
            $project->save();
            $project = Laralum::project('id',$id);
        }

        return $project;
    }

    public function projects_all(){
        $projects = Laralum::projects();
        for($x=0;$x<count($projects);$x++){
            $projects[$x]->user = User::find($projects[$x]->user_id)->name; 
        }
        return $projects;
    }

    public function my_all_projects(){
        $id_user = Laralum::loggedInUser()->id;
        $myprojects = Laralum::projects()->where('user_id',$id_user);
        return $myprojects;
    }

}

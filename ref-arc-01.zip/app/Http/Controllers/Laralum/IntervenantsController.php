<?php 

namespace App\Http\Controllers\Laralum;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Intervenants;
use Response;

class IntervenantsController extends Controller{

	public function add_interv(Request $req){

		$intervenant = new Intervenants();
		$req['user_id'] = Laralum::loggedInUser()->id;
		// Ajout de l'intervenant
		$intervenant->add_interv($req);

		return 'Save Success';
	}

	public function list_name(Request $req){

		$queries = Intervenants::distinct()->select('nom','resp_domain','email','entite')->where('nom', 'LIKE', '%'.$req['query'].'%')->get();
		if(count($queries) > 0){
			foreach ($queries as $query){
	    		$results[] = [ 'id' => $query->id, 'value' => $query->nom, 'email' => $query->email, 'resp_domain' => $query->resp_domain, 'entite' => $query->entite ];
			}
			$json = json_encode(array('suggestions'=> $results));
		}else{
			$results = [];
			$json = json_encode(array('suggestions'=>$results));
		}
		return $json;
		
	}

	public function list_entite(Request $req){
		$queries = Intervenants::distinct()->select('entite')->where('entite', 'LIKE', '%'.$req['query'].'%')->get();
		if(count($queries) > 0){
			foreach ($queries as $query){
	    		$results[] = [ 'id' => $query->id, 'value' => $query->entite ];
			}
			$json = json_encode(array('suggestions'=> $results));
		}else{
			$results = [];
			$json = json_encode(array('suggestions'=>$results));
		}
		return $json;
	}

	public function list_resp_domain(Request $req){
		$queries = Intervenants::distinct()->select('resp_domain')->where('resp_domain', 'LIKE', '%'.$req['query'].'%')->get();
		if(count($queries) > 0){
			foreach ($queries as $query){
	    		$results[] = [ 'id' => $query->id, 'value' => $query->resp_domain ];
			}
			$json = json_encode(array('suggestions'=> $results));
		}else{
			$results = [];
			$json = json_encode(array('suggestions'=>$results));
		}
		return $json;
	}
}

?>
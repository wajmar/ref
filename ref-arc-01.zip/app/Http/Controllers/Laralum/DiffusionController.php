<?php 

namespace App\Http\Controllers\Laralum;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Diffusion;
use Response;

class DiffusionController extends Controller{

	public function add_diff(Request $req){

		$diffusion = new Diffusion();
		$req['user_id'] = Laralum::loggedInUser()->id;
		// Ajout de l'intervenant
		$diffusion->add_diff($req);

		return 'Save Success';
	}

	public function list_name_diff(Request $req){

		$queries = Diffusion::where('nom', 'LIKE', '%'.$req['query'].'%')->get();
		if(count($queries) > 0){
			foreach ($queries as $query){
	    		$results[] = [ 'id' => $query->id, 'value' => $query->nom, 'objet' => $query->objet, 'entite' => $query->entite ];
			}
			$json = json_encode(array('suggestions'=> $results));
		}else{
			$results = [];
			$json = json_encode(array('suggestions'=>$results));
		}
		return $json;
		
	}
	public function list_entite(Request $req){
		$queries = Diffusion::distinct()->select('entite')->where('entite', 'LIKE', '%'.$req['query'].'%')->get();
		if(count($queries) > 0){
			foreach ($queries as $query){
	    		$results[] = [ 'id' => $query->id, 'value' => $query->entite ];
			}
			$json = json_encode(array('suggestions'=> $results));
		}else{
			$results = [];
			$json = json_encode(array('suggestions'=>$results));
		}
		return $json;
	}
}

?>
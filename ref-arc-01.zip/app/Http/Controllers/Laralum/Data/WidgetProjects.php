<?php

// Operations here
require('WidgetsOperations.php');

// Widgets here

$widgets = [
    'latest_projects_graph' =>  Laralum::barChart($latest_projects_graph['title'], $latest_projects_graph['element_label'], $latest_projects_graph['labels'], $latest_projects_graph['data']),
    'projects_pie_graph'  =>   Laralum::pieChart($projects_pie_graph['title'], $projects_pie_graph['labels'], $projects_pie_graph['data'], '#16ab39'),
    
];

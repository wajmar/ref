<?php

$includes = [
    'header'    =>  "
        <script src=" . asset(Laralum::publicPath() . '/js/jquery/dist/jquery.min.js') . "></script>
        <link rel='stylesheet' type='text/css' href='" . asset(Laralum::publicPath() . '/css/custom.min.css') . "'>
        
        <link rel='stylesheet' type='text/css' href='" . asset(Laralum::publicPath() . '/css/font-awesome/css/font-awesome.min.css') . "'> 
        <link rel='stylesheet' type='text/css' href='" . asset(Laralum::publicPath() . '/css/bootstrap/dist/css/bootstrap.min.css') . "'>
        <link rel='stylesheet' type='text/css' href='" . asset(Laralum::publicPath() . '/css/animate.css/animate.min.css') . "'>
        <script src='" . asset(Laralum::publicPath() . '/css/bootstrap/dist/js/bootstrap.min.js') . "'></script>

        

    ",
    /*
    |--------------------------------------------------------------------------
    | Laralum Includes, please do not remove any lines as it may cause problems
    |--------------------------------------------------------------------------
    */
    'laralum_header'    =>  "
        <link rel='stylesheet' type='text/css' href='" . asset(Laralum::publicPath() . '/css/bootstrap/dist/css/bootstrap.min.css') . "'>
        <link rel='stylesheet' type='text/css' href='" . asset(Laralum::publicPath() . '/css/iCheck/skins/flat/green.css') . "'>
        <link rel='stylesheet' type='text/css' href='" . asset(Laralum::publicPath() . '/js/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css') . "'>
        <link rel='stylesheet' type='text/css' href='" . asset(Laralum::publicPath() . '/css/custom.min.css') . "'>
        
        <link rel='stylesheet' type='text/css' href='" . asset(Laralum::publicPath() . '/css/font-awesome/css/font-awesome.min.css') . "'>       
        <link rel='stylesheet' type='text/css' href='" . asset(Laralum::publicPath() . '/js/mjolnic-bootstrap-colorpicker/dist/css/bootstrap-colorpicker.min.css') . "'>

        <link rel='stylesheet' type='text/css' href='" . asset(Laralum::publicPath() . '/js/datatables.net-bs/css/dataTables.bootstrap.min.css') . "'>

        <link rel='stylesheet' type='text/css' href='" . asset(Laralum::publicPath() . '/js/datatables.net-buttons-bs/css/buttons.bootstrap.min.css') . "'>
        <link rel='stylesheet' type='text/css' href='" . asset(Laralum::publicPath() . '/js/datatables.net-fixedheader-bs/css/fixedHeader.bootstrap.min.css') . "'>
        <link rel='stylesheet' type='text/css' href='" . asset(Laralum::publicPath() . '/js/datatables.net-responsive-bs/css/responsive.bootstrap.min.css') . "'>
        <link rel='stylesheet' type='text/css' href='" . asset(Laralum::publicPath() . '/js/datatables.net-scroller-bs/css/scroller.bootstrap.min.css') . "'>
        <link rel='stylesheet' type='text/css' href='" . asset(Laralum::publicPath() . '/js/pnotify/dist/pnotify.css') . "'>
        <link rel='stylesheet' type='text/css' href='" . asset(Laralum::publicPath() . '/js/pnotify/dist/pnotify.buttons.css') . "'>
        <link rel='stylesheet' type='text/css' href='" . asset(Laralum::publicPath() . '/js/pnotify/dist/pnotify.nonblock.css') . "'>
        <link rel='stylesheet' type='text/css' href='" . asset(Laralum::publicPath() . '/js/bootstrap-daterangepicker/daterangepicker.css') . "'>
        <link rel='stylesheet' type='text/css' href='" . asset(Laralum::publicPath() . '/css/select2/dist/css/select2.min.css') . "'>
        <link rel='stylesheet' type='text/css' href='" . asset(Laralum::publicPath() . '/css/switchery/dist/switchery.min.css') . "'>
        <link rel='stylesheet' type='text/css' href='" . asset(Laralum::publicPath() . '/sweetalert/sweetalert.css') . "'>
        
        <link rel='stylesheet' type='text/css' href='" . asset(Laralum::publicPath() . '/css/jquery.steps.css') . "'>
        <link rel='stylesheet' type='text/css' href='" . asset(Laralum::publicPath() . '/css/normalize.css') . "'>
        
        <script src='" . asset(Laralum::publicPath() . '/js/jquery/dist/jquery.min.js') . "'></script>
        <script src='" . asset(Laralum::publicPath() . '/js/jquery.loadscript.js') . "'></script>
        <script src='" . asset(Laralum::publicPath() . '/js/tinymce/tinymce.js') . "'></script>
    ",

    'laralum_bottom'    =>  "  
        <script src='" . asset(Laralum::publicPath() . '/js/jquery.autocomplete.js') . "'></script>          
        <script src='" . asset(Laralum::publicPath() . '/css/switchery/dist/switchery.min.js') . "'></script>        
        <script src='" . asset(Laralum::publicPath() . '/css/select2/dist/js/select2.full.min.js') . "'></script>
        <script src='" . asset(Laralum::publicPath() . '/js/datatables.net/js/jquery.dataTables.min.js') . "'></script>
        <script src='" . asset(Laralum::publicPath() . '/css/bootstrap/dist/js/bootstrap.min.js') . "'></script>
        <script src='" . asset(Laralum::publicPath() . '/js/fastclick/lib/fastclick.js') . "'></script>
        <script src='" . asset(Laralum::publicPath() . '/js/nprogress/nprogress.js') . "'></script>
        <script src='" . asset(Laralum::publicPath() . '/js/moment.js') . "'></script>
        <script src='" . asset(Laralum::publicPath() . '/js/daterangepicker.js') . "'></script>
        <script src='" . asset(Laralum::publicPath() . '/js/Chart.js/dist/Chart.min.js') . "'></script>
        <script src='" . asset(Laralum::publicPath() . '/js/gauge.js/dist/gauge.min.js') . "'></script>
        <script src='" . asset(Laralum::publicPath() . '/js/bootstrap-progressbar/bootstrap-progressbar.min.js') . "'></script>
        <script src='" . asset(Laralum::publicPath() . '/js/iCheck/icheck.min.js') . "'></script>
        <script src='" . asset(Laralum::publicPath() . '/js/skycons/skycons.js') . "'></script>
        <script src='" . asset(Laralum::publicPath() . '/js/Flot/jquery.flot.js') . "'></script>
        <script src='" . asset(Laralum::publicPath() . '/js/Flot/jquery.flot.pie.js') . "'></script>
        <script src='" . asset(Laralum::publicPath() . '/js/Flot/jquery.flot.time.js') . "'></script>
        <script src='" . asset(Laralum::publicPath() . '/js/Flot/jquery.flot.stack.js') . "'></script>
        <script src='" . asset(Laralum::publicPath() . '/js/Flot/jquery.flot.resize.js') . "'></script>
        <script src='" . asset(Laralum::publicPath() . '/js/custom.min.js') . "'></script>
        <script src='" . asset(Laralum::publicPath() . '/js/mjolnic-bootstrap-colorpicker/dist/js/bootstrap-colorpicker.min.js') . "'></script>
        <script src='" . asset(Laralum::publicPath() . '/js/datatables.net/js/jquery.dataTables.min.js') . "'></script>
        <script src='" . asset(Laralum::publicPath() . '/js/datatables.net-bs/js/dataTables.bootstrap.min.js') . "'></script>
        <script src='" . asset(Laralum::publicPath() . '/js/datatables.net-buttons/js/dataTables.buttons.min.js') . "'></script>
        <script src='" . asset(Laralum::publicPath() . '/js/datatables.net-buttons-bs/js/buttons.bootstrap.min.js') . "'></script>
        <script src='" . asset(Laralum::publicPath() . '/js/datatables.net-buttons/js/buttons.flash.min.js') . "'></script>
        <script src='" . asset(Laralum::publicPath() . '/js/datatables.net-buttons/js/buttons.html5.min.js') . "'></script>

        <script src='" . asset(Laralum::publicPath() . '/js/datatables.net-buttons/js/buttons.print.min.js') . "'></script>
        <script src='" . asset(Laralum::publicPath() . '/js/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js') . "'></script>
        <script src='" . asset(Laralum::publicPath() . '/js/datatables.net-keytable/js/dataTables.keyTable.min.js') . "'></script>
        <script src='" . asset(Laralum::publicPath() . '/js/datatables.net-responsive/js/dataTables.responsive.min.js') . "'></script>
        <script src='" . asset(Laralum::publicPath() . '/js/datatables.net-responsive-bs/js/responsive.bootstrap.js') . "'></script>
        <script src='" . asset(Laralum::publicPath() . '/js/datatables.net-scroller/js/datatables.scroller.min.js') . "'></script>
        <script src='" . asset(Laralum::publicPath() . '/js/jszip/dist/jszip.min.js') . "'></script>
        <script src='" . asset(Laralum::publicPath() . '/js/pdfmake/build/pdfmake.min.js') . "'></script>
        <script src='" . asset(Laralum::publicPath() . '/js/pdfmake/build/vfs_fonts.js') . "'></script>
        <script src='" . asset(Laralum::publicPath() . '/js/pnotify/dist/pnotify.js') . "'></script>
        <script src='" . asset(Laralum::publicPath() . '/js/pnotify/dist/pnotify.buttons.js') . "'></script>
        <script src='" . asset(Laralum::publicPath() . '/js/pnotify/dist/pnotify.nonblock.js') . "'></script>
        <script src='" . asset(Laralum::publicPath() . '/js/validator/validator.js') . "'></script>
        <script src='" . asset(Laralum::publicPath() . '/sweetalert/sweetalert.min.js') . "'></script>
        <script src='" . asset(Laralum::publicPath() . '/js/jQuery-Smart-Wizard/js/jquery.smartWizard.js') . "'></script>
        <script src='" . asset(Laralum::publicPath() . '/js/jquery.steps.js') . "'></script>
        
        
        <script src='" . asset(Laralum::publicPath() . '/js/scriptApps.js') . "'></script>
        
    ",

    'charts'    =>  "
        
        
        <script src='" . asset(Laralum::publicPath() . '/highcharts/js/highcharts.js') . "'></script>
        <script src='" . asset(Laralum::publicPath() . '/highcharts/js/modules/exporting.js') . "'></script>
        
    ",
];

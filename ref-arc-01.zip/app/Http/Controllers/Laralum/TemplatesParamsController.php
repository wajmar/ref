<?php

namespace App\Http\Controllers\Laralum;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\TemplatesParams;
use App\TypeTpl;

class TemplatesParamsController extends Controller
{
    /**
     * [index description]
     * @return [type] [description]
     */
    public function index()
    {
        # Check projects permissions
        Laralum::permissionToAccess('refarc.templates.access');

        $templates = Laralum::templatesList();   
        $tplType = Laralum::getTypeTpl();    
        
        return view(
            'laralum/templates/index',
            [
                'templates' =>  $templates,
                'tpltype' => $tplType
            ]
        );
    }

    public function addtype(request $request)
    {
        # Check projects permissions
        Laralum::permissionToAccess('refarc.templates.access');
        Laralum::permissionToAccess('refarc.templates.edit');

        $templatesExist = TypeTpl::where('type', '=', $request->type)->first();
        if (!empty($templatesExist)) {
            return 'exist';
        }
        $type = new TypeTpl();
        $type->type = $request->type;
        $type->save();
  
        $templatesLast = TypeTpl::where('type', '=', $request->type)->first();
  
        return $templatesLast['id'].'/'.$templatesLast['type'];
    }  

    /**
     * [index description]
     * @return [type] [description]
     */
    public function create(Request $request)
    {
        # Check projects permissions
        Laralum::permissionToAccess('refarc.templates.access');

        # Check projects permissions
        Laralum::permissionToAccess('refarc.templates.create');

        $request['user_id'] = Laralum::loggedInUser()->id;
        $version = TemplatesParams::where('type', '=', $request->type)->max('version');          
        if (!empty($version)) {
            $request->version = ++$version;
        } else {
            $request->version = 1;
        }
        $app = new TemplatesParams();
        $app->addtpl($request);

        $row = Laralum::templatesList();

        return $request->version;
    }


    public function update($id, Request $request)
    {
        Laralum::permissionToAccess('refarc.applications.access');

        # Check permissions
        Laralum::permissionToAccess('refarc.applications.edit');

        $req = $request;
        $req_id = $request['id'];

        $app = new Applications();
        $app->editApp($req_id,$req);

        $row = Laralum::application('id', $req_id);

    	return $row;
        
    }    
}

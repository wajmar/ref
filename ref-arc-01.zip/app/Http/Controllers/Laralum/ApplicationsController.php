<?php

namespace App\Http\Controllers\Laralum;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Applications;
use App\ApplicationsContent;
use App\Templates;
use App\TemplatesParams;
use App\Intervenants;
use App\Diffusion;

class ApplicationsController extends Controller
{
    /**
     * [index description]
     * @return [type] [description]
     */
    public function index($id, $idApp)
    {
        # Check projects permissions
        Laralum::permissionToAccess('refarc.applications.access');

        $appsParams = Laralum::application('id', $idApp);
        //print_r($appsParams);die;

        $applications = Laralum::application('project_id', $id);
        $project = Laralum::project('id', $id);
        $name_project = $project->name;
        # Get all history
        $history = Laralum::applicationsHist('id_original', $idApp);
        $intervenants = Intervenants::where('id_app',$idApp)->get();
        $diffusion = Diffusion::where('id_app',$idApp)->get();
        # Return the view
        return view(
            'laralum/projects/applications/index',
                [
                    'applications' =>  $applications,
                    'history' =>  $history,
                    'nameProj' => $name_project,
                    'appsParams' => $appsParams,
                    'intervenants' => $intervenants,
                    'diffusion' => $diffusion
                ]
        );
    } 

   public function apps($id, $idApp)
      {$id = 1; ///////////////////////////////////////////////////////////
          # Check projects permissions
          Laralum::permissionToAccess('refarc.applications.access');
          
          $appsContent = Laralum::applicationscontentId('id_app', $idApp);
          $tpls = Laralum::TemplatesLast('id', 1);
          $tpl = laralum::templatesParamsLast('id', $id);
          $appsParams = laralum::application('id', $idApp);
  
          if (empty($appsContent)) {
              $parents = Laralum::templatesNiv(['niv' => 0, 'id_template' => $id]);      
              $first_nivs = Laralum::templatesNiv(['niv' => 1, 'id_template' => $id]);
              $second_nivs = Laralum::templatesNiv(['niv' => 2, 'id_template' => $id]);
          } else {
    
              $parents = Laralum::applicationsNiv(['niv' => 0, 'id_template' => $id]);
             $first_nivs = Laralum::applicationsNiv(['niv' => 1, 'id_template' => $id]);
              $second_nivs = Laralum::applicationsNiv(['niv' => 2, 'id_template' => $id]);   
          }
      
        return view(
            'laralum/projects/apps',
              [
                  'id' => $id,
                  'parents' =>  $parents,
                  'first_nivs' =>  $first_nivs,
                  'second_nivs' =>  $second_nivs,
                  'tpl' =>  $tpl,
                  'appsParams' => $appsParams           
              ]
          );
      }

    public function activeEdit($id, Request $request)
    {
        Laralum::permissionToAccess('refarc.applications.access');

        # Check permissions
        Laralum::permissionToAccess('refarc.applications.edit');

        if ($request->stat == 'editor') {
            $appsParams = new Applications();
            $data = Applications::where('id', $request->id)->first();
            if ($data->active_edit === NULL) {
                $appsParams->where('id', $request->id)
                ->update(['active_edit' => Laralum::loggedInUser()->id]);
                return 'edit';
            } elseif ($data->active_edit === Laralum::loggedInUser()->id) {
                $appsParams->where('id', $request->id)
                ->update(['active_edit' => NULL]);
                return 'stopedEdit';
            } else {
                return $data->active_edit;
            }
        }
        return $request->stat;
    }

    public function createParagrapApp(Request $request){
         Laralum::permissionToAccess('refarc.applications.access');
 
         # Check permissions
         Laralum::permissionToAccess('refarc.applications.edit');        
 
         $app = new ApplicationsContent();
 
         $request->user_id = Laralum::loggedInUser()->id;
 
         $data = ApplicationsContent::where('id_app', $request->id_app)->where('num_parag', $request->numPrg)->first();
 
         if (!empty($data->id)) {
             if (strcasecmp($data->text_stat, $request->text_stat) == 0) {
                 return 'noModif';
             } else {
                 $modif = $app->editAppContent($request, $data->id);
                 return $modif;
             } 
         }
         $addApp = $app->addAppContent($request);
 
         return $addApp;
    }

    public function update($id, Request $request)
    {
        Laralum::permissionToAccess('refarc.applications.access');

        # Check permissions
        Laralum::permissionToAccess('refarc.applications.edit');

        $req = $request;
        $req_id = $request['id'];

        $app = new Applications();
        $app->editApp($req_id,$req);

        $row = Laralum::application('id', $req_id);

    	return $row;
        
    }

    public function create($id, Request $request)
    {
        # Check permissions
        Laralum::permissionToAccess('refarc.applications.access');
        Laralum::permissionToAccess('refarc.applications.create');
        $app = new Applications();
        $request['user_id'] = Laralum::loggedInUser()->id;
        $app->addApp($request);

        $applications = Laralum::applications('project_id', $id);

        return $applications;
        
    }

    public function versionup(Request $request)
    {
        # Check permissions
        Laralum::permissionToAccess('refarc.applications.access');
        Laralum::permissionToAccess('refarc.applications.edit');      
        $appsParams = new Applications();
        $version = Applications::where('id', '=', $request->app)->first();
        $el = explode('.', $version['version']);
        $newversion = ++$el[0];
        $version->version = $newversion;
        $version->save();        
        return $newversion;         
    }
}

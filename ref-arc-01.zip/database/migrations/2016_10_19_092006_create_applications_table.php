<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateApplicationsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('applications', function (Blueprint $table) {
            $table->increments('id');
            $table->string('name');
            $table->string('ecolience');
            $table->string('irt')->unique();
            $table->string('trigramme');
            $table->enum('criticite_stamp', ['Non prioritaire', 'Secondaire', 'Critique', 'Vitale'])
            ->default('Non prioritaire');
            $table->boolean('sensible_groupe');
            $table->string('demande_client');
            $table->string('version');
            $table->enum('statu', ['Draft', 'Final'])->default('Draft');
            $table->boolean('niv_sensible_fraude');
            $table->integer('user_id');
            $table->integer('project_id');
            $table->integer('template_id');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('applications');
    }
}

<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePermissions extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('permissions', function (Blueprint $table) {
            $table->increments('id');
            $table->string('slug')->unique();
            $table->boolean('assignable');
            $table->boolean('su');
            $table->timestamps();
        });

        $permissions = [
            'refarc.access',
            'refarc.users.access',
            'refarc.users.create',
            'refarc.users.edit',
            'refarc.users.roles',
            'refarc.users.delete',
            'refarc.users.settings',
            'refarc.roles.access',
            'refarc.roles.create',
            'refarc.roles.edit',
            'refarc.roles.permissions',
            'refarc.roles.delete',
            'refarc.permissions.access',
            'refarc.permissions.create',
            'refarc.permissions.edit',
            'refarc.permissions.delete',
            'refarc.blogs.access',
            'refarc.blogs.create',
            'refarc.blogs.edit',
            'refarc.blogs.posts',
            'refarc.blogs.delete',
            'refarc.posts.access',
            'refarc.posts.create',
            'refarc.posts.edit',
            'refarc.posts.view',
            'refarc.posts.comments',
            'refarc.posts.graphics',
            'refarc.posts.delete',
            'refarc.files.access',
            'refarc.files.upload',
            'refarc.files.download',
            'refarc.files.delete',
            'refarc.documents.create',
            'refarc.documents.edit',
            'refarc.documents.delete',
            'refarc.settings.access',
            'refarc.settings.edit',
            'refarc.CRUD.access',
            //
            'refarc.projects.access',
            'refarc.projects.create',
            'refarc.projects.edit',
            'refarc.projects.delete',
            //
            'refarc.applications.access',
            'refarc.applications.create',
            'refarc.applications.edit',
            //
        ];

        foreach($permissions as $permission) {
            $perm = \Laralum::newPermission();
            $perm->slug = $permission;
            $perm->assignable = true;
            $perm->su = true;
            $perm->save();
        }


    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('permissions');
    }
}

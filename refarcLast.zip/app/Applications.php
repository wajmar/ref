<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Http\Requests;

class Applications extends Model
{
    protected $table = 'applications_params';

    public function editApp($id, $req)
    {

    	$application = Applications::where('id','=',$id)->first();

    	$application->name = $req['name'];
    	$application->ecolience = $req['ecolience'];
    	$application->irt = $req['irt'];
    	$application->trigramme = $req['trigramme'];
    	$application->criticite_stamp = $req['criticite_stamp'];
    	$application->sensible_groupe = $req['sensible_groupe'];
    	$application->niv_sensible_fraude = $req['niv_sensible_fraude'];
    	$application->demande_client = $req['demande_client'];
        $application->statu = $req['statu'];
    	$application->save();
    	return true;
    }

    public function addApp($req)
    {

        $application = new Applications();
        $application->name = $req['nameapp'];
        $application->ecolience = $req['ecolience'];
        $application->irt = $req['irt'];
        $application->trigramme = $req['trigramme'];
        $application->criticite_stamp = $req['criticite_stamp'];
        $application->sensible_groupe = $req['sensible_groupe'];
        $application->niv_sensible_fraude = $req['niv_sensible_fraude'];
        $application->demande_client = $req['demande_client'];
        $application->user_id = $req['user_id'];
        $application->project_id = $req['project_id'];
        $application->template_id = $req['type_doc'];        

        $application->save();
		
		// Incr�menter la version
        $version = new VersionApps();
        $version->id_app = $application->id;
        $version->version = 1;
        $version->save();

        // Incr�menter nb apps dans templates
        $tplParams = TemplatesParams::where('id', '=', $req['type_doc'])->first();
        $nb = ++$tplParams->nbapps;
        $tplParams->nbapps = $nb;
        $tplParams->save();

        // Incr�menter nb apps dans projets
        $projects = Projects::where('id', '=', $req['project_id'])->first();
        $nbPrj = ++$projects->nb_apps;
        $projects->nb_apps = $nbPrj;
        $projects->save();
		
        return true;
    }
   
}

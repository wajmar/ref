<?php 

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Http\Requests;

class TemplatesInterv extends Model{

	protected $table = "templates_interv";

	public function add_interv($request){

		$intervenant = new TemplatesInterv();
		$intervenant->nom = $request['name'];
		$intervenant->email = $request['email'];
		$intervenant->entite = $request['entite'];
		$intervenant->resp_domain = $request['resp_domain'];
		$intervenant->id_user = $request['user_id'];
		$intervenant->save();
		return $intervenant;
	}

	public function list_interv(){

	}

	public function list_entite_interv(){

	}

	public function list_name_interv(){

	}

	public function list_resp_domain_interv(){

	}

}

?>
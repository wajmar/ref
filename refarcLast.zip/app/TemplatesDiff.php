<?php 

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Http\Requests;

class TemplatesDiff extends Model{

	protected $table = "templates_diff";

	public function add_diff($req){

		$diffusion = new TemplatesDiff();
		$diffusion->nom = $req['name'];
		$diffusion->entite = $req['entite'];
		$diffusion->objet = $req['objet'];
		$diffusion->id_user = $req['user_id'];
		$diffusion->save();
		return $diffusion;
	}
}

?>
<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Http\Requests;

class VersionApps extends Model
{
    protected $table = 'version_apps';

}

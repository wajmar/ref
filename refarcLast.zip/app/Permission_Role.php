<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Permission_Role extends Model
{
    public $timestamps = false;
    protected $table = 'permission_role';
}

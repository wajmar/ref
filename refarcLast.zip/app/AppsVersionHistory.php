<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Http\Requests;

class AppsVersionHistory extends Model
{
    protected $table = 'applications_version_history';

}

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Users_Settings extends Model
{
	public $timestamps = false;
    protected $table = 'users_settings';
}

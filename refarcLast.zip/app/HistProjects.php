<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Request;
use Location;
use Laralum;

class HistProjects extends Model
{
    protected $table = 'histo_projects';

    
   
}

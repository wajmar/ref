<?php
namespace App;

use Illuminate\Database\Eloquent\Model;
use Request;
use Location;
use Laralum;

class TypeTpl extends Model
{
    protected $table = 'typetpl';

    public function add_type($request){

    	$type_tpl = new TypeTpl();
    	$type_tpl->type = $request->type_name;
    	$type_tpl->save();
    	return $type_tpl;
    }

    public function edit_type($request){

    	$type_tpl = TypeTpl::where('id',$request->id)->first();
    	$type_tpl->type = $request->type_name;
    	$type_tpl->save();

    	return $type_tpl->id;
    } 

    public function delete_type($request){
    	$type_tpl = TypeTpl::where('id',$request->id);
		$type_tpl->delete();    	
    } 
}
<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Http\Requests;

class ApplicationsPlanning extends Model
{
    protected $table = 'applications_planning';

}

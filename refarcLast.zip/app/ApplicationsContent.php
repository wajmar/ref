<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Http\Requests;
use App\Templates;
use App\TemplatesParams;
use App\Applications;
use App\AppsVersionHistory;
use App\VersionApps;

class ApplicationsContent extends Model
{
    protected $table = 'applications_content';


    public function addAppContent($req)
    {        
        $tabModified = [];
        $data = Templates::where('id_template', '=', $req->id_template)->get();
        foreach ($data as $key) {
            $application = new ApplicationsContent();
            $application->text = $key->text;
            $application->niv = $key->niv;
            $application->parent = $key->parent;
            $application->text_stat = $key->text_stat;
            $application->ordre = $key->ordre;
            $application->num_parag = $key->num_parag;
            $application->id_template = $key->id_template;
            $application->user_id = $key->user_id;
            $application->id_app = $req->id_app;
            $i = 1;
            foreach ($req->text as $textStat) {
                $exp = explode('|***|', $textStat);
                $txt = $exp[0];
                $idT = $exp[1];
                $npg = $exp[2];
                if ($idT == $key->id) {
                    if (strcmp($key->text_stat, $txt) === 0) {
                        $application->text_stat = $key->text_stat;
                        $application->modified = 0;
                    } else {
                        $application->text_stat = $txt;
                        $application->modified = 1;
                        $tabModified[] = $idT;
                    }
                }
                ++$i;
            }
            $application->save();
        }
        // Update parent first Niv
        $dataUpdateFirstNiv = ApplicationsContent::where('id_template', '=', $req->id_template)
            ->where('niv', '=', 1)->get()->each(
                function ($item) use ($req) {
                    $expOne = explode('.', $item->num_parag);
                    $parent = ApplicationsContent::where('id_template', '=', $item->id_template)
                        ->where('num_parag', '=', $expOne[0])->where('niv', '=', 0)->first();
                    $applicationNivOne = ApplicationsContent::where('id','=',$item->id)->first();
                    $applicationNivOne->text = $item->text;
                    $applicationNivOne->niv = $item->niv;
                    $applicationNivOne->text_stat = $item->text_stat;
                    $applicationNivOne->ordre = $item->ordre;
                    $applicationNivOne->num_parag = $item->num_parag;
                    $applicationNivOne->id_template = $item->id_template;
                    $applicationNivOne->user_id = $item->user_id;
                    $applicationNivOne->id_app = $item->id_app;
                    $applicationNivOne->parent =  $parent['id'];
                    $applicationNivOne->save();
                });
        // Update parent Second Niv
        $dataUpdateSecondNiv = ApplicationsContent::where('id_template', '=', $req->id_template)
            ->where('niv', '=', 2)->get()->each(
                function ($item) use ($req) {
                    $expTwo = explode('.', $item->num_parag);
                    $numprg = $expTwo[0].'.'.$expTwo[1];
                    $fniv = ApplicationsContent::where('id_template', '=', $item->id_template)
                        ->where('num_parag', '=', $numprg)->where('niv', '=', 1)->first();
                    $applicationNivTwo = ApplicationsContent::where('id','=',$item->id)->first();
                    $applicationNivTwo->text = $item->text;
                    $applicationNivTwo->niv = $item->niv;
                    $applicationNivTwo->text_stat = $item->text_stat;
                    $applicationNivTwo->ordre = $item->ordre;
                    $applicationNivTwo->num_parag = $item->num_parag;
                    $applicationNivTwo->id_template = $item->id_template;
                    $applicationNivTwo->user_id = $item->user_id;
                    $applicationNivTwo->id_app = $item->id_app;
                    $applicationNivTwo->parent =  $fniv['id'];
                    $applicationNivTwo->save();
                });
        $dataCheked = ApplicationsContent::select('id', 'modified')->where('id_app', $req->id_app)->get();
        return $dataCheked;
    }

    public function updateAppContent($request)
    {
        $data = ApplicationsContent::where('id_app', $request->id_app)->get();
        $tabModified = [];
        foreach ($request->text as $textStat) {
            $exp = explode('|***|', $textStat);
            $txt = $exp[0];
            $idT = $exp[1];
            $npg = $exp[2];
            foreach ($data as $value) {
                if ($idT == $value->id) {
                    if (strcmp($value->text_stat, $txt) !== 0) {
                        $application = ApplicationsContent::where('id', '=', $idT)->first();
                        $application->text_stat = $txt;
                        $application->modified = 1;
                        $tabModified[] = $idT;
                        $application->save();
                    } else {
                        continue;
                    }
                }
            }
        }
        // Enregistrement version mineure / majeure
        if ($request->type == 1 || $request->type == 2) {
            $version = VersionApps::where('id_app', '=', $request->id_app)->max('version');
            $newVersion = '';
            if ($request->type == 1) {
                $exp = explode('.', $version);
                if (!empty($exp[1]) && $exp[1] != 9) {
                    $newVersion = $exp[0].'.'.++$exp[1];
                } elseif (!empty($exp[1]) && $exp[1] == 9) {
                    $newVersion = ++$exp[0];
                } else {
                    $newVersion = $version.'.1';
                }
            }
            if ($request->type == 2) {
                $exp = explode('.', $version);
                $newVersion = ++$exp[0];
            }
            // Mettre a jour la table des versions (version_apps)
            $vers = new VersionApps();
            $vers->version = $newVersion;
            $vers->id_app = $request->id_app;
            $vers->save();

            // Mettre a jour la table des historique versions (applications_version_history)
            foreach ($data as $key) {
                $applicationHist = new AppsVersionHistory();
                $applicationHist->text = $key->text;
                $applicationHist->niv = $key->niv;
                $applicationHist->parent = $key->parent;
                $applicationHist->text_stat = $key->text_stat;
                $applicationHist->ordre = $key->ordre;
                $applicationHist->num_parag = $key->num_parag;
                $applicationHist->id_template = $key->id_template;
                $applicationHist->user_id = $key->user_id;
                $applicationHist->id_app = $key->id_app;
                $applicationHist->aide = $key->aide;
                $applicationHist->modified = $key->modified;
                $applicationHist->version = $version;

                $applicationHist->save();
            }
            // Update parent first Niv
            $dataUpdateFirstNiv = AppsVersionHistory::where('id_app', '=', $request->id_app)->where('version', '=', $version)
                ->where('niv', '=', 1)->get()->each(
                    function ($item) use ($version) {
                        $expOne = explode('.', $item->num_parag);
                        $parent = AppsVersionHistory::where('id_app', '=', $item->id_app)->where('version', '=', $version)
                            ->where('num_parag', '=', $expOne[0])->where('niv', '=', 0)->first();
                        $applicationNivOne = AppsVersionHistory::where('id','=',$item->id)->first();
                        $applicationNivOne->text = $item->text;
                        $applicationNivOne->niv = $item->niv;
                        $applicationNivOne->text_stat = $item->text_stat;
                        $applicationNivOne->ordre = $item->ordre;
                        $applicationNivOne->num_parag = $item->num_parag;
                        $applicationNivOne->id_template = $item->id_template;
                        $applicationNivOne->user_id = $item->user_id;
                        $applicationNivOne->id_app = $item->id_app;
                        $applicationNivOne->parent =  $parent['id'];
                        $applicationNivOne->save();
                    });
            // Update parent Second Niv
            $dataUpdateSecondNiv = AppsVersionHistory::where('id_app', '=', $request->id_app)->where('version', '=', $version)
                ->where('niv', '=', 2)->get()->each(
                    function ($item) use ($version) {
                        $expTwo = explode('.', $item->num_parag);
                        $numprg = $expTwo[0].'.'.$expTwo[1];
                        $fniv = AppsVersionHistory::where('id_app', '=', $item->id_app)->where('version', '=', $version)
                            ->where('num_parag', '=', $numprg)->where('niv', '=', 1)->first();
                        $applicationNivTwo = AppsVersionHistory::where('id','=',$item->id)->first();
                        $applicationNivTwo->text = $item->text;
                        $applicationNivTwo->niv = $item->niv;
                        $applicationNivTwo->text_stat = $item->text_stat;
                        $applicationNivTwo->ordre = $item->ordre;
                        $applicationNivTwo->num_parag = $item->num_parag;
                        $applicationNivTwo->id_template = $item->id_template;
                        $applicationNivTwo->user_id = $item->user_id;
                        $applicationNivTwo->id_app = $item->id_app;
                        $applicationNivTwo->parent =  $fniv['id'];
                        $applicationNivTwo->save();
                    });
        }

        $dataCheked = ApplicationsContent::select('id', 'modified')->where('id_app', $request->id_app)->get();
        return $dataCheked;
    }

    public function editAppContent($req, $id)
    {
        $application = ApplicationsContent::where('id','=',$id)->first();

        $application->text_stat = $req->text_stat;
        $application->modified = 1;
        $application->save();

        $appsParams = new Applications();
        $version = Applications::where('id', '=', $req->id_app)->first();

        if (empty($version['version'])) {
            $newVersion = 1;
        } else {
            $exp = explode('.', $version['version']);
            if (!empty($exp[1]) && $exp[1] != 9) {
                $newVersion = $exp[0].'.'.++$exp[1];
            } elseif (!empty($exp[1]) && $exp[1] == 9) {
                $newVersion = ++$exp[0];
            } else {
                $newVersion = $version['version'].'.1';
            }
        }

        $version->version = $newVersion;
        $version->save();

        return $newVersion;
    }


}

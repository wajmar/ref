<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Request;
use Location;
use Laralum;

class TemplatesParams extends Model
{
    protected $table = 'templates_params';  

   public function addtpl($request)
    {
        $tplParams = TemplatesParams::where('type', '=', $request->type)->max('id');

        $tpl = new TemplatesParams();
        $tpl->version = $request->version;
        $tpl->comment = $request->comment;
        $tpl->user_id = $request->user_id;
        $tpl->type    = $request->type;
       
        $tpl->save();
        $insertedId = $tpl->id;
        if ($tplParams) {            
            if ($insertedId) {
                $data = Templates::where('id_template', '=', $tplParams)->get()->each(
                    function ($item) use ($insertedId) {
                        $templates = new Templates();
                        $templates->id_template = $insertedId;
                        $templates->text = $item->text;
                        $templates->type = $item->type;
                        $templates->niv = $item->niv;
                        $templates->parent = $item->parent;
                        $templates->text_stat = $item->text_stat;
                        $templates->ordre = $item->ordre;
                        $templates->num_parag = $item->num_parag;
                        $templates->user_id = $item->user_id;                        
                        $templates->save();
                });
            }
        
            // Update parent first Niv
            $dataUpdateFirstNiv = Templates::where('id_template', '=', $insertedId)
            ->where('niv', '=', 1)->get()->each(
                function ($item) use ($request) {
                $expOne = explode('.', $item->num_parag);
                $parent = Templates::where('id_template', '=', $item->id_template)
                        ->where('num_parag', '=', $expOne[0])->where('niv', '=', 0)->first();
                        $templatesNivOne = Templates::where('id','=',$item->id)->first();
                        $templatesNivOne->text = $item->text;
                        $templatesNivOne->niv = $item->niv;
                        $templatesNivOne->text_stat = $item->text_stat;
                        $templatesNivOne->ordre = $item->ordre;
                        $templatesNivOne->num_parag = $item->num_parag;
                        $templatesNivOne->id_template = $item->id_template;
                        $templatesNivOne->user_id = $request->user_id;
                        $templatesNivOne->parent =  $parent['id'];
                        $templatesNivOne->save();               
            });
            // Update parent Second Niv
            $dataUpdateSecondNiv = Templates::where('id_template', '=', $insertedId)
            ->where('niv', '=', 2)->get()->each(
                function ($item) use ($request) {
                $expTwo = explode('.', $item->num_parag);
                $numprg = $expTwo[0].'.'.$expTwo[1];
                $fniv = Templates::where('id_template', '=', $item->id_template)
                        ->where('num_parag', '=', $numprg)->where('niv', '=', 1)->first();
                        $templatesNivTwo = Templates::where('id','=',$item->id)->first();
                        $templatesNivTwo->text = $item->text;
                        $templatesNivTwo->niv = $item->niv;
                        $templatesNivTwo->text_stat = $item->text_stat;
                        $templatesNivTwo->ordre = $item->ordre;
                        $templatesNivTwo->num_parag = $item->num_parag;
                        $templatesNivTwo->id_template = $item->id_template;
                        $templatesNivTwo->user_id = $request->user_id;
                        $templatesNivTwo->parent =  $fniv['id'];
                        $templatesNivTwo->save();               
            });
        }
        return true;
    }

    public function addtplFusion($request)
    {
        // Ajout dans templates_params
        $tplParams = TemplatesParams::where('type', '=', $request->type)->max('id');

        $tpl = new TemplatesParams();
        $tpl->version = $request->version;
        $tpl->comment = $request->comment;
        $tpl->user_id = $request->user_id;
        $tpl->type    = $request->type;
        $tpl->save();
        $request->id_template = $tpl->id;

        $data = json_decode($request->data, true);
        $i = 1;
        if ($request->id_template) {
            foreach ($data as $key) {
                $exp = explode('/', $key['id']);
                $nPrg = $exp[0];            
                $idTpl = $exp[1];
                $data = Templates::where('id_template', '=', $idTpl)->where('num_parag', '=', $nPrg)->get()->each(
                    function ($item) use ($request, $i, $key) {
                        $templates = new Templates();                   
                        $templates->id_template = $request->id_template;
                        $templates->text = $item->text;
                        $templates->type = $request->type;
                        $templates->niv = $item->niv;
                        $templates->text_stat = $item->text_stat;
                        $templates->ordre = $i;
                        $templates->parent = 0;
                        $templates->num_parag = $i;
                        $templates->user_id = $request->user_id;                        
                        $templates->save();
                        $idParent =  $templates->id;
                        if (!empty($key['children'])) {
                            $j = 1;
                            foreach ($key['children'] as $child) {
                                $exp = explode('/', $child['id']);
                                $nPrgChild = $exp[0];            
                                $idTplCild = $exp[1];
                                $dataChild = Templates::where('id_template', '=', $idTplCild)->where('num_parag', '=', $nPrgChild)->get()->each(
                                    function ($item) use ($request, $i, $idParent, $j, $child) {
                                        $templatesCildF = new Templates();                   
                                        $templatesCildF->id_template = $request->id_template;
                                        $templatesCildF->text = $item->text;
                                        $templatesCildF->type = $request->type;
                                        $templatesCildF->niv = $item->niv;
                                        $templatesCildF->text_stat = $item->text_stat;
                                        $templatesCildF->ordre = $j;
                                        $templatesCildF->parent = $idParent;
                                        $templatesCildF->num_parag = $i.'.'.$j;
                                        $templatesCildF->user_id = $request->user_id;                           
                                        $templatesCildF->save();
                                        $idParentCild =  $templatesCildF->id;
                                        if (!empty($child['children'])) {
                                            $k = 1;
                                            foreach ($child['children'] as $childS) {
                                                $exp = explode('/', $childS['id']);
                                                $nPrgChildS = $exp[0];            
                                                $idTplCildS = $exp[1];
                                                $dataChildS = Templates::where('id_template', '=', $idTplCildS)->where('num_parag', '=', $nPrgChildS)->get()->each(
                                                    function ($item) use ($request, $i, $idParentCild, $j, $k) {
                                                        $templatesCildS = new Templates();                   
                                                        $templatesCildS->id_template = $request->id_template;
                                                        $templatesCildS->text = $item->text;
                                                        $templatesCildS->type = $request->type;
                                                        $templatesCildS->niv = $item->niv;
                                                        $templatesCildS->text_stat = $item->text_stat;
                                                        $templatesCildS->ordre = $k;
                                                        $templatesCildS->parent = $idParentCild;
                                                        $templatesCildS->num_parag = $i.'.'.$j.'.'.$k;
                                                        $templatesCildS->user_id = $request->user_id;                           
                                                        $templatesCildS->save();
                                                    });
                                                ++$k;
                                            }
                                        }
                                    });
                                ++$j;
                            }
                        }
                });
                ++$i;
            }
        }
        return true;
    }
}
<?php 

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Http\Requests;

class Experience extends Model{

	protected $table = "experiences";

	public function add_report($request){

		$exp = new Experience();
		$exp->page = $request->page_report;
		$exp->comment = $request->comment_report;
		$exp->status = 'Nouveau';
		$exp->criticite = $request->criticite_report;
		$exp->type = $request->type_report;
		$exp->wished_at = $request->wishdate;
		$exp->planned_at = 'N/A';
		$exp->id_user = $request->id_user;
		$exp->save();
		return $exp;
	}

	public function edit($request){
		$exp = Experience::where('id',$request->id_retexp)->first();
		$exp->status = $request->statut_retexp;
		$exp->planned_at = $request->date_retexp;
		$exp->save();
		return $exp;
	}
}

?>
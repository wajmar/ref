<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Request;
use Location;
use Laralum;

class HistApplications extends Model
{
    protected $table = 'histo_applications';
   
}

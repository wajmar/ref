<?php

namespace App\Http\Controllers\Laralum;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\TemplatesParams;
use App\TypeTpl;
use App\Templates;

class TemplatesParamsController extends Controller
{
    /**
     * [index description]
     * @return [type] [description]
     */
    public function index()
    {
        # Check projects permissions
        Laralum::permissionToAccess('refarc.templates.access');

        $templates = Laralum::templatesList();   
        $tplType = Laralum::getTypeTpl();    
        
        return view(
            'laralum/templates/index',
            [
                'templates' =>  $templates,
                'tpltype' => $tplType
            ]
        );
    }

    /**
     * [index description]
     * @return [type] [description]
     */
    public function fusion()
    {
        # Check projects permissions
        Laralum::permissionToAccess('refarc.templates.access');
        Laralum::permissionToAccess('refarc.templates.edit');

        $templates = Laralum::templatesList();   
        $tplType = Laralum::getTypeTpl();    
        
        return view(
            'laralum/templates/fusion',
            [
                'templates' =>  $templates,
                'tplType' => $tplType
            ]
        );
    }

    /**
     * [index description]
     * @return [type] [description]
     */
    public function getdataFusion(request $request)
    {
        # Check projects permissions
        Laralum::permissionToAccess('refarc.templates.access');
        Laralum::permissionToAccess('refarc.templates.edit');
        $data = '<ol class="dd-list">';

        $tplsParents = Templates::select(['id', 'text', 'num_parag', 'id_template'])->where('id_template', '=', $request->id)
        ->where('niv', '=', 0)->get();
        $tplsFirsts = Templates::select(['id', 'text', 'num_parag', 'parent', 'id_template'])->where('id_template', '=', $request->id)
        ->where('niv', '=', 1)->get();
        $tplsSeconds = Templates::select(['id', 'text', 'num_parag', 'parent', 'id_template'])->where('id_template', '=', $request->id)
        ->where('niv', '=', 2)->get();

        if (empty($tplsParents)) {
            return '';
        }
        $i = 1;            
        foreach ($tplsParents as $tplsParent) {
             $data .= '<input type="hidden" id="tplNew" value="' . $tplsParent->id_template . '"><li class="dd-item"  data-id="'. $tplsParent->num_parag .'/'. $tplsParent->id_template .'">
             <div class="dd-handle"><span id="nprg_'. $i .'_'. $tplsParent->id_template .'">'. $tplsParent->num_parag .'</span> '. $tplsParent->text .'</div>';
             $j = 1;
             foreach ($tplsFirsts as $tplsFirst) {
                if ($tplsFirst->parent == $tplsParent->id) {
                    $data .= '<ol class="dd-list">';
                    $data .= '<li class="dd-item" data-id="'. $tplsFirst->num_parag .'/'. $tplsFirst->id_template .'">
                        <div class="dd-nodrag"><span id="nprgF_'. str_replace('.', '_', $tplsFirst->num_parag) .'_'. $tplsFirst->id_template .'">'. $tplsFirst->text .'</div>';
                    $k = 1;
                    foreach ($tplsSeconds as $tplsSecond) {
                        if ($tplsSecond->parent == $tplsFirst->id) {
                            $data .= '<ol class="dd-list">';
                            $data .= '<li class="dd-item" data-id="'. $tplsSecond->num_parag .'/'. $tplsSecond->id_template .'">
                                <div class="dd-nodrag"><span id="nprgS_'. $i .'_'. $j .'_'. $k .'_'. $tplsSecond->id_template .'">'. $tplsSecond->text .'</div>';
                            $data .= '</li>'; 
                            $data .= '</ol>';   
                        }
                        ++$k;
                     }
                    $data .= '</li>'; 
                    $data .= '</ol>';   
                }
                ++$j;
             }
             $data .= '</li>';
             ++$i;                        
         }
          $data .= '</ol>'; 
        
        return $data;        
    }

    /**
     * [index description]
     * @return [type] [description]
     */
    public function createTplFusion(Request $request)
    {
        # Check projects permissions
        Laralum::permissionToAccess('refarc.templates.access');

        # Check projects permissions
        Laralum::permissionToAccess('refarc.templates.create');

        $templatesExist = TypeTpl::where('type', '=', $request->type)->first();
        if (!empty($templatesExist)) {
            return 'exist';
        }
      
        $type = new TypeTpl();
        $type->type = $request->type;
        $type->save();
        $insertedId = $type->id;
  
        $request['type'] = $insertedId;
        $request['user_id'] = Laralum::loggedInUser()->id;
        $request->version = 1;

        $app = new TemplatesParams();
        $app->addtplFusion($request);

        $lastId = TemplatesParams::where('type', '=', $request->type)->max('id');
        
        return $lastId;
    }
	public function delTpls(Request $request)
    {
        Laralum::permissionToAccess('refarc.templates.access');

        # Check permissions
        Laralum::permissionToAccess('refarc.templates.edit');

        # Find The tpl
        $tpl = new TemplatesParams();

        $tpl = TemplatesParams::where('id', $request->idTpl)->first();

        $tpl->delete();

        $cntTpl = new Templates();

        $cntTpl = Templates::where('id_template', $request->idTpl)->get()->each(
            function ($item) {
                $item->delete();
            });

        return redirect()->route('Laralum::templates')->with('success', 'Le template a bien ?t? supprim?!');

    }

    public function validTpl(Request $request)
    {
        Laralum::permissionToAccess('refarc.templates.access');

        # Check permissions
        Laralum::permissionToAccess('refarc.templates.edit');

        # Find The tpl

        $tpl = TemplatesParams::where('id', $request->idTpl)->first();

        $tpl->valid = 1;

        $tpl->save();

        return redirect()->route('Laralum::templates')->with('success', 'Le template a bien �t� valid�!');

    }

    /**
     * [index description]
     * @return [type] [description]
     */
    public function create(Request $request)
    {
        # Check projects permissions
        Laralum::permissionToAccess('refarc.templates.access');

        # Check projects permissions
        Laralum::permissionToAccess('refarc.templates.create');

        $request['user_id'] = Laralum::loggedInUser()->id;
        $version = TemplatesParams::where('type', '=', $request->type)->max('version');          
        if (!empty($version)) {
            $request->version = ++$version;
        } else {
            $request->version = 1;
        }
        $app = new TemplatesParams();
        $app->addtpl($request);

        $lastId = TemplatesParams::where('type', '=', $request->type)->max('id');
        
        return $lastId;
    }


    public function update($id, Request $request)
    {
        Laralum::permissionToAccess('refarc.applications.access');

        # Check permissions
        Laralum::permissionToAccess('refarc.applications.edit');

        $req = $request;
        $req_id = $request['id'];

        $app = new Applications();
        $app->editApp($req_id,$req);

        $row = Laralum::application('id', $req_id);

        return $row;
        
    }  

    public function types(Request $request){

        // Recuperation des templates
        $tpls = Laralum::templatesList();

        // Recuperation des types de templates
        $tpl_types = Laralum::getTypeTpl();

        return view('laralum/templates/types',['tpl_types' =>  $tpl_types,'tpls' => $tpls]);

    }

    public function add_type(request $request)
    {
        
        $templatesExist = TypeTpl::where('type', '=', $request->type_name)->first();
        // test d'unicite du type
        if (!empty($templatesExist)) {
            return 'exist';
        }
        $type = new TypeTpl();
        $type = $type->add_type($request);
  
        // Recuperation des templates
        $tpls = Laralum::templatesList();

        // Recuperation des types de templates
        $tpl_types = Laralum::getTypeTpl();

        return view('laralum/templates/types_list',['tpl_types' =>  $tpl_types,'tpls' => $tpls]);   
    }  

    public function edit_type(Request $request){

        $type_tpl = new TypeTpl();
        // Modification du type
        $type_tpl = $type_tpl->edit_type($request);

        // Recuperation des templates
        $tpls = Laralum::templatesList();

        // Recuperation des types de templates
        $tpl_types = Laralum::getTypeTpl();

        return view('laralum/templates/types_list',['tpl_types' =>  $tpl_types,'tpls' => $tpls]);
    }

    public function delete_type(Request $request){

        $type_tpl = new TypeTpl();
        // Suppression du type
        $type_tpl = $type_tpl->delete_type($request);

        // Recuperation des templates
        $tpls = Laralum::templatesList();

        // Recuperation des types de templates
        $tpl_types = Laralum::getTypeTpl();

        return view('laralum/templates/types_list',['tpl_types' =>  $tpl_types,'tpls' => $tpls]);
    }  
}

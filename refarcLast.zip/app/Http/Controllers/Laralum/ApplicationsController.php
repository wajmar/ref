<?php

namespace App\Http\Controllers\Laralum;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Applications;
use App\ApplicationsContent;
use App\ApplicationsPlanning;
use App\Templates;
use App\TemplatesParams;
use App\TemplatesInterv;
use App\TemplatesDiff;
use App\Intervenants;
use App\Diffusion;
use App\VersionApps;
use App\AppsVersionHistory;

class ApplicationsController extends Controller
{
    /**
     * [index description]
     * @return [type] [description]
     */
    public function index($id, $idApp)
    {
        # Check projects permissions
        Laralum::permissionToAccess('refarc.applications.access');

        //$appsParams = Laralum::application('id', $idApp);

        $applications = Laralum::application('id', $idApp);
        $project = Laralum::project('id', $id);
        $name_project = $project->name;
        # Get all history
        $history = Laralum::applicationsHist('id_original', $idApp);
        // Recuperation de la liste des intervenants et de diffusion
        $intervenants = Intervenants::where('id_app', $idApp)->get();
        $diffusion = Diffusion::where('id_app', $idApp)->get();
        // Recuperatation de la liste des intervenants et diffusion generiques
        $generic_interv = TemplatesInterv::all();
        $generic_diff = TemplatesDiff::all();
        // Recupere les jalons
        $jalons = ApplicationsPlanning::where('id_app', $idApp)->get();
        // Recupere les versions ant�rieures
        $versHist = AppsVersionHistory::where('id_app', $idApp)->groupBy('version')->orderBy('version', 'desc')->get();
        // Recupere les versions
        $versApps = VersionApps::where('id_app', $idApp)->orderBy('version', 'desc')->get();

        //print_r($versHist);die;

        # Return the view
        return view(
            'laralum/projects/applications/index',
            [
                'applications' => $applications,
                'history' => $history,
                'nameProj' => $name_project,
                //'appsParams' => $appsParams,
                'intervenants' => $intervenants,
                'diffusion' => $diffusion,
                'jalons' => $jalons,
                'generic_interv' => $generic_interv,
                'generic_diff' => $generic_diff,
                'versHist' => $versHist,
                'versApps' => $versApps
            ]
        );
    }

   public function apps($id, $idApp)
    {
        # Check projects permissions
        Laralum::permissionToAccess('refarc.applications.access');
        $percent = 0;

        $appsContent = Laralum::applicationscontentId('id_app', $idApp);
        $appsParams = laralum::application('id', $idApp);
        $idTpl = $appsParams['template_id'];
        $tpl = laralum::templatesParamsLast('id', $appsParams->template_id);
        $modified = false;

        if (empty($appsContent)) {
            $parents = Laralum::templatesNiv(['niv' => 0, 'id_template' => $idTpl]);
            $first_nivs = Laralum::templatesNiv(['niv' => 1, 'id_template' => $idTpl]);
            $second_nivs = Laralum::templatesNiv(['niv' => 2, 'id_template' => $idTpl]);
            $modified = true;
        } else {
            $parents = Laralum::applicationsNiv(['niv' => 0, 'id_app' => $idApp]);
            $first_nivs = Laralum::applicationsNiv(['niv' => 1, 'id_app' => $idApp]);
            $second_nivs = Laralum::applicationsNiv(['niv' => 2, 'id_app' => $idApp]);
            $dataCountmodified = Laralum::applicationsNiv(['id_app' => $idApp, 'modified' => 1]);
            $totalCount = Laralum::applicationsNiv(['id_app' => $idApp]);
            $countModified = count($dataCountmodified);
            $countTotal = count($totalCount);
            $percent = $countModified/$countTotal*100;
        }
        $data = Laralum::applicationsNiv('id_app', $idApp);
        if (!empty($data)) {
            foreach ($data as $key) {
                if ($key['modified'] == 0) {
                    $modified = true;
                    continue;
                }
            }
        }

        $vers = VersionApps::where('id_app', $idApp)->max('version');
        return view(
            'laralum/projects/apps',
            [
                'id' => $id,
                'parents' => $parents,
                'first_nivs' => $first_nivs,
                'second_nivs' => $second_nivs,
                'tpl' => $tpl,
                'appsParams' => $appsParams,
                'modified' => $modified,
                'idTpl' => $idTpl,
                'version'   => $vers,
                'percent'   => $percent
            ]
        );
    }

    public function activeEdit($id, Request $request)
    {
        Laralum::permissionToAccess('refarc.applications.access');

        # Check permissions
        Laralum::permissionToAccess('refarc.applications.edit');

        if ($request->stat == 'editor') {
            $appsParams = new Applications();
            $data = Applications::where('id', $request->id)->first();
            if ($data->active_edit === NULL) {
                $appsParams->where('id', $request->id)
                ->update(['active_edit' => Laralum::loggedInUser()->id]);
                return 'edit';
            } elseif ($data->active_edit === Laralum::loggedInUser()->id) {
                $appsParams->where('id', $request->id)
                ->update(['active_edit' => NULL]);
                return 'stopedEdit';
            } else {
                return $data->active_edit;
            }
        }
        return $request->stat;
    }

    public function createParagrapApp(Request $request)
    {
        Laralum::permissionToAccess('refarc.applications.access');

        # Check permissions
        Laralum::permissionToAccess('refarc.applications.edit');

        $request->user_id = Laralum::loggedInUser()->id;

        $app = new ApplicationsContent();

        $dataExist = ApplicationsContent::where('id_app', $request->id_app)->first();

        if (empty($dataExist)) {
            $addApp = $app->addAppContent($request);
            return $addApp;
        } else {
            $updateApp = $app->updateAppContent($request);
            return $updateApp;
        }

    }

    public function update($id, Request $request)
    {
        Laralum::permissionToAccess('refarc.applications.access');

        # Check permissions
        Laralum::permissionToAccess('refarc.applications.edit');
        $req = $request;
        $req_id = $request['id'];

        $app = new Applications();
        $app->editApp($req_id,$req);

        $row = Laralum::application('id', $req_id);

    	return $row;
        
    }

    public function create($id, Request $request)
    {
        # Check permissions
        Laralum::permissionToAccess('refarc.applications.access');
        Laralum::permissionToAccess('refarc.applications.create');
        $app = new Applications();
        $request['user_id'] = Laralum::loggedInUser()->id;
        $app->addApp($request);

	
        // Incrementation du nombre d'applications
        $tpl_inc_nbapps = Laralum::templatesParamsLast("id",$request->type_doc);
        $tpl_inc_nbapps->nbapps++;
        $tpl_inc_nbapps->save();

        $applications = Laralum::applications('project_id', $id);
        $projects = Laralum::project('id', $id);
        # Get all users
        $users = Laralum::users();
        # Get all history
        $history = Laralum::projectHist('id_original', $id);

        // Recuperation des templates
        $templates = Laralum::templatesList();
        // Recuperation des types de templates
        $tplType = Laralum::getTypeTpl();

        $listTpl = [];

        for($i=0;$i<count($tplType);$i++){
            for($j=0;$j<count($templates);$j++){
                if($tplType[$i]->id == $templates[$j]->type){
                    //print_r('added -----');
                    //print_r($tplType[$i]->id.''.$templates[$j]->type);
                    $listTpl[$i] = $templates[$j];
                }else{
                    //print_r('not added -----');
                    //print_r($tplType[$i]->id.''.$templates[$j]->type);
                }
            }
        }

        # Return the view
        return view(
            'laralum/projects/suivi',
            [
            'projects' =>  $projects,
            'users' =>  $users,
            'applications' =>  $applications,
            'history' =>  $history,
            'templates' => $listTpl,
            'tplType' => $tplType, 
            ]
        );
        
    }

    public function versionup(Request $request)
    {
        # Check permissions
        Laralum::permissionToAccess('refarc.applications.access');
        Laralum::permissionToAccess('refarc.applications.edit');      
        $appsParams = new Applications();
        $version = Applications::where('id', '=', $request->app)->first();
        $el = explode('.', $version['version']);
        $newversion = ++$el[0];
        $version->version = $newversion;
        $version->save();        
        return $newversion;         
    }
}

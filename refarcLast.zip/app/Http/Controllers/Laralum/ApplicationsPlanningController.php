<?php

namespace App\Http\Controllers\Laralum;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\ApplicationsPlanning;

class ApplicationsPlanningController extends Controller
{
    /**
     * [index description]
     * @return [type] [description]
     */
    public function index($id, $idApp)
    {
        
    } 

    public function add_jalon($id,$idApp,Request $request){

      $app_planning = new ApplicationsPlanning();

      // Traitement pour la date
      $date = explode("/",$request->date);
      $date = $date[2]."-".$date[0]."-".$date[1];

      $app_planning->jalon = $request->name;
      $app_planning->date = $date;
      $app_planning->commentaires = $request->comments;
      $app_planning->id_app = $idApp;
      $app_planning->save();

      return $app_planning;
    }

    public function del_jalon($id,$idApp,$idJalon){

      $app_planning = ApplicationsPlanning::where('id',$idJalon);
      $app_planning->delete();

      return $idJalon;
    }

}

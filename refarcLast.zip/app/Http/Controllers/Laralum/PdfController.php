<?php 

namespace App\Http\Controllers\Laralum;

use App\Http\Controllers\Controller;
use App\Intervenants;
use App\User;
use App\AppsVersionHistory;

class PdfController extends Controller{

	protected $application;

	public function index($idApp){

		require('htmlparser.php');

		// Fichier temporaire
		$TEMPIMG = 'tempimg.png';

		// Récupération des paragraphes du template
		$application = Laralum::applications('id',$idApp);
		$templates = Laralum::templates('id_template',$application[0]->template_id);
		$intervenants = Laralum::intervenants('id_app',$idApp);
		$templates_interv = Laralum::templates_interv();
		$templates_diff = Laralum::templates_diff();
		$diffusions = Laralum::diffusion('id_app',$idApp);
		$creator = User::find($application[0]->user_id)->name;
		$prgs_content = Laralum::applicationscontent('id_app',$idApp);

		// Parametres du document
		$pdf = new FPDF($idApp);
		$pdf->AliasNbPages();
		$pdf->AddPage();
		$pdf->SetFont('Arial','B',16);
		$pdf->SetLeftMargin(10);
		$pdf->SetRightMargin(10);
		//$pdf->SetAutoPageBreak(true,2);
		// Première Page
		//////////////////////////////////////////////
		$pdf->SetY(70);
		$pdf->SetFillColor(103, 128, 159);
		$pdf->SetTextColor(255,255,255);
		$pdf->Cell(0,15,'Application '.$application[0]->name,1,1,'C',true);
		$pdf->SetTextColor(0,0,0);
		$pdf->SetY(120);
		$pdf->SetFontSize(28);
		$pdf->Cell(0,15,'Dossier d\'architecture Hebergement (DAH)',0,1,'C');
		$pdf->SetFontSize(14);
		$pdf->SetY(150);
		$pdf->SetFont('Arial','',16);
		$pdf->Cell(80,7,'Ecolience','LTR',0,'R');
		$pdf->Cell(100,7,$application[0]->ecolience,'TR',1,'L');
		$pdf->Cell(80,7,'Nom','LR',0,'R');
		$pdf->Cell(100,7,$application[0]->name,'R',1,'L');
		$pdf->Cell(80,7,'Trigramme','LR',0,'R');
		$pdf->Cell(100,7,$application[0]->trigramme,'R',1,'L');
		$pdf->Cell(80,7,'Criticite STAMP','LR',0,'R');
		$pdf->Cell(100,7,$application[0]->criticite_stamp,'R',1,'L');
		$pdf->Cell(80,7,'Sensible Groupe','LR',0,'R');
		$pdf->Cell(100,7, ($application[0]->sensible_groupe == 1)?'OUI':'NON','R',1,'L');
		$pdf->Cell(80,7,'Niveau sensibilite a la fraude','LBR',0,'R');
		$pdf->Cell(100,7,$application[0]->niv_sensible_fraude,'BR',1,'L');
		$pdf->Cell(80,7,'Demande Client','LBR',0,'R');
		$pdf->SetFont('Arial','',14);
		$pdf->Cell(100,7,'Fichier : EBQ "FLA-EBQ.xlsx" - 05/09/2016','BR',1,'L');
		$pdf->Ln();
		$pdf->Ln();
		$pdf->SetFont('Arial','B',20);
		$pdf->Cell(0,20,'Version : 1.1',0,1,'C');
		$pdf->Cell(0,20,'Statut : '.$application[0]->statu,0,1,'C');
		$pdf->SetFont('Arial','',10);
		$pdf->SetY(-20);
		// Deuxième Page
		//////////////////////////////////////////////
		$pdf->AddPage();
		$pdf->SetY(32);
		$pdf->SetFont('Arial','BU',12);
		$pdf->Cell(0,10,'FICHE DE CONTROLE DU DOCUMENT',0,1,'C');
		$pdf->SetFont('Arial','B',11);
		$pdf->Write(5,'Caracteristiques du document');
		$pdf->Ln(6);
		$pdf->SetFont('Arial','B',10);
		$pdf->Cell(40,5,'Statut','LTRB',0,'L');
		$pdf->SetFont('Arial','',10);
		$pdf->Cell(150,5,$application[0]->statu,'BTR',1,'L');
		$pdf->SetFont('Arial','B',10);
		$pdf->Cell(40,5,'Ref. fichier','LBR',0,'L');
		$pdf->SetFont('Arial','',10);
		$pdf->Cell(150,5,'DAH application FLA','BR',1,'L');
		$pdf->Ln();  
		$pdf->SetFont('Arial','B',11);
		$pdf->Write(5,'Creation et suivi du document');
		$pdf->Ln(6);
		$pdf->SetFont('Arial','B',10);
		$pdf->Cell(20,5,'Version','LTRB',0,'L');
		$pdf->Cell(25,5,'Cree le','LTRB',0,'L');
		$pdf->Cell(45,5,'Auteur','LTRB',0,'L');
		$pdf->Cell(100,5,'Commentaires','LTRB',1,'L');
		$pdf->SetFont('Arial','',10);
		$pdf->Cell(20,5,'1.0','LTRB',0,'L');
		$date = explode(" ",$application[0]->created_at);
		$pdf->Cell(25,5,$date[0],'LTRB',0,'L');
		$pdf->Cell(45,5,User::find($application[0]->user_id)->name,'LTRB',0,'L');
		$pdf->Cell(100,5,'Statut : '.$application[0]->statu,'LTRB',1,'L');
		$pdf->Ln();
		$pdf->SetFont('Arial','B',11);
		$pdf->Write(5,'Intervenants sur le projet');
		$pdf->Ln(6);
		$pdf->SetFont('Arial','B',10);
		$pdf->Cell(40,5,'Entite/Service','LTRB',0,'L');
		$pdf->Cell(80,5,'Domaine de responsabilite','LTRB',0,'L');
		$pdf->Cell(70,5,'Nom de l\'intervenant','LTRB',1,'L');
		$pdf->SetFont('Arial','',10);
		// boucle pour integrer la liste des intervenants generiques
		foreach($templates_interv as $temp_interv){
			$pdf->Cell(40,5,$temp_interv->entite,'LTRB',0,'L');
			$pdf->Cell(80,5,$temp_interv->resp_domain,'LTRB',0,'L');
			$pdf->Cell(70,5,$temp_interv->nom,'LTRB',1,'L');
		}
		// boucle pour integrer les intervenants
		foreach($intervenants as $interv){
			$pdf->Cell(40,5,$interv->entite,'LTRB',0,'L');
			$pdf->Cell(80,5,$interv->resp_domain,'LTRB',0,'L');
			$pdf->Cell(70,5,$interv->nom,'LTRB',1,'L');	
		}
		$pdf->Ln();
		$pdf->SetFont('Arial','B',11);
		$pdf->Write(5,'Liste de diffusion');
		$pdf->Ln(6);	
		$pdf->SetFont('Arial','B',10);
		$pdf->Cell(60,5,'Entite','LTRB',0,'L');
		$pdf->Cell(100,5,'Nom des destinaires','LTRB',0,'L');
		$pdf->Cell(30,5,'Objet','LTRB',1,'L');
		$pdf->SetFont('Arial','',10);
		// boucle pour integerer la liste de diffusion generique
		foreach($templates_diff as $temp_diff){
			$pdf->Cell(60,5,$temp_diff->entite,'LTRB',0,'L');
			$pdf->Cell(100,5,$temp_diff->nom,'LTRB',0,'L');
			$pdf->Cell(30,5,$temp_diff->objet,'LTRB',1,'L');
		}
		// boucle pour integrer la liste de diffusion
		foreach($diffusions as $diff){
			$pdf->Cell(60,5,$diff->entite,'LTRB',0,'L');
			$pdf->Cell(100,5,$diff->nom,'LTRB',0,'L');
			$pdf->Cell(30,5,$diff->objet,'LTRB',1,'L');
		}
		$pdf->SetY(-20);
		// Fiche de Synthese
		//////////////////////////////////////////////
		$pdf->AddPage();
		$pdf->Ln(5);
		$pdf->Write(5,'FICHE SYNTHESE');
		$pdf->Ln(5);
		$pdf->Cell(60,5,'IRT/ Trigramme(s)','LTR',0,'R');
		$pdf->Cell(130,5,'AAAA/XYZ','LTR',1,'L');
		$pdf->Cell(60,5,'Application(s)','LBR',0,'R');
		$pdf->Cell(130,5,'Nom Application','LBR',1,'L');
		$pdf->Cell(60,5,'Code Ecolience',1,0,'R');
		$pdf->Cell(130,5,'',1,1,'L');
		$pdf->Cell(60,5,'Progiciel(s)',1,0,'R');
		$pdf->Cell(130,5,'Nom(s) + release utilisee par l\'application',1,1,'L');
		$pdf->Cell(60,5,'Typologie Architecture','LTR',0,'R');
		$pdf->Cell(130,5,'Web Transactionnel C1 ou non standard','LTR',1,'L');
		$pdf->Cell(60,5,'','LBR',0,'R');
		$pdf->Cell(130,5,'Web Decisionnel D1,D2 ou on standard','LBR',1,'L');
		$y = $pdf->GetY();
		$pdf->MultiCell(60,5,"Preconisation GTS non retenues par la ME\n\n\n\n",'LTR','R');
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(130,5,"Statut : rediger la vision synthetique de l'architecte\nLister les preconisations non retenues de maniere synthetique\n1. ddd\n2. aaa\nLes points sont detailles dans le § '1.2 vision architecture'",'LBR','L');
		$pdf->Cell(190,7,"Description de l'Architecture de production",1,1,'L');
		$y = $pdf->GetY();
		$pdf->MultiCell(60,5,"Site primaire d'hebergement",1,'R');
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(130,5,"Tigery / Marcoussis DC02 / Seclin2 / Seclin1 Jules Verne - St Exupery / Valmy",1,'L');
		$pdf->Cell(60,5,"Site secondaire",1,0,'R');
		$pdf->MultiCell(130,5,"Seclin2 / Marcoussis DC02",1,'L');
		$y = $pdf->GetY();
		$pdf->MultiCell(60,5,"Modele d'architecture de resilience\n\n\n\n\n\n\n",1,'R');
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(130,5,"1+0:A\n1+0:HA\n1+1:A+A\n1+1:A+Hot Standby\n1+1:A+Hot Standby croise\n1+1:A+Cold Standby\n1+1:HA+Cold Standby",1,'L');
		$y = $pdf->GetY();
		$pdf->MultiCell(60,5,"Modele de solution de resilience de l'ecolience\n",1,'R');
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(130,5,"Bronze,Argent,Or,Saphir,Rubis,Emeraude\nObjectif de delai de retablissement GTS(panne) : 0h,4h,8h,24h",1,'L');
		$y = $pdf->GetY();
		$pdf->MultiCell(60,5,"Modele d'exercice entre deux sites distants atteignable\n\n",1,'R');
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(130,5,"Exercice unitaire hors charge (validation technique)\nExercice hors charge de l'ecolience\nExercice pleine charge de l'ecolience",1,'L');
		$y = $pdf->GetY();
		$pdf->MultiCell(60,5,"Couche metiers\n\n\n\n",1,'R');
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(130,5,"Pour les couches/services ci-dessous, preciser en gras les composants techniques associes a des fonctions applicatives vitales/critiques (par opposition aux fonctions non prioritaires ou secondaires) -> impact direct sur le processus de prise en charge des incidents",1,'L');
		$y = $pdf->GetY();
		$pdf->MultiCell(60,5,"Services d'echanges\n\n\n\n",1,'R');
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(90,5,"WMQ R.m\nConnect:eXpress R.m\nSMTP\n\n",1,'L');
		$pdf->SetY($y);
		$pdf->SetX(160);
		$pdf->MultiCell(40,5,"Ajout\nMise a jour\nRetrait\nReconduit",1,'L');
		$y = $pdf->GetY();
		$pdf->MultiCell(60,5,"Services d'application\n\n\n\n\n",1,'R');
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(90,5,"WebLogic xxRxx et sdk 1.5\nInformation\nTOMCAT\nLa matrice de compatibilite impose une version < a ...\nSi connu, indiquer le niveau de durcissement requis",1,'L');
		$pdf->SetY($y);
		$pdf->SetX(160);
		$pdf->MultiCell(40,5,"...\n\n\n\n\n",1,'L');
		$y = $pdf->GetY();
		$pdf->MultiCell(60,5,"Services Donnes\n\n\n\n\n",1,'R');
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(90,5,"Oracle ww.x.y.z\nIBM DB2 w.x\nMicrosoft SQL Server xxx\nLa matrice de compatibilite impose une version < a ...\nSi connu, indiquer le niveau de durcissement requis",1,'L');
		$pdf->SetY($y);
		$pdf->SetX(160);
		$pdf->MultiCell(40,5,"...\n\n\n\n\n",1,'L');
		$y = $pdf->GetY();
		$pdf->MultiCell(60,5,"Services Ordonnancement",1,'R');
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(90,5,"Control M",1,'L');
		$pdf->SetY($y);
		$pdf->SetX(160);
		$pdf->MultiCell(40,5,"...",1,'L');
		$pdf->SetY(-20);
		$pdf->AddPage();
		$pdf->Ln(5);
		$y = $pdf->GetY();
		$pdf->MultiCell(60,5,"Zone Cellules Securite Reseau (CSR)",1,'R');
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(90,5,"CITSv2,L3,BSC Mutualise,PCMS,CAZA,TNU,GMS,PGN,PEPSY,MAIA",1,'L');
		$pdf->SetY($y);
		$pdf->SetX(160);
		$pdf->MultiCell(40,5,"...\n\n",1,'L');
		$y = $pdf->GetY();
		$pdf->MultiCell(60,5,"Systemes d'exploitation\n\n\n\n",1,'R');
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(90,5,"Linux Red Hat 6.6\nWindows 2012 SPxx\nAIX 6.1 TL3\nLa matrice de comptatibilite impose une version < a ...",1,'L');
		$pdf->SetY($y);
		$pdf->SetX(160);
		$pdf->MultiCell(40,5,"...\n\n\n\n",1,'L');
		$y = $pdf->GetY();
		$pdf->MultiCell(60,5,"Classe de resilience du stockage\n\n",1,'R');
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(90,5,"SAN: M0,M1,L0,L1 + id du groupe de coherence\n\n",1,'L');
		$pdf->SetY($y);
		$pdf->SetX(160);
		$pdf->MultiCell(40,5,"...\n\n",1,'L');
		$y = $pdf->GetY();
		$pdf->MultiCell(60,5,"Conformite standard et politique\n\n\n\n",1,'R');
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(90,5,"Durcissement OS:\nAdvenced\nPremium\nPremium+",1,'L');
		$pdf->SetY($y);
		$pdf->SetX(160);
		$pdf->MultiCell(40,5,"...\n\n\n\n",1,'L');
		$y = $pdf->GetY();
		$pdf->MultiCell(60,5,"Features hors socle a installer\n\n\n\n",1,'R');
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(90,5,"Features a installer hors socle ou ce qui est obligatoire\nJVM Oracle dans la couche DB\nOpenSSH\n\n",1,'L');
		$pdf->SetY($y);
		$pdf->SetX(160);
		$pdf->MultiCell(40,5,"...\n\n\n\n",1,'L');
		$y = $pdf->GetY();
		$pdf->MultiCell(60,5,"Ressources Techniques\n\n\n\n\n",1,'R');
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(130,5,"3 chois possibles :\n-Indiquer les paragraphes correspondants par environnement\n-Mettre ici le tableau récapitulatif tout environnement\n-ou en litteraire",1,'L');
		$y = $pdf->GetY();
		$pdf->MultiCell(60,5,"Offres GTS\n\n\n",1,'R');
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(90,5,"RET : OMLX, SQM, OMDG\nTFO : SIPO [Exotique],etc\nEUS : @PAC,...",1,'L');
		$pdf->SetY($y);
		$pdf->SetX(160);
		$pdf->MultiCell(40,5,"...\n\n\n",1,'L');
		$y = $pdf->GetY();
		$pdf->MultiCell(60,5,"Servitudes\n\n\n",1,'R');
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(90,5,"Sauvegarde Standard TSM ou Lan Free Backup ou specifique (ex : Networker sur Valmy)\nSupervision standard Patrol",1,'L');
		$pdf->SetY($y);
		$pdf->SetX(160);
		$pdf->MultiCell(40,5,"...\n\n\n",1,'L');
		$y = $pdf->GetY();
		$pdf->MultiCell(60,5,"Ressources reseaux\n",1,'R');
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(90,5,"x lien 100 Mb | 1 Gb | 10Gb",1,'L');
		$pdf->SetY($y);
		$pdf->SetX(160);
		$pdf->MultiCell(40,5,"...\n",1,'L');
		$y = $pdf->GetY();
		$pdf->MultiCell(60,5,"Poste de travail\n\n",1,'R');
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(90,5,"Client lourd ou client web NDG ARPEGE IE8\nInternational oui/non",1,'L');
		$pdf->SetY($y);
		$pdf->SetX(160);
		$pdf->MultiCell(40,5,"...\n\n",1,'L');
		$y = $pdf->GetY();
		$pdf->MultiCell(60,5,"Service d'acces\n",1,'R');
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(90,5,"CITRIX,PAX,TRAP,I2BD,GAIA VPN,LS",1,'L');
		$pdf->SetY($y);
		$pdf->SetX(160);
		$pdf->MultiCell(40,5,"...\n",1,'L');
		$y = $pdf->GetY();
		$pdf->MultiCell(60,5,"Processus de livraison des packages applicatifs en production\n",1,'R');
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(90,5,"Earth CDI\nNon standard (scp,client lourd,etc)",1,'L');
		$pdf->SetY($y);
		$pdf->SetX(160);
		$pdf->MultiCell(40,5,"...\n\n",1,'L');
		$y = $pdf->GetY();
		$pdf->MultiCell(60,5,"Principaux ecarts par rapport a la strategie ou aux exigences GTS\n\n\n\n\n\n\n\n\n",1,'R');
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(105,5,"Domaine\n\n",1,'L');
		$pdf->SetY($y);
		$pdf->SetX(175);
		$pdf->MultiCell(25,5,"Ecart ? oui/non\n",1,'L');
		$y = $pdf->GetY();
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(105,5,"Securite",1,'L');
		$pdf->SetY($y);
		$pdf->SetX(175);
		$pdf->MultiCell(25,5,"",1,'L');
		$y = $pdf->GetY();
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(105,5,"Virtualisation comme 1er choix de hosting",1,'L');
		$pdf->SetY($y);
		$pdf->SetX(175);
		$pdf->MultiCell(25,5,"",1,'L');
		$y = $pdf->GetY();
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(105,5,"CITSv2 / L3",1,'L');
		$pdf->SetY($y);
		$pdf->SetX(175);
		$pdf->MultiCell(25,5,"",1,'L');
		$y = $pdf->GetY();
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(105,5,"Capacite a realiser des exercices pleine charge <-> ecosysteme de donnees et de flux definis et valides",1,'L');
		$pdf->SetY($y);
		$pdf->SetX(175);
		$pdf->MultiCell(25,5,"\n\n",1,'L');
		$y = $pdf->GetY();
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(105,5,"RedCat",1,'L');
		$pdf->SetY($y);
		$pdf->SetX(175);
		$pdf->MultiCell(25,5,"",1,'L');
		$y = $pdf->GetY();
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(105,5,"Stategie DataCenter",1,'L');
		$pdf->SetY($y);
		$pdf->SetX(175);
		$pdf->MultiCell(25,5,"",1,'L');
		$y = $pdf->GetY();
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(105,5,"Processus de livraison standard",1,'L');
		$pdf->SetY($y);
		$pdf->SetX(175);
		$pdf->MultiCell(25,5,"",1,'L');
		$pdf->SetY(-20);
		$pdf->AddPage();
		$pdf->Ln(5);
		$y = $pdf->GetY();
		$pdf->MultiCell(60,5,"Principaux ecarts par rapport aux besoins exprimes\n\n\n\n\n",1,'R');
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(130,5,"synthese : xxxxx\n\nLister les ecarts de manière synthetique\n1. Ecart 1: Domaine/description synthetique\n2. ex SLA de disponibilite\n3. ex : couverture de risques",1,'L');
		$y = $pdf->GetY();
		$pdf->MultiCell(60,5,"Synthese de l'avis Securite",1,'R');
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(130,5,"Rappeler le niveau d'ISR indique en cartouche (page de garde)",1,'L');
		$pdf->Ln(10);
		$pdf->Write(5,"Dans le paragraphe 1.2.2, le recapitulatif des besoins declines par offre et par environnement et par site");
		$pdf->Ln(10);
		$pdf->Cell(190,5,"JALON DU PLANNING",1,1,'C');

		$pdf->Cell(60,5,"CVT-I",1,0,'C');
		$pdf->Cell(60,5,"XX/XX/XXXX",1,0,'C');
		$pdf->Cell(70,5,"N/A",1,1,'L');
		$pdf->Cell(60,5,"CVT-Q / QA",1,0,'C');
		$pdf->Cell(60,5,"XX/XX/XXXX",1,0,'C');
		$pdf->Cell(70,5,"",1,1,'L');
		$pdf->Cell(60,5,"CVT-X",1,0,'C');
		$pdf->Cell(60,5,"XX/XX/XXXX",1,0,'C');
		$pdf->Cell(70,5,"",1,1,'L');
		$pdf->Cell(60,5,"Installation en developpement",1,0,'C');
		$pdf->Cell(60,5,"XX/XX/XXXX",1,0,'C');
		$pdf->Cell(70,5,"",1,1,'L');
		$pdf->Cell(60,5,"Mise en homologation-X",1,0,'C');
		$pdf->Cell(60,5,"XX/XX/XXXX",1,0,'C');
		$pdf->Cell(70,5,"",1,1,'L');
		$pdf->Cell(60,5,"Mise en production",1,0,'C');
		$pdf->Cell(60,5,"XX/XX/XXXX",1,0,'C');
		$pdf->Cell(70,5,"",1,1,'L');
		$pdf->Ln(10);
		$pdf->Write(5,"- Tous les acronymes sont recenses dans le 8.5 Glossaire");
		$pdf->Ln();
		$pdf->Write(5,"- Ce document presente le plan type du Dossier d'Architecture Hebergement (DAH) dont la structure et le contenu sont sous la responsabilite de GTS/RET/APS");
		$pdf->Ln();
		$pdf->Write(5,"- Ce DAH (oriente infrastructure) est le document resultant du DAA en entree (orientation metier). Le contenu du DAA est sous la responsabilite de la maitre d'oeuvre du projet");
		$pdf->Ln(10);
		$pdf->Write(5,"Workflow simplifie du DAH");
		$pdf->Ln(50);
		$pdf->Write(5,"- Le processus global de l'etude GTS d'architecture est decrit dans le document 'HAO : Hosting Architecture Offer v1.0' que l'on peut trouver sur ce site (document 'processus d'elaboration d'Architecture Technique')");
		$pdf->Ln();
		$pdf->Write(5,"Les caracteristiques ci-dessous du document sont a renseigner dans les 'prorietes' du document (onglet 'Resume') :");
		$pdf->Ln();
		$pdf->SetX(20);
		$pdf->Write(5,"- Nom du projet");
		$pdf->Ln();
		$pdf->SetX(20);
		$pdf->Write(5,"- Sous titre");
		$pdf->Ln();
		$pdf->SetX(30);
		$pdf->Write(5,"- Objet(Nom application)");
		$pdf->Ln();
		$pdf->SetX(30);
		$pdf->Write(5,"- Categorie ( Nom de l'ecosysteme d'hebergmeent )");
		$pdf->Ln();
		$pdf->SetX(20);
		$pdf->Write(5,"- Version du document");
		$pdf->Ln();
		$pdf->SetX(20);
		$pdf->Write(5,"- Statut du document");
		$pdf->SetY(-20);
		// Table des matieres
		//////////////////////////////////////////////
		$pdf->AddPage();
		$pdf->SetFont('Arial','BU',11);
		$pdf->SetY(32);
		$pdf->Write(5,'Table des matieres');
		$pdf->Ln(7);
		$pdf->SetFont('Arial','',10);
		$prgs_niv_0 = Laralum::tplList('niv',0);
		for($i=0;$i<count($prgs_niv_0);$i++){
			if($prgs_niv_0[$i]->id_template == $application[0]->template_id){
				$pdf->Ln(5);
				$pdf->SetX(10);
				$pdf->Write(5,str_replace("?","'",utf8_decode($prgs_niv_0[$i]->num_parag." - ".$prgs_niv_0[$i]->text)));
			}
			
			// Récupération des paragraphes de niveau 1 du template
			$prgs_niv_1 = Laralum::tplList('parent',$prgs_niv_0[$i]->id);
			for($j=0;$j<count($prgs_niv_1);$j++){
				if($prgs_niv_1[$j]->id_template == $application[0]->template_id){
					$pdf->Ln(5);
					$pdf->SetX(20);
					$pdf->Write(5,str_replace("?","'",utf8_decode($prgs_niv_1[$j]->num_parag." - ".$prgs_niv_1[$j]->text)));
				}
				
				// Récupération des paragraphes de niveau 2 du template
				$prgs_niv_2 = Laralum::tplList('parent',$prgs_niv_1[$j]->id);
				for($k=0;$k<count($prgs_niv_2);$k++){
					if($prgs_niv_2[$k]->id_template == $application[0]->template_id){
						$pdf->Ln(5);
						$pdf->SetX(30);
						$pdf->Write(5,str_replace("?","'",utf8_decode($prgs_niv_2[$k]->num_parag." - ".$prgs_niv_2[$k]->text)));
					}
				}

			}
		}
		$pdf->SetY(-20);
		// Page d'introduction
		//////////////////////////////////////////////
		$pdf->AddPage();
		$pdf->SetFont('Arial','B',18);
		$pdf->Cell(0,20,'INTRODUCTION',0,1,'C');
		$pdf->SetFont('Arial','',11);
		$pdf->Write(5,'L\'objet de ce document est de presenter l\'architecture technique et les ressources techniques de l\'application FILA-E a mettre en oeuvre et validee par les differents acteurs dans le cadre du projet. Il doit contenir la liste exhaustive des ressources materielles (serveurs,RAM,CPUs,interfaces reseaux donnees, interfaces stockage et sauvegarde) a mettre en place pour assurer le fonctionnement, la sauvegarde et le secours eventuel de l\'application');
		$pdf->Ln();
		$pdf->SetY(-20);
		$pdf->SetFont('Arial','',10);
		// Corps du document
		//////////////////////////////////////////////
		$pdf->AddPage();
		$pdf->SetY(32);

		// Récupération du contenu de l'application courante
		
		//print_r($idApp);
		//print_r($prgs_content);die;
		// Récupération des paragraphes de niveau 0 du template
		$prgs_niv_0 = Laralum::tplList('niv',0);
		for($i=0;$i<count($prgs_niv_0);$i++){
			if($prgs_niv_0[$i]->id_template == $application[0]->template_id){
				$pdf->Ln(5);
				$pdf->SetX(10);
				$pdf->SetFont("","U","");
				$pdf->Write(5,str_replace("?","'",utf8_decode($prgs_niv_0[$i]->num_parag." - ".$prgs_niv_0[$i]->text)));
				$pdf->SetFont("","","");
				$pdf->Ln(10);

				for($row=0;$row<count($prgs_content);$row++){
					
					// Contenu du paragraphe
					$original_str = $prgs_content[$row]->text_stat;
					// Si le chapitre courant correspond au chapitre de l'application
					if($prgs_content[$row]->num_parag == $prgs_niv_0[$i]->num_parag){
						$pdf->WriteHTML($original_str);
						//$pdf->Ln(5);
					}
				}
			}
			

			// Récupération des paragraphes de niveau 1 du template
			$prgs_niv_1 = Laralum::tplList('parent',$prgs_niv_0[$i]->id);
			for($j=0;$j<count($prgs_niv_1);$j++){
				if($prgs_niv_1[$j]->id_template == $application[0]->template_id){
					$pdf->Ln(5);
					$pdf->SetX(20);
					$pdf->SetFont("","U","");
					$pdf->Write(5,str_replace("?","'",utf8_decode($prgs_niv_1[$j]->num_parag." - ".$prgs_niv_1[$j]->text)));
					$pdf->SetFont("","","");
					$pdf->Ln(10);
					for($row=0;$row<count($prgs_content);$row++){
					// Contenu du paragraphe
						$original_str = $prgs_content[$row]->text_stat;
					// Si le chapitre courant correspond au chapitre de l'application
						if($prgs_content[$row]->num_parag == $prgs_niv_1[$j]->num_parag){
							$pdf->WriteHTML($original_str);
						//$pdf->Ln(5);
						}
					}
				}
				
				// Récupération des paragraphes de niveau 2 du template
				$prgs_niv_2 = Laralum::tplList('parent',$prgs_niv_1[$j]->id);
				for($k=0;$k<count($prgs_niv_2);$k++){
					if($prgs_niv_2[$k]->id_template == $application[0]->template_id){
						$pdf->Ln(5);
						$pdf->SetX(30);
						$pdf->SetFont("","U","");
						$pdf->Write(5,str_replace("?","'",utf8_decode($prgs_niv_2[$k]->num_parag." - ".$prgs_niv_2[$k]->text)));
						$pdf->SetFont("","","");
						$pdf->Ln(10);
						for($row=0;$row<count($prgs_content);$row++){
							// Contenu du paragraphe
							$original_str = $prgs_content[$row]->text_stat;
							// Si le chapitre courant correspond au chapitre de l'application
							if($prgs_content[$row]->num_parag == $prgs_niv_2[$k]->num_parag){
								$pdf->WriteHTML($original_str);
								//$pdf->Ln(5);
							}
						}
						
					}
				}
			}
		}

		$pdf->SetY(-20);
		$pdf->Output('I','pdf.pdf',false);
	}


	public function pdf_template($idApp){

		require('htmlparser.php');

		// Fichier temporaire
		$TEMPIMG = 'tempimg.png';

		// Récupération des paragraphes du template
		$application = Laralum::applications('id',$idApp);
		$templates = Laralum::templates('id_template',$application[0]->template_id);
		$intervenants = Laralum::intervenants('id_app',$idApp);
		$diffusions = Laralum::diffusion('id_app',$idApp);
		$creator = User::find($application[0]->user_id)->name;
		$prgs_content = Laralum::applicationscontent('id_app',$idApp);

		// Parametres du document
		$pdf = new FPDF($idApp);
		$pdf->AliasNbPages();
		$pdf->AddPage();
		$pdf->SetFont('Arial','B',16);
		$pdf->SetLeftMargin(10);
		$pdf->SetRightMargin(10);
		//$pdf->SetAutoPageBreak(true,2);
		// Première Page
		//////////////////////////////////////////////
		$pdf->SetY(70);
		$pdf->SetFillColor(103, 128, 159);
		$pdf->SetTextColor(255,255,255);
		$pdf->Cell(0,15,'Application '.$application[0]->name,1,1,'C',true);
		$pdf->SetTextColor(0,0,0);
		$pdf->SetY(120);
		$pdf->SetFontSize(28);
		$pdf->Cell(0,15,'Dossier d\'architecture Hebergement (DAH)',0,1,'C');
		$pdf->SetFontSize(14);
		$pdf->SetY(150);
		$pdf->SetFont('Arial','',16);
		$pdf->Cell(80,7,'Ecolience','LTR',0,'R');
		$pdf->Cell(100,7,$application[0]->ecolience,'TR',1,'L');
		$pdf->Cell(80,7,'Nom','LR',0,'R');
		$pdf->Cell(100,7,$application[0]->name,'R',1,'L');
		$pdf->Cell(80,7,'Trigramme','LR',0,'R');
		$pdf->Cell(100,7,$application[0]->trigramme,'R',1,'L');
		$pdf->Cell(80,7,'Criticite STAMP','LR',0,'R');
		$pdf->Cell(100,7,$application[0]->criticite_stamp,'R',1,'L');
		$pdf->Cell(80,7,'Sensible Groupe','LR',0,'R');
		$pdf->Cell(100,7, ($application[0]->sensible_groupe == 1)?'OUI':'NON','R',1,'L');
		$pdf->Cell(80,7,'Niveau sensibilite a la fraude','LBR',0,'R');
		$pdf->Cell(100,7,$application[0]->niv_sensible_fraude,'BR',1,'L');
		$pdf->Cell(80,7,'Demande Client','LBR',0,'R');
		$pdf->SetFont('Arial','',14);
		$pdf->Cell(100,7,'Fichier : EBQ "FLA-EBQ.xlsx" - 05/09/2016','BR',1,'L');
		$pdf->Ln();
		$pdf->Ln();
		$pdf->SetFont('Arial','B',20);
		$pdf->Cell(0,20,'Version : 1.1',0,1,'C');
		$pdf->Cell(0,20,'Statut : '.$application[0]->statu,0,1,'C');
		$pdf->SetFont('Arial','',10);
		$pdf->SetY(-20);
		// Deuxième Page
		//////////////////////////////////////////////
		$pdf->AddPage();
		$pdf->SetY(32);
		$pdf->SetFont('Arial','BU',12);
		$pdf->Cell(0,10,'FICHE DE CONTROLE DU DOCUMENT',0,1,'C');
		$pdf->SetFont('Arial','B',11);
		$pdf->Write(5,'Caracteristiques du document');
		$pdf->Ln(6);
		$pdf->SetFont('Arial','B',10);
		$pdf->Cell(40,5,'Statut','LTRB',0,'L');
		$pdf->SetFont('Arial','',10);
		$pdf->Cell(150,5,$application[0]->statu,'BTR',1,'L');
		$pdf->SetFont('Arial','B',10);
		$pdf->Cell(40,5,'Ref. fichier','LBR',0,'L');
		$pdf->SetFont('Arial','',10);
		$pdf->Cell(150,5,'DAH application FLA','BR',1,'L');
		$pdf->Ln();  
		$pdf->SetFont('Arial','B',11);
		$pdf->Write(5,'Creation et suivi du document');
		$pdf->Ln(6);
		$pdf->SetFont('Arial','B',10);
		$pdf->Cell(20,5,'Version','LTRB',0,'L');
		$pdf->Cell(25,5,'Cree le','LTRB',0,'L');
		$pdf->Cell(45,5,'Auteur','LTRB',0,'L');
		$pdf->Cell(100,5,'Commentaires','LTRB',1,'L');
		$pdf->SetFont('Arial','',10);
		$pdf->Cell(20,5,'1.0','LTRB',0,'L');
		$date = explode(" ",$application[0]->created_at);
		$pdf->Cell(25,5,$date[0],'LTRB',0,'L');
		$pdf->Cell(45,5,User::find($application[0]->user_id)->name,'LTRB',0,'L');
		$pdf->Cell(100,5,'Statut : '.$application[0]->statu,'LTRB',1,'L');
		$pdf->Ln();
		$pdf->SetFont('Arial','B',11);
		$pdf->Write(5,'Intervenants sur le projet');
		$pdf->Ln(6);
		$pdf->SetFont('Arial','B',10);
		$pdf->Cell(40,5,'Entite/Service','LTRB',0,'L');
		$pdf->Cell(80,5,'Domaine de responsabilite','LTRB',0,'L');
		$pdf->Cell(70,5,'Nom de l\'intervenant','LTRB',1,'L');
		$pdf->SetFont('Arial','',10);
		// boucle pour integrer les intervenants
		foreach($intervenants as $interv){
			$pdf->Cell(40,5,$interv->entite,'LTRB',0,'L');
			$pdf->Cell(80,5,$interv->resp_domain,'LTRB',0,'L');
			$pdf->Cell(70,5,$interv->nom,'LTRB',1,'L');	
		}
		$pdf->Ln();
		$pdf->SetFont('Arial','B',11);
		$pdf->Write(5,'Liste de diffusion');
		$pdf->Ln(6);	
		$pdf->SetFont('Arial','B',10);
		$pdf->Cell(60,5,'Entite','LTRB',0,'L');
		$pdf->Cell(100,5,'Nom des destinaires','LTRB',0,'L');
		$pdf->Cell(30,5,'Objet','LTRB',1,'L');
		$pdf->SetFont('Arial','',10);
		// boucle pour integrer la liste de diffusion
		foreach($diffusions as $diff){
			$pdf->Cell(60,5,$diff->entite,'LTRB',0,'L');
			$pdf->Cell(100,5,$diff->nom,'LTRB',0,'L');
			$pdf->Cell(30,5,$diff->objet,'LTRB',1,'L');
		}
		$pdf->SetY(-20);
		// Fiche de Synthese
		//////////////////////////////////////////////
		$pdf->AddPage();
		$pdf->Ln(5);
		$pdf->Write(5,'FICHE SYNTHESE');
		$pdf->Ln(5);
		$pdf->Cell(60,5,'IRT/ Trigramme(s)','LTR',0,'R');
		$pdf->Cell(130,5,'AAAA/XYZ','LTR',1,'L');
		$pdf->Cell(60,5,'Application(s)','LBR',0,'R');
		$pdf->Cell(130,5,'Nom Application','LBR',1,'L');
		$pdf->Cell(60,5,'Code Ecolience',1,0,'R');
		$pdf->Cell(130,5,'',1,1,'L');
		$pdf->Cell(60,5,'Progiciel(s)',1,0,'R');
		$pdf->Cell(130,5,'Nom(s) + release utilisee par l\'application',1,1,'L');
		$pdf->Cell(60,5,'Typologie Architecture','LTR',0,'R');
		$pdf->Cell(130,5,'Web Transactionnel C1 ou non standard','LTR',1,'L');
		$pdf->Cell(60,5,'','LBR',0,'R');
		$pdf->Cell(130,5,'Web Decisionnel D1,D2 ou on standard','LBR',1,'L');
		$y = $pdf->GetY();
		$pdf->MultiCell(60,5,"Preconisation GTS non retenues par la ME\n\n\n\n",'LTR','R');
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(130,5,"Statut : rediger la vision synthetique de l'architecte\nLister les preconisations non retenues de maniere synthetique\n1. ddd\n2. aaa\nLes points sont detailles dans le § '1.2 vision architecture'",'LBR','L');
		$pdf->Cell(190,7,"Description de l'Architecture de production",1,1,'L');
		$y = $pdf->GetY();
		$pdf->MultiCell(60,5,"Site primaire d'hebergement",1,'R');
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(130,5,"Tigery / Marcoussis DC02 / Seclin2 / Seclin1 Jules Verne - St Exupery / Valmy",1,'L');
		$pdf->Cell(60,5,"Site secondaire",1,0,'R');
		$pdf->MultiCell(130,5,"Seclin2 / Marcoussis DC02",1,'L');
		$y = $pdf->GetY();
		$pdf->MultiCell(60,5,"Modele d'architecture de resilience\n\n\n\n\n\n\n",1,'R');
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(130,5,"1+0:A\n1+0:HA\n1+1:A+A\n1+1:A+Hot Standby\n1+1:A+Hot Standby croise\n1+1:A+Cold Standby\n1+1:HA+Cold Standby",1,'L');
		$y = $pdf->GetY();
		$pdf->MultiCell(60,5,"Modele de solution de resilience de l'ecolience\n",1,'R');
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(130,5,"Bronze,Argent,Or,Saphir,Rubis,Emeraude\nObjectif de delai de retablissement GTS(panne) : 0h,4h,8h,24h",1,'L');
		$y = $pdf->GetY();
		$pdf->MultiCell(60,5,"Modele d'exercice entre deux sites distants atteignable\n\n",1,'R');
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(130,5,"Exercice unitaire hors charge (validation technique)\nExercice hors charge de l'ecolience\nExercice pleine charge de l'ecolience",1,'L');
		$y = $pdf->GetY();
		$pdf->MultiCell(60,5,"Couche metiers\n\n\n\n",1,'R');
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(130,5,"Pour les couches/services ci-dessous, preciser en gras les composants techniques associes a des fonctions applicatives vitales/critiques (par opposition aux fonctions non prioritaires ou secondaires) -> impact direct sur le processus de prise en charge des incidents",1,'L');
		$y = $pdf->GetY();
		$pdf->MultiCell(60,5,"Services d'echanges\n\n\n\n",1,'R');
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(90,5,"WMQ R.m\nConnect:eXpress R.m\nSMTP\n\n",1,'L');
		$pdf->SetY($y);
		$pdf->SetX(160);
		$pdf->MultiCell(40,5,"Ajout\nMise a jour\nRetrait\nReconduit",1,'L');
		$y = $pdf->GetY();
		$pdf->MultiCell(60,5,"Services d'application\n\n\n\n\n",1,'R');
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(90,5,"WebLogic xxRxx et sdk 1.5\nInformation\nTOMCAT\nLa matrice de compatibilite impose une version < a ...\nSi connu, indiquer le niveau de durcissement requis",1,'L');
		$pdf->SetY($y);
		$pdf->SetX(160);
		$pdf->MultiCell(40,5,"...\n\n\n\n\n",1,'L');
		$y = $pdf->GetY();
		$pdf->MultiCell(60,5,"Services Donnes\n\n\n\n\n",1,'R');
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(90,5,"Oracle ww.x.y.z\nIBM DB2 w.x\nMicrosoft SQL Server xxx\nLa matrice de compatibilite impose une version < a ...\nSi connu, indiquer le niveau de durcissement requis",1,'L');
		$pdf->SetY($y);
		$pdf->SetX(160);
		$pdf->MultiCell(40,5,"...\n\n\n\n\n",1,'L');
		$y = $pdf->GetY();
		$pdf->MultiCell(60,5,"Services Ordonnancement",1,'R');
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(90,5,"Control M",1,'L');
		$pdf->SetY($y);
		$pdf->SetX(160);
		$pdf->MultiCell(40,5,"...",1,'L');
		$pdf->SetY(-20);
		$pdf->AddPage();
		$pdf->Ln(5);
		$y = $pdf->GetY();
		$pdf->MultiCell(60,5,"Zone Cellules Securite Reseau (CSR)",1,'R');
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(90,5,"CITSv2,L3,BSC Mutualise,PCMS,CAZA,TNU,GMS,PGN,PEPSY,MAIA",1,'L');
		$pdf->SetY($y);
		$pdf->SetX(160);
		$pdf->MultiCell(40,5,"...\n\n",1,'L');
		$y = $pdf->GetY();
		$pdf->MultiCell(60,5,"Systemes d'exploitation\n\n\n\n",1,'R');
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(90,5,"Linux Red Hat 6.6\nWindows 2012 SPxx\nAIX 6.1 TL3\nLa matrice de comptatibilite impose une version < a ...",1,'L');
		$pdf->SetY($y);
		$pdf->SetX(160);
		$pdf->MultiCell(40,5,"...\n\n\n\n",1,'L');
		$y = $pdf->GetY();
		$pdf->MultiCell(60,5,"Classe de resilience du stockage\n\n",1,'R');
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(90,5,"SAN: M0,M1,L0,L1 + id du groupe de coherence\n\n",1,'L');
		$pdf->SetY($y);
		$pdf->SetX(160);
		$pdf->MultiCell(40,5,"...\n\n",1,'L');
		$y = $pdf->GetY();
		$pdf->MultiCell(60,5,"Conformite standard et politique\n\n\n\n",1,'R');
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(90,5,"Durcissement OS:\nAdvenced\nPremium\nPremium+",1,'L');
		$pdf->SetY($y);
		$pdf->SetX(160);
		$pdf->MultiCell(40,5,"...\n\n\n\n",1,'L');
		$y = $pdf->GetY();
		$pdf->MultiCell(60,5,"Features hors socle a installer\n\n\n\n",1,'R');
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(90,5,"Features a installer hors socle ou ce qui est obligatoire\nJVM Oracle dans la couche DB\nOpenSSH\n\n",1,'L');
		$pdf->SetY($y);
		$pdf->SetX(160);
		$pdf->MultiCell(40,5,"...\n\n\n\n",1,'L');
		$y = $pdf->GetY();
		$pdf->MultiCell(60,5,"Ressources Techniques\n\n\n\n\n",1,'R');
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(130,5,"3 chois possibles :\n-Indiquer les paragraphes correspondants par environnement\n-Mettre ici le tableau récapitulatif tout environnement\n-ou en litteraire",1,'L');
		$y = $pdf->GetY();
		$pdf->MultiCell(60,5,"Offres GTS\n\n\n",1,'R');
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(90,5,"RET : OMLX, SQM, OMDG\nTFO : SIPO [Exotique],etc\nEUS : @PAC,...",1,'L');
		$pdf->SetY($y);
		$pdf->SetX(160);
		$pdf->MultiCell(40,5,"...\n\n\n",1,'L');
		$y = $pdf->GetY();
		$pdf->MultiCell(60,5,"Servitudes\n\n\n",1,'R');
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(90,5,"Sauvegarde Standard TSM ou Lan Free Backup ou specifique (ex : Networker sur Valmy)\nSupervision standard Patrol",1,'L');
		$pdf->SetY($y);
		$pdf->SetX(160);
		$pdf->MultiCell(40,5,"...\n\n\n",1,'L');
		$y = $pdf->GetY();
		$pdf->MultiCell(60,5,"Ressources reseaux\n",1,'R');
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(90,5,"x lien 100 Mb | 1 Gb | 10Gb",1,'L');
		$pdf->SetY($y);
		$pdf->SetX(160);
		$pdf->MultiCell(40,5,"...\n",1,'L');
		$y = $pdf->GetY();
		$pdf->MultiCell(60,5,"Poste de travail\n\n",1,'R');
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(90,5,"Client lourd ou client web NDG ARPEGE IE8\nInternational oui/non",1,'L');
		$pdf->SetY($y);
		$pdf->SetX(160);
		$pdf->MultiCell(40,5,"...\n\n",1,'L');
		$y = $pdf->GetY();
		$pdf->MultiCell(60,5,"Service d'acces\n",1,'R');
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(90,5,"CITRIX,PAX,TRAP,I2BD,GAIA VPN,LS",1,'L');
		$pdf->SetY($y);
		$pdf->SetX(160);
		$pdf->MultiCell(40,5,"...\n",1,'L');
		$y = $pdf->GetY();
		$pdf->MultiCell(60,5,"Processus de livraison des packages applicatifs en production\n",1,'R');
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(90,5,"Earth CDI\nNon standard (scp,client lourd,etc)",1,'L');
		$pdf->SetY($y);
		$pdf->SetX(160);
		$pdf->MultiCell(40,5,"...\n\n",1,'L');
		$y = $pdf->GetY();
		$pdf->MultiCell(60,5,"Principaux ecarts par rapport a la strategie ou aux exigences GTS\n\n\n\n\n\n\n\n\n",1,'R');
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(105,5,"Domaine\n\n",1,'L');
		$pdf->SetY($y);
		$pdf->SetX(175);
		$pdf->MultiCell(25,5,"Ecart ? oui/non\n",1,'L');
		$y = $pdf->GetY();
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(105,5,"Securite",1,'L');
		$pdf->SetY($y);
		$pdf->SetX(175);
		$pdf->MultiCell(25,5,"",1,'L');
		$y = $pdf->GetY();
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(105,5,"Virtualisation comme 1er choix de hosting",1,'L');
		$pdf->SetY($y);
		$pdf->SetX(175);
		$pdf->MultiCell(25,5,"",1,'L');
		$y = $pdf->GetY();
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(105,5,"CITSv2 / L3",1,'L');
		$pdf->SetY($y);
		$pdf->SetX(175);
		$pdf->MultiCell(25,5,"",1,'L');
		$y = $pdf->GetY();
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(105,5,"Capacite a realiser des exercices pleine charge <-> ecosysteme de donnees et de flux definis et valides",1,'L');
		$pdf->SetY($y);
		$pdf->SetX(175);
		$pdf->MultiCell(25,5,"\n\n",1,'L');
		$y = $pdf->GetY();
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(105,5,"RedCat",1,'L');
		$pdf->SetY($y);
		$pdf->SetX(175);
		$pdf->MultiCell(25,5,"",1,'L');
		$y = $pdf->GetY();
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(105,5,"Stategie DataCenter",1,'L');
		$pdf->SetY($y);
		$pdf->SetX(175);
		$pdf->MultiCell(25,5,"",1,'L');
		$y = $pdf->GetY();
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(105,5,"Processus de livraison standard",1,'L');
		$pdf->SetY($y);
		$pdf->SetX(175);
		$pdf->MultiCell(25,5,"",1,'L');
		$pdf->SetY(-20);
		$pdf->AddPage();
		$pdf->Ln(5);
		$y = $pdf->GetY();
		$pdf->MultiCell(60,5,"Principaux ecarts par rapport aux besoins exprimes\n\n\n\n\n",1,'R');
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(130,5,"synthese : xxxxx\n\nLister les ecarts de manière synthetique\n1. Ecart 1: Domaine/description synthetique\n2. ex SLA de disponibilite\n3. ex : couverture de risques",1,'L');
		$y = $pdf->GetY();
		$pdf->MultiCell(60,5,"Synthese de l'avis Securite",1,'R');
		$pdf->SetY($y);
		$pdf->SetX(70);
		$pdf->MultiCell(130,5,"Rappeler le niveau d'ISR indique en cartouche (page de garde)",1,'L');
		$pdf->Ln(10);
		$pdf->Write(5,"Dans le paragraphe 1.2.2, le recapitulatif des besoins declines par offre et par environnement et par site");
		$pdf->Ln(10);
		$pdf->Cell(190,5,"JALON DU PLANNING",1,1,'C');

		$pdf->Cell(60,5,"CVT-I",1,0,'C');
		$pdf->Cell(60,5,"XX/XX/XXXX",1,0,'C');
		$pdf->Cell(70,5,"N/A",1,1,'L');
		$pdf->Cell(60,5,"CVT-Q / QA",1,0,'C');
		$pdf->Cell(60,5,"XX/XX/XXXX",1,0,'C');
		$pdf->Cell(70,5,"",1,1,'L');
		$pdf->Cell(60,5,"CVT-X",1,0,'C');
		$pdf->Cell(60,5,"XX/XX/XXXX",1,0,'C');
		$pdf->Cell(70,5,"",1,1,'L');
		$pdf->Cell(60,5,"Installation en developpement",1,0,'C');
		$pdf->Cell(60,5,"XX/XX/XXXX",1,0,'C');
		$pdf->Cell(70,5,"",1,1,'L');
		$pdf->Cell(60,5,"Mise en homologation-X",1,0,'C');
		$pdf->Cell(60,5,"XX/XX/XXXX",1,0,'C');
		$pdf->Cell(70,5,"",1,1,'L');
		$pdf->Cell(60,5,"Mise en production",1,0,'C');
		$pdf->Cell(60,5,"XX/XX/XXXX",1,0,'C');
		$pdf->Cell(70,5,"",1,1,'L');
		$pdf->Ln(10);
		$pdf->Write(5,"- Tous les acronymes sont recenses dans le 8.5 Glossaire");
		$pdf->Ln();
		$pdf->Write(5,"- Ce document presente le plan type du Dossier d'Architecture Hebergement (DAH) dont la structure et le contenu sont sous la responsabilite de GTS/RET/APS");
		$pdf->Ln();
		$pdf->Write(5,"- Ce DAH (oriente infrastructure) est le document resultant du DAA en entree (orientation metier). Le contenu du DAA est sous la responsabilite de la maitre d'oeuvre du projet");
		$pdf->Ln(10);
		$pdf->Write(5,"Workflow simplifie du DAH");
		$pdf->Ln(50);
		$pdf->Write(5,"- Le processus global de l'etude GTS d'architecture est decrit dans le document 'HAO : Hosting Architecture Offer v1.0' que l'on peut trouver sur ce site (document 'processus d'elaboration d'Architecture Technique')");
		$pdf->Ln();
		$pdf->Write(5,"Les caracteristiques ci-dessous du document sont a renseigner dans les 'prorietes' du document (onglet 'Resume') :");
		$pdf->Ln();
		$pdf->SetX(20);
		$pdf->Write(5,"- Nom du projet");
		$pdf->Ln();
		$pdf->SetX(20);
		$pdf->Write(5,"- Sous titre");
		$pdf->Ln();
		$pdf->SetX(30);
		$pdf->Write(5,"- Objet(Nom application)");
		$pdf->Ln();
		$pdf->SetX(30);
		$pdf->Write(5,"- Categorie ( Nom de l'ecosysteme d'hebergmeent )");
		$pdf->Ln();
		$pdf->SetX(20);
		$pdf->Write(5,"- Version du document");
		$pdf->Ln();
		$pdf->SetX(20);
		$pdf->Write(5,"- Statut du document");
		$pdf->SetY(-20);
		// Table des matieres
		//////////////////////////////////////////////
		$pdf->AddPage();
		$pdf->SetFont('Arial','BU',11);
		$pdf->SetY(32);
		$pdf->Write(5,'Table des matieres');
		$pdf->Ln(7);
		$pdf->SetFont('Arial','',10);
		$prgs_niv_0 = Laralum::tplList('niv',0);
		for($i=0;$i<count($prgs_niv_0);$i++){
			if($prgs_niv_0[$i]->id_template == $application[0]->template_id){
				$pdf->Ln(5);
				$pdf->SetX(10);
				$pdf->Write(5,str_replace("?","'",utf8_decode($prgs_niv_0[$i]->num_parag." - ".$prgs_niv_0[$i]->text)));
			}
			
			// Récupération des paragraphes de niveau 1 du template
			$prgs_niv_1 = Laralum::tplList('parent',$prgs_niv_0[$i]->id);
			for($j=0;$j<count($prgs_niv_1);$j++){
				if($prgs_niv_1[$j]->id_template == $application[0]->template_id){
					$pdf->Ln(5);
					$pdf->SetX(20);
					$pdf->Write(5,str_replace("?","'",utf8_decode($prgs_niv_1[$j]->num_parag." - ".$prgs_niv_1[$j]->text)));
				}
				
				// Récupération des paragraphes de niveau 2 du template
				$prgs_niv_2 = Laralum::tplList('parent',$prgs_niv_1[$j]->id);
				for($k=0;$k<count($prgs_niv_2);$k++){
					if($prgs_niv_2[$k]->id_template == $application[0]->template_id){
						$pdf->Ln(5);
						$pdf->SetX(30);
						$pdf->Write(5,str_replace("?","'",utf8_decode($prgs_niv_2[$k]->num_parag." - ".$prgs_niv_2[$k]->text)));
					}
				}

			}
		}
		$pdf->SetY(-20);
		// Page d'introduction
		//////////////////////////////////////////////
		$pdf->AddPage();
		$pdf->SetFont('Arial','B',18);
		$pdf->Cell(0,20,'INTRODUCTION',0,1,'C');
		$pdf->SetFont('Arial','',11);
		$pdf->Write(5,'L\'objet de ce document est de presenter l\'architecture technique et les ressources techniques de l\'application FILA-E a mettre en oeuvre et validee par les differents acteurs dans le cadre du projet. Il doit contenir la liste exhaustive des ressources materielles (serveurs,RAM,CPUs,interfaces reseaux donnees, interfaces stockage et sauvegarde) a mettre en place pour assurer le fonctionnement, la sauvegarde et le secours eventuel de l\'application');
		$pdf->Ln();
		$pdf->SetY(-20);
		$pdf->SetFont('Arial','',10);
		// Corps du document
		//////////////////////////////////////////////
		$pdf->AddPage();
		$pdf->SetY(32);

		// Récupération du contenu de l'application courante
		
		//print_r($idApp);
		//print_r($prgs_content);die;
		// Récupération des paragraphes de niveau 0 du template
		$prgs_niv_0 = Laralum::tplList('niv',0);
		for($i=0;$i<count($prgs_niv_0);$i++){
			if($prgs_niv_0[$i]->id_template == $application[0]->template_id){
				$pdf->Ln(5);
				$pdf->SetX(10);
				$pdf->SetFont("","U","");
				$pdf->Write(5,str_replace("?","'",utf8_decode($prgs_niv_0[$i]->num_parag." - ".$prgs_niv_0[$i]->text)));
				$pdf->SetFont("","","");
				$pdf->Ln(10);

				for($row=0;$row<count($prgs_content);$row++){
					
					// Contenu du paragraphe
					$original_str = $prgs_content[$row]->text_stat;
					// Si le chapitre courant correspond au chapitre de l'application
					if($prgs_content[$row]->num_parag == $prgs_niv_0[$i]->num_parag){
						$pdf->WriteHTML($original_str);
						//$pdf->Ln(5);
					}
				}
			}
			

			// Récupération des paragraphes de niveau 1 du template
			$prgs_niv_1 = Laralum::tplList('parent',$prgs_niv_0[$i]->id);
			for($j=0;$j<count($prgs_niv_1);$j++){
				if($prgs_niv_1[$j]->id_template == $application[0]->template_id){
					$pdf->Ln(5);
					$pdf->SetX(20);
					$pdf->SetFont("","U","");
					$pdf->Write(5,str_replace("?","'",utf8_decode($prgs_niv_1[$j]->num_parag." - ".$prgs_niv_1[$j]->text)));
					$pdf->SetFont("","","");
					$pdf->Ln(10);
					for($row=0;$row<count($prgs_content);$row++){
					// Contenu du paragraphe
						$original_str = $prgs_content[$row]->text_stat;
					// Si le chapitre courant correspond au chapitre de l'application
						if($prgs_content[$row]->num_parag == $prgs_niv_1[$j]->num_parag){
							$pdf->WriteHTML($original_str);
						//$pdf->Ln(5);
						}
					}
				}
				
				// Récupération des paragraphes de niveau 2 du template
				$prgs_niv_2 = Laralum::tplList('parent',$prgs_niv_1[$j]->id);
				for($k=0;$k<count($prgs_niv_2);$k++){
					if($prgs_niv_2[$k]->id_template == $application[0]->template_id){
						$pdf->Ln(5);
						$pdf->SetX(30);
						$pdf->SetFont("","U","");
						$pdf->Write(5,str_replace("?","'",utf8_decode($prgs_niv_2[$k]->num_parag." - ".$prgs_niv_2[$k]->text)));
						$pdf->SetFont("","","");
						$pdf->Ln(10);
						for($row=0;$row<count($prgs_content);$row++){
							// Contenu du paragraphe
							$original_str = $prgs_content[$row]->text_stat;
							// Si le chapitre courant correspond au chapitre de l'application
							if($prgs_content[$row]->num_parag == $prgs_niv_2[$k]->num_parag){
								$pdf->WriteHTML($original_str);
								//$pdf->Ln(5);
							}
						}
						
					}
				}
			}
		}

		$pdf->SetY(-20);
		$pdf->Output('I','pdf.pdf',false);
	}

    public function pdf_Version_Hist($idApp, $version){

        require('htmlparser.php');

        // Fichier temporaire
        $TEMPIMG = 'tempimg.png';

        // Récupération des paragraphes du template
        $application = Laralum::applications('id',$idApp);
        $templates = Laralum::templates('id_template',$application[0]->template_id);
        $intervenants = Laralum::intervenants('id_app',$idApp);
        $diffusions = Laralum::diffusion('id_app',$idApp);
        $creator = User::find($application[0]->user_id)->name;
        $prgs_content = AppsVersionHistory::where('id_app', $idApp)->where('version', $version)->get();

        // Parametres du document
        $pdf = new FPDF($idApp);
        $pdf->AliasNbPages();
        $pdf->AddPage();
        $pdf->SetFont('Arial','B',16);
        $pdf->SetLeftMargin(10);
        $pdf->SetRightMargin(10);
        //$pdf->SetAutoPageBreak(true,2);
        // Première Page
        //////////////////////////////////////////////
        $pdf->SetY(70);
        $pdf->SetFillColor(103, 128, 159);
        $pdf->SetTextColor(255,255,255);
        $pdf->Cell(0,15,'Application '.$application[0]->name,1,1,'C',true);
        $pdf->SetTextColor(0,0,0);
        $pdf->SetY(120);
        $pdf->SetFontSize(28);
        $pdf->Cell(0,15,'Dossier d\'architecture Hebergement (DAH)',0,1,'C');
        $pdf->SetFontSize(14);
        $pdf->SetY(150);
        $pdf->SetFont('Arial','',16);
        $pdf->Cell(80,7,'Ecolience','LTR',0,'R');
        $pdf->Cell(100,7,$application[0]->ecolience,'TR',1,'L');
        $pdf->Cell(80,7,'Nom','LR',0,'R');
        $pdf->Cell(100,7,$application[0]->name,'R',1,'L');
        $pdf->Cell(80,7,'Trigramme','LR',0,'R');
        $pdf->Cell(100,7,$application[0]->trigramme,'R',1,'L');
        $pdf->Cell(80,7,'Criticite STAMP','LR',0,'R');
        $pdf->Cell(100,7,$application[0]->criticite_stamp,'R',1,'L');
        $pdf->Cell(80,7,'Sensible Groupe','LR',0,'R');
        $pdf->Cell(100,7, ($application[0]->sensible_groupe == 1)?'OUI':'NON','R',1,'L');
        $pdf->Cell(80,7,'Niveau sensibilite a la fraude','LBR',0,'R');
        $pdf->Cell(100,7,$application[0]->niv_sensible_fraude,'BR',1,'L');
        $pdf->Cell(80,7,'Demande Client','LBR',0,'R');
        $pdf->SetFont('Arial','',14);
        $pdf->Cell(100,7,'Fichier : EBQ "FLA-EBQ.xlsx" - 05/09/2016','BR',1,'L');
        $pdf->Ln();
        $pdf->Ln();
        $pdf->SetFont('Arial','B',20);
        $pdf->Cell(0,20,'Version : 1.1',0,1,'C');
        $pdf->Cell(0,20,'Statut : '.$application[0]->statu,0,1,'C');
        $pdf->SetFont('Arial','',10);
        $pdf->SetY(-20);
        // Deuxième Page
        //////////////////////////////////////////////
        $pdf->AddPage();
        $pdf->SetY(32);
        $pdf->SetFont('Arial','BU',12);
        $pdf->Cell(0,10,'FICHE DE CONTROLE DU DOCUMENT',0,1,'C');
        $pdf->SetFont('Arial','B',11);
        $pdf->Write(5,'Caracteristiques du document');
        $pdf->Ln(6);
        $pdf->SetFont('Arial','B',10);
        $pdf->Cell(40,5,'Statut','LTRB',0,'L');
        $pdf->SetFont('Arial','',10);
        $pdf->Cell(150,5,$application[0]->statu,'BTR',1,'L');
        $pdf->SetFont('Arial','B',10);
        $pdf->Cell(40,5,'Ref. fichier','LBR',0,'L');
        $pdf->SetFont('Arial','',10);
        $pdf->Cell(150,5,'DAH application FLA','BR',1,'L');
        $pdf->Ln();
        $pdf->SetFont('Arial','B',11);
        $pdf->Write(5,'Creation et suivi du document');
        $pdf->Ln(6);
        $pdf->SetFont('Arial','B',10);
        $pdf->Cell(20,5,'Version','LTRB',0,'L');
        $pdf->Cell(25,5,'Cree le','LTRB',0,'L');
        $pdf->Cell(45,5,'Auteur','LTRB',0,'L');
        $pdf->Cell(100,5,'Commentaires','LTRB',1,'L');
        $pdf->SetFont('Arial','',10);
        $pdf->Cell(20,5,'1.0','LTRB',0,'L');
        $date = explode(" ",$application[0]->created_at);
        $pdf->Cell(25,5,$date[0],'LTRB',0,'L');
        $pdf->Cell(45,5,User::find($application[0]->user_id)->name,'LTRB',0,'L');
        $pdf->Cell(100,5,'Statut : '.$application[0]->statu,'LTRB',1,'L');
        $pdf->Ln();
        $pdf->SetFont('Arial','B',11);
        $pdf->Write(5,'Intervenants sur le projet');
        $pdf->Ln(6);
        $pdf->SetFont('Arial','B',10);
        $pdf->Cell(40,5,'Entite/Service','LTRB',0,'L');
        $pdf->Cell(80,5,'Domaine de responsabilite','LTRB',0,'L');
        $pdf->Cell(70,5,'Nom de l\'intervenant','LTRB',1,'L');
        $pdf->SetFont('Arial','',10);
        // boucle pour integrer les intervenants
        foreach($intervenants as $interv){
            $pdf->Cell(40,5,$interv->entite,'LTRB',0,'L');
            $pdf->Cell(80,5,$interv->resp_domain,'LTRB',0,'L');
            $pdf->Cell(70,5,$interv->nom,'LTRB',1,'L');
        }
        $pdf->Ln();
        $pdf->SetFont('Arial','B',11);
        $pdf->Write(5,'Liste de diffusion');
        $pdf->Ln(6);
        $pdf->SetFont('Arial','B',10);
        $pdf->Cell(60,5,'Entite','LTRB',0,'L');
        $pdf->Cell(100,5,'Nom des destinaires','LTRB',0,'L');
        $pdf->Cell(30,5,'Objet','LTRB',1,'L');
        $pdf->SetFont('Arial','',10);
        // boucle pour integrer la liste de diffusion
        foreach($diffusions as $diff){
            $pdf->Cell(60,5,$diff->entite,'LTRB',0,'L');
            $pdf->Cell(100,5,$diff->nom,'LTRB',0,'L');
            $pdf->Cell(30,5,$diff->objet,'LTRB',1,'L');
        }
        $pdf->SetY(-20);
        // Fiche de Synthese
        //////////////////////////////////////////////
        $pdf->AddPage();
        $pdf->Ln(5);
        $pdf->Write(5,'FICHE SYNTHESE');
        $pdf->Ln(5);
        $pdf->Cell(60,5,'IRT/ Trigramme(s)','LTR',0,'R');
        $pdf->Cell(130,5,'AAAA/XYZ','LTR',1,'L');
        $pdf->Cell(60,5,'Application(s)','LBR',0,'R');
        $pdf->Cell(130,5,'Nom Application','LBR',1,'L');
        $pdf->Cell(60,5,'Code Ecolience',1,0,'R');
        $pdf->Cell(130,5,'',1,1,'L');
        $pdf->Cell(60,5,'Progiciel(s)',1,0,'R');
        $pdf->Cell(130,5,'Nom(s) + release utilisee par l\'application',1,1,'L');
        $pdf->Cell(60,5,'Typologie Architecture','LTR',0,'R');
        $pdf->Cell(130,5,'Web Transactionnel C1 ou non standard','LTR',1,'L');
        $pdf->Cell(60,5,'','LBR',0,'R');
        $pdf->Cell(130,5,'Web Decisionnel D1,D2 ou on standard','LBR',1,'L');
        $y = $pdf->GetY();
        $pdf->MultiCell(60,5,"Preconisation GTS non retenues par la ME\n\n\n\n",'LTR','R');
        $pdf->SetY($y);
        $pdf->SetX(70);
        $pdf->MultiCell(130,5,"Statut : rediger la vision synthetique de l'architecte\nLister les preconisations non retenues de maniere synthetique\n1. ddd\n2. aaa\nLes points sont detailles dans le § '1.2 vision architecture'",'LBR','L');
        $pdf->Cell(190,7,"Description de l'Architecture de production",1,1,'L');
        $y = $pdf->GetY();
        $pdf->MultiCell(60,5,"Site primaire d'hebergement",1,'R');
        $pdf->SetY($y);
        $pdf->SetX(70);
        $pdf->MultiCell(130,5,"Tigery / Marcoussis DC02 / Seclin2 / Seclin1 Jules Verne - St Exupery / Valmy",1,'L');
        $pdf->Cell(60,5,"Site secondaire",1,0,'R');
        $pdf->MultiCell(130,5,"Seclin2 / Marcoussis DC02",1,'L');
        $y = $pdf->GetY();
        $pdf->MultiCell(60,5,"Modele d'architecture de resilience\n\n\n\n\n\n\n",1,'R');
        $pdf->SetY($y);
        $pdf->SetX(70);
        $pdf->MultiCell(130,5,"1+0:A\n1+0:HA\n1+1:A+A\n1+1:A+Hot Standby\n1+1:A+Hot Standby croise\n1+1:A+Cold Standby\n1+1:HA+Cold Standby",1,'L');
        $y = $pdf->GetY();
        $pdf->MultiCell(60,5,"Modele de solution de resilience de l'ecolience\n",1,'R');
        $pdf->SetY($y);
        $pdf->SetX(70);
        $pdf->MultiCell(130,5,"Bronze,Argent,Or,Saphir,Rubis,Emeraude\nObjectif de delai de retablissement GTS(panne) : 0h,4h,8h,24h",1,'L');
        $y = $pdf->GetY();
        $pdf->MultiCell(60,5,"Modele d'exercice entre deux sites distants atteignable\n\n",1,'R');
        $pdf->SetY($y);
        $pdf->SetX(70);
        $pdf->MultiCell(130,5,"Exercice unitaire hors charge (validation technique)\nExercice hors charge de l'ecolience\nExercice pleine charge de l'ecolience",1,'L');
        $y = $pdf->GetY();
        $pdf->MultiCell(60,5,"Couche metiers\n\n\n\n",1,'R');
        $pdf->SetY($y);
        $pdf->SetX(70);
        $pdf->MultiCell(130,5,"Pour les couches/services ci-dessous, preciser en gras les composants techniques associes a des fonctions applicatives vitales/critiques (par opposition aux fonctions non prioritaires ou secondaires) -> impact direct sur le processus de prise en charge des incidents",1,'L');
        $y = $pdf->GetY();
        $pdf->MultiCell(60,5,"Services d'echanges\n\n\n\n",1,'R');
        $pdf->SetY($y);
        $pdf->SetX(70);
        $pdf->MultiCell(90,5,"WMQ R.m\nConnect:eXpress R.m\nSMTP\n\n",1,'L');
        $pdf->SetY($y);
        $pdf->SetX(160);
        $pdf->MultiCell(40,5,"Ajout\nMise a jour\nRetrait\nReconduit",1,'L');
        $y = $pdf->GetY();
        $pdf->MultiCell(60,5,"Services d'application\n\n\n\n\n",1,'R');
        $pdf->SetY($y);
        $pdf->SetX(70);
        $pdf->MultiCell(90,5,"WebLogic xxRxx et sdk 1.5\nInformation\nTOMCAT\nLa matrice de compatibilite impose une version < a ...\nSi connu, indiquer le niveau de durcissement requis",1,'L');
        $pdf->SetY($y);
        $pdf->SetX(160);
        $pdf->MultiCell(40,5,"...\n\n\n\n\n",1,'L');
        $y = $pdf->GetY();
        $pdf->MultiCell(60,5,"Services Donnes\n\n\n\n\n",1,'R');
        $pdf->SetY($y);
        $pdf->SetX(70);
        $pdf->MultiCell(90,5,"Oracle ww.x.y.z\nIBM DB2 w.x\nMicrosoft SQL Server xxx\nLa matrice de compatibilite impose une version < a ...\nSi connu, indiquer le niveau de durcissement requis",1,'L');
        $pdf->SetY($y);
        $pdf->SetX(160);
        $pdf->MultiCell(40,5,"...\n\n\n\n\n",1,'L');
        $y = $pdf->GetY();
        $pdf->MultiCell(60,5,"Services Ordonnancement",1,'R');
        $pdf->SetY($y);
        $pdf->SetX(70);
        $pdf->MultiCell(90,5,"Control M",1,'L');
        $pdf->SetY($y);
        $pdf->SetX(160);
        $pdf->MultiCell(40,5,"...",1,'L');
        $pdf->SetY(-20);
        $pdf->AddPage();
        $pdf->Ln(5);
        $y = $pdf->GetY();
        $pdf->MultiCell(60,5,"Zone Cellules Securite Reseau (CSR)",1,'R');
        $pdf->SetY($y);
        $pdf->SetX(70);
        $pdf->MultiCell(90,5,"CITSv2,L3,BSC Mutualise,PCMS,CAZA,TNU,GMS,PGN,PEPSY,MAIA",1,'L');
        $pdf->SetY($y);
        $pdf->SetX(160);
        $pdf->MultiCell(40,5,"...\n\n",1,'L');
        $y = $pdf->GetY();
        $pdf->MultiCell(60,5,"Systemes d'exploitation\n\n\n\n",1,'R');
        $pdf->SetY($y);
        $pdf->SetX(70);
        $pdf->MultiCell(90,5,"Linux Red Hat 6.6\nWindows 2012 SPxx\nAIX 6.1 TL3\nLa matrice de comptatibilite impose une version < a ...",1,'L');
        $pdf->SetY($y);
        $pdf->SetX(160);
        $pdf->MultiCell(40,5,"...\n\n\n\n",1,'L');
        $y = $pdf->GetY();
        $pdf->MultiCell(60,5,"Classe de resilience du stockage\n\n",1,'R');
        $pdf->SetY($y);
        $pdf->SetX(70);
        $pdf->MultiCell(90,5,"SAN: M0,M1,L0,L1 + id du groupe de coherence\n\n",1,'L');
        $pdf->SetY($y);
        $pdf->SetX(160);
        $pdf->MultiCell(40,5,"...\n\n",1,'L');
        $y = $pdf->GetY();
        $pdf->MultiCell(60,5,"Conformite standard et politique\n\n\n\n",1,'R');
        $pdf->SetY($y);
        $pdf->SetX(70);
        $pdf->MultiCell(90,5,"Durcissement OS:\nAdvenced\nPremium\nPremium+",1,'L');
        $pdf->SetY($y);
        $pdf->SetX(160);
        $pdf->MultiCell(40,5,"...\n\n\n\n",1,'L');
        $y = $pdf->GetY();
        $pdf->MultiCell(60,5,"Features hors socle a installer\n\n\n\n",1,'R');
        $pdf->SetY($y);
        $pdf->SetX(70);
        $pdf->MultiCell(90,5,"Features a installer hors socle ou ce qui est obligatoire\nJVM Oracle dans la couche DB\nOpenSSH\n\n",1,'L');
        $pdf->SetY($y);
        $pdf->SetX(160);
        $pdf->MultiCell(40,5,"...\n\n\n\n",1,'L');
        $y = $pdf->GetY();
        $pdf->MultiCell(60,5,"Ressources Techniques\n\n\n\n\n",1,'R');
        $pdf->SetY($y);
        $pdf->SetX(70);
        $pdf->MultiCell(130,5,"3 chois possibles :\n-Indiquer les paragraphes correspondants par environnement\n-Mettre ici le tableau récapitulatif tout environnement\n-ou en litteraire",1,'L');
        $y = $pdf->GetY();
        $pdf->MultiCell(60,5,"Offres GTS\n\n\n",1,'R');
        $pdf->SetY($y);
        $pdf->SetX(70);
        $pdf->MultiCell(90,5,"RET : OMLX, SQM, OMDG\nTFO : SIPO [Exotique],etc\nEUS : @PAC,...",1,'L');
        $pdf->SetY($y);
        $pdf->SetX(160);
        $pdf->MultiCell(40,5,"...\n\n\n",1,'L');
        $y = $pdf->GetY();
        $pdf->MultiCell(60,5,"Servitudes\n\n\n",1,'R');
        $pdf->SetY($y);
        $pdf->SetX(70);
        $pdf->MultiCell(90,5,"Sauvegarde Standard TSM ou Lan Free Backup ou specifique (ex : Networker sur Valmy)\nSupervision standard Patrol",1,'L');
        $pdf->SetY($y);
        $pdf->SetX(160);
        $pdf->MultiCell(40,5,"...\n\n\n",1,'L');
        $y = $pdf->GetY();
        $pdf->MultiCell(60,5,"Ressources reseaux\n",1,'R');
        $pdf->SetY($y);
        $pdf->SetX(70);
        $pdf->MultiCell(90,5,"x lien 100 Mb | 1 Gb | 10Gb",1,'L');
        $pdf->SetY($y);
        $pdf->SetX(160);
        $pdf->MultiCell(40,5,"...\n",1,'L');
        $y = $pdf->GetY();
        $pdf->MultiCell(60,5,"Poste de travail\n\n",1,'R');
        $pdf->SetY($y);
        $pdf->SetX(70);
        $pdf->MultiCell(90,5,"Client lourd ou client web NDG ARPEGE IE8\nInternational oui/non",1,'L');
        $pdf->SetY($y);
        $pdf->SetX(160);
        $pdf->MultiCell(40,5,"...\n\n",1,'L');
        $y = $pdf->GetY();
        $pdf->MultiCell(60,5,"Service d'acces\n",1,'R');
        $pdf->SetY($y);
        $pdf->SetX(70);
        $pdf->MultiCell(90,5,"CITRIX,PAX,TRAP,I2BD,GAIA VPN,LS",1,'L');
        $pdf->SetY($y);
        $pdf->SetX(160);
        $pdf->MultiCell(40,5,"...\n",1,'L');
        $y = $pdf->GetY();
        $pdf->MultiCell(60,5,"Processus de livraison des packages applicatifs en production\n",1,'R');
        $pdf->SetY($y);
        $pdf->SetX(70);
        $pdf->MultiCell(90,5,"Earth CDI\nNon standard (scp,client lourd,etc)",1,'L');
        $pdf->SetY($y);
        $pdf->SetX(160);
        $pdf->MultiCell(40,5,"...\n\n",1,'L');
        $y = $pdf->GetY();
        $pdf->MultiCell(60,5,"Principaux ecarts par rapport a la strategie ou aux exigences GTS\n\n\n\n\n\n\n\n\n",1,'R');
        $pdf->SetY($y);
        $pdf->SetX(70);
        $pdf->MultiCell(105,5,"Domaine\n\n",1,'L');
        $pdf->SetY($y);
        $pdf->SetX(175);
        $pdf->MultiCell(25,5,"Ecart ? oui/non\n",1,'L');
        $y = $pdf->GetY();
        $pdf->SetY($y);
        $pdf->SetX(70);
        $pdf->MultiCell(105,5,"Securite",1,'L');
        $pdf->SetY($y);
        $pdf->SetX(175);
        $pdf->MultiCell(25,5,"",1,'L');
        $y = $pdf->GetY();
        $pdf->SetY($y);
        $pdf->SetX(70);
        $pdf->MultiCell(105,5,"Virtualisation comme 1er choix de hosting",1,'L');
        $pdf->SetY($y);
        $pdf->SetX(175);
        $pdf->MultiCell(25,5,"",1,'L');
        $y = $pdf->GetY();
        $pdf->SetY($y);
        $pdf->SetX(70);
        $pdf->MultiCell(105,5,"CITSv2 / L3",1,'L');
        $pdf->SetY($y);
        $pdf->SetX(175);
        $pdf->MultiCell(25,5,"",1,'L');
        $y = $pdf->GetY();
        $pdf->SetY($y);
        $pdf->SetX(70);
        $pdf->MultiCell(105,5,"Capacite a realiser des exercices pleine charge <-> ecosysteme de donnees et de flux definis et valides",1,'L');
        $pdf->SetY($y);
        $pdf->SetX(175);
        $pdf->MultiCell(25,5,"\n\n",1,'L');
        $y = $pdf->GetY();
        $pdf->SetY($y);
        $pdf->SetX(70);
        $pdf->MultiCell(105,5,"RedCat",1,'L');
        $pdf->SetY($y);
        $pdf->SetX(175);
        $pdf->MultiCell(25,5,"",1,'L');
        $y = $pdf->GetY();
        $pdf->SetY($y);
        $pdf->SetX(70);
        $pdf->MultiCell(105,5,"Stategie DataCenter",1,'L');
        $pdf->SetY($y);
        $pdf->SetX(175);
        $pdf->MultiCell(25,5,"",1,'L');
        $y = $pdf->GetY();
        $pdf->SetY($y);
        $pdf->SetX(70);
        $pdf->MultiCell(105,5,"Processus de livraison standard",1,'L');
        $pdf->SetY($y);
        $pdf->SetX(175);
        $pdf->MultiCell(25,5,"",1,'L');
        $pdf->SetY(-20);
        $pdf->AddPage();
        $pdf->Ln(5);
        $y = $pdf->GetY();
        $pdf->MultiCell(60,5,"Principaux ecarts par rapport aux besoins exprimes\n\n\n\n\n",1,'R');
        $pdf->SetY($y);
        $pdf->SetX(70);
        $pdf->MultiCell(130,5,"synthese : xxxxx\n\nLister les ecarts de manière synthetique\n1. Ecart 1: Domaine/description synthetique\n2. ex SLA de disponibilite\n3. ex : couverture de risques",1,'L');
        $y = $pdf->GetY();
        $pdf->MultiCell(60,5,"Synthese de l'avis Securite",1,'R');
        $pdf->SetY($y);
        $pdf->SetX(70);
        $pdf->MultiCell(130,5,"Rappeler le niveau d'ISR indique en cartouche (page de garde)",1,'L');
        $pdf->Ln(10);
        $pdf->Write(5,"Dans le paragraphe 1.2.2, le recapitulatif des besoins declines par offre et par environnement et par site");
        $pdf->Ln(10);
        $pdf->Cell(190,5,"JALON DU PLANNING",1,1,'C');

        $pdf->Cell(60,5,"CVT-I",1,0,'C');
        $pdf->Cell(60,5,"XX/XX/XXXX",1,0,'C');
        $pdf->Cell(70,5,"N/A",1,1,'L');
        $pdf->Cell(60,5,"CVT-Q / QA",1,0,'C');
        $pdf->Cell(60,5,"XX/XX/XXXX",1,0,'C');
        $pdf->Cell(70,5,"",1,1,'L');
        $pdf->Cell(60,5,"CVT-X",1,0,'C');
        $pdf->Cell(60,5,"XX/XX/XXXX",1,0,'C');
        $pdf->Cell(70,5,"",1,1,'L');
        $pdf->Cell(60,5,"Installation en developpement",1,0,'C');
        $pdf->Cell(60,5,"XX/XX/XXXX",1,0,'C');
        $pdf->Cell(70,5,"",1,1,'L');
        $pdf->Cell(60,5,"Mise en homologation-X",1,0,'C');
        $pdf->Cell(60,5,"XX/XX/XXXX",1,0,'C');
        $pdf->Cell(70,5,"",1,1,'L');
        $pdf->Cell(60,5,"Mise en production",1,0,'C');
        $pdf->Cell(60,5,"XX/XX/XXXX",1,0,'C');
        $pdf->Cell(70,5,"",1,1,'L');
        $pdf->Ln(10);
        $pdf->Write(5,"- Tous les acronymes sont recenses dans le 8.5 Glossaire");
        $pdf->Ln();
        $pdf->Write(5,"- Ce document presente le plan type du Dossier d'Architecture Hebergement (DAH) dont la structure et le contenu sont sous la responsabilite de GTS/RET/APS");
        $pdf->Ln();
        $pdf->Write(5,"- Ce DAH (oriente infrastructure) est le document resultant du DAA en entree (orientation metier). Le contenu du DAA est sous la responsabilite de la maitre d'oeuvre du projet");
        $pdf->Ln(10);
        $pdf->Write(5,"Workflow simplifie du DAH");
        $pdf->Ln(50);
        $pdf->Write(5,"- Le processus global de l'etude GTS d'architecture est decrit dans le document 'HAO : Hosting Architecture Offer v1.0' que l'on peut trouver sur ce site (document 'processus d'elaboration d'Architecture Technique')");
        $pdf->Ln();
        $pdf->Write(5,"Les caracteristiques ci-dessous du document sont a renseigner dans les 'prorietes' du document (onglet 'Resume') :");
        $pdf->Ln();
        $pdf->SetX(20);
        $pdf->Write(5,"- Nom du projet");
        $pdf->Ln();
        $pdf->SetX(20);
        $pdf->Write(5,"- Sous titre");
        $pdf->Ln();
        $pdf->SetX(30);
        $pdf->Write(5,"- Objet(Nom application)");
        $pdf->Ln();
        $pdf->SetX(30);
        $pdf->Write(5,"- Categorie ( Nom de l'ecosysteme d'hebergmeent )");
        $pdf->Ln();
        $pdf->SetX(20);
        $pdf->Write(5,"- Version du document");
        $pdf->Ln();
        $pdf->SetX(20);
        $pdf->Write(5,"- Statut du document");
        $pdf->SetY(-20);
        // Table des matieres
        //////////////////////////////////////////////
        $pdf->AddPage();
        $pdf->SetFont('Arial','BU',11);
        $pdf->SetY(32);
        $pdf->Write(5,'Table des matieres');
        $pdf->Ln(7);
        $pdf->SetFont('Arial','',10);
        $prgs_niv_0 = Laralum::tplList('niv',0);
        for($i=0;$i<count($prgs_niv_0);$i++){
            if($prgs_niv_0[$i]->id_template == $application[0]->template_id){
                $pdf->Ln(5);
                $pdf->SetX(10);
                $pdf->Write(5,str_replace("?","'",utf8_decode($prgs_niv_0[$i]->num_parag." - ".$prgs_niv_0[$i]->text)));
            }

            // Récupération des paragraphes de niveau 1 du template
            $prgs_niv_1 = Laralum::tplList('parent',$prgs_niv_0[$i]->id);
            for($j=0;$j<count($prgs_niv_1);$j++){
                if($prgs_niv_1[$j]->id_template == $application[0]->template_id){
                    $pdf->Ln(5);
                    $pdf->SetX(20);
                    $pdf->Write(5,str_replace("?","'",utf8_decode($prgs_niv_1[$j]->num_parag." - ".$prgs_niv_1[$j]->text)));
                }

                // Récupération des paragraphes de niveau 2 du template
                $prgs_niv_2 = Laralum::tplList('parent',$prgs_niv_1[$j]->id);
                for($k=0;$k<count($prgs_niv_2);$k++){
                    if($prgs_niv_2[$k]->id_template == $application[0]->template_id){
                        $pdf->Ln(5);
                        $pdf->SetX(30);
                        $pdf->Write(5,str_replace("?","'",utf8_decode($prgs_niv_2[$k]->num_parag." - ".$prgs_niv_2[$k]->text)));
                    }
                }

            }
        }
        $pdf->SetY(-20);
        // Page d'introduction
        //////////////////////////////////////////////
        $pdf->AddPage();
        $pdf->SetFont('Arial','B',18);
        $pdf->Cell(0,20,'INTRODUCTION',0,1,'C');
        $pdf->SetFont('Arial','',11);
        $pdf->Write(5,'L\'objet de ce document est de presenter l\'architecture technique et les ressources techniques de l\'application FILA-E a mettre en oeuvre et validee par les differents acteurs dans le cadre du projet. Il doit contenir la liste exhaustive des ressources materielles (serveurs,RAM,CPUs,interfaces reseaux donnees, interfaces stockage et sauvegarde) a mettre en place pour assurer le fonctionnement, la sauvegarde et le secours eventuel de l\'application');
        $pdf->Ln();
        $pdf->SetY(-20);
        $pdf->SetFont('Arial','',10);
        // Corps du document
        //////////////////////////////////////////////
        $pdf->AddPage();
        $pdf->SetY(32);

        // Récupération du contenu de l'application courante

        //print_r($idApp);
        //print_r($prgs_content);die;
        // Récupération des paragraphes de niveau 0 du template
        $prgs_niv_0 = Laralum::tplList('niv',0);
        for($i=0;$i<count($prgs_niv_0);$i++){
            if($prgs_niv_0[$i]->id_template == $application[0]->template_id){
                $pdf->Ln(5);
                $pdf->SetX(10);
                $pdf->SetFont("","U","");
                $pdf->Write(5,str_replace("?","'",utf8_decode($prgs_niv_0[$i]->num_parag." - ".$prgs_niv_0[$i]->text)));
                $pdf->SetFont("","","");
                $pdf->Ln(10);

                for($row=0;$row<count($prgs_content);$row++){

                    // Contenu du paragraphe
                    $original_str = $prgs_content[$row]->text_stat;
                    // Si le chapitre courant correspond au chapitre de l'application
                    if($prgs_content[$row]->num_parag == $prgs_niv_0[$i]->num_parag){
                        $pdf->WriteHTML($original_str);
                        //$pdf->Ln(5);
                    }
                }
            }


            // Récupération des paragraphes de niveau 1 du template
            $prgs_niv_1 = Laralum::tplList('parent',$prgs_niv_0[$i]->id);
            for($j=0;$j<count($prgs_niv_1);$j++){
                if($prgs_niv_1[$j]->id_template == $application[0]->template_id){
                    $pdf->Ln(5);
                    $pdf->SetX(20);
                    $pdf->SetFont("","U","");
                    $pdf->Write(5,str_replace("?","'",utf8_decode($prgs_niv_1[$j]->num_parag." - ".$prgs_niv_1[$j]->text)));
                    $pdf->SetFont("","","");
                    $pdf->Ln(10);
                    for($row=0;$row<count($prgs_content);$row++){
                        // Contenu du paragraphe
                        $original_str = $prgs_content[$row]->text_stat;
                        // Si le chapitre courant correspond au chapitre de l'application
                        if($prgs_content[$row]->num_parag == $prgs_niv_1[$j]->num_parag){
                            $pdf->WriteHTML($original_str);
                            //$pdf->Ln(5);
                        }
                    }
                }

                // Récupération des paragraphes de niveau 2 du template
                $prgs_niv_2 = Laralum::tplList('parent',$prgs_niv_1[$j]->id);
                for($k=0;$k<count($prgs_niv_2);$k++){
                    if($prgs_niv_2[$k]->id_template == $application[0]->template_id){
                        $pdf->Ln(5);
                        $pdf->SetX(30);
                        $pdf->SetFont("","U","");
                        $pdf->Write(5,str_replace("?","'",utf8_decode($prgs_niv_2[$k]->num_parag." - ".$prgs_niv_2[$k]->text)));
                        $pdf->SetFont("","","");
                        $pdf->Ln(10);
                        for($row=0;$row<count($prgs_content);$row++){
                            // Contenu du paragraphe
                            $original_str = $prgs_content[$row]->text_stat;
                            // Si le chapitre courant correspond au chapitre de l'application
                            if($prgs_content[$row]->num_parag == $prgs_niv_2[$k]->num_parag){
                                $pdf->WriteHTML($original_str);
                                //$pdf->Ln(5);
                            }
                        }

                    }
                }
            }
        }

        $pdf->SetY(-20);
        $pdf->Output('I','pdf.pdf',false);
    }
}

define('FPDF_VERSION','1.81');

class FPDF
{
protected $page;               // current page number
protected $n;                  // current object number
protected $offsets;            // array of object offsets
protected $buffer;             // buffer holding in-memory PDF
protected $pages;              // array containing pages
protected $state;              // current document state
protected $compress;           // compression flag
protected $k;                  // scale factor (number of points in user unit)
protected $DefOrientation;     // default orientation
protected $CurOrientation;     // current orientation
protected $StdPageSizes;       // standard page sizes
protected $DefPageSize;        // default page size
protected $CurPageSize;        // current page size
protected $CurRotation;        // current page rotation
protected $PageInfo;           // page-related data
protected $wPt, $hPt;          // dimensions of current page in points
protected $w, $h;              // dimensions of current page in user unit
protected $lMargin;            // left margin
protected $tMargin;            // top margin
protected $rMargin;            // right margin
protected $bMargin;            // page break margin
protected $cMargin;            // cell margin
protected $x, $y;              // current position in user unit
protected $lasth;              // height of last printed cell
protected $LineWidth;          // line width in user unit
protected $fontpath;           // path containing fonts
protected $CoreFonts;          // array of core font names
protected $fonts;              // array of used fonts
protected $FontFiles;          // array of font files
protected $encodings;          // array of encodings
protected $cmaps;              // array of ToUnicode CMaps
protected $FontFamily;         // current font family
protected $FontStyle;          // current font style
protected $underline;          // underlining flag
protected $CurrentFont;        // current font info
protected $FontSizePt;         // current font size in points
protected $FontSize;           // current font size in user unit
protected $DrawColor;          // commands for drawing color
protected $FillColor;          // commands for filling color
protected $TextColor;          // commands for text color
protected $ColorFlag;          // indicates whether fill and text colors are different
protected $WithAlpha;          // indicates whether alpha channel is used
protected $ws;                 // word spacing
protected $images;             // array of used images
protected $PageLinks;          // array of links in pages
protected $links;              // array of internal links
protected $AutoPageBreak;      // automatic page breaking
protected $PageBreakTrigger;   // threshold used to trigger page breaks
protected $InHeader;           // flag set when processing header
protected $InFooter;           // flag set when processing footer
protected $AliasNbPages;       // alias for total number of pages
protected $ZoomMode;           // zoom display mode
protected $LayoutMode;         // layout display mode
protected $metadata;           // document properties
protected $PDFVersion;         // PDF version number
protected $B = 0;
protected $I = 0;
protected $U = 0;
protected $HREF = '';
protected $application;
protected $project;

/*******************************************************************************
*                               Public methods                                 *
*******************************************************************************/

function __construct($idApp,$orientation='P', $unit='mm', $size='A4')
{
	// Some checks
	$this->_dochecks();
	// Initialization of properties
	$this->state = 0;
	$this->page = 0;
	$this->n = 2;
	$this->buffer = '';
	$this->pages = array();
	$this->PageInfo = array();
	$this->fonts = array();
	$this->FontFiles = array();
	$this->encodings = array();
	$this->cmaps = array();
	$this->images = array();
	$this->links = array();
	$this->InHeader = false;
	$this->InFooter = false;
	$this->lasth = 0;
	$this->FontFamily = '';
	$this->FontStyle = '';
	$this->FontSizePt = 12;
	$this->underline = false;
	$this->DrawColor = '0 G';
	$this->FillColor = '0 g';
	$this->TextColor = '0 g';
	$this->ColorFlag = false;
	$this->WithAlpha = false;
	$this->ws = 0;
	$this->application = Laralum::applications('id',$idApp);
	$this->project = Laralum::projects('id',$this->application[0]->project_id);
	// Font path
	if(defined('FPDF_FONTPATH'))
	{
		$this->fontpath = FPDF_FONTPATH;
		if(substr($this->fontpath,-1)!='/' && substr($this->fontpath,-1)!='\\') {echo 'katk';die;
            $this->fontpath .= '/';
        }

	}
	elseif(is_dir(dirname(__FILE__).'/font'))
		$this->fontpath = dirname(__FILE__).'/font/';
	else
		$this->fontpath = '';
	// Core fonts
	$this->CoreFonts = array('courier', 'helvetica', 'times', 'symbol', 'zapfdingbats');
	// Scale factor
	if($unit=='pt')
		$this->k = 1;
	elseif($unit=='mm')
		$this->k = 72/25.4;
	elseif($unit=='cm')
		$this->k = 72/2.54;
	elseif($unit=='in')
		$this->k = 72;
	else
		$this->Error('Incorrect unit: '.$unit);
	// Page sizes
	$this->StdPageSizes = array('a3'=>array(841.89,1190.55), 'a4'=>array(595.28,841.89), 'a5'=>array(420.94,595.28),
		'letter'=>array(612,792), 'legal'=>array(612,1008));
	$size = $this->_getpagesize($size);
	$this->DefPageSize = $size;
	$this->CurPageSize = $size;
	// Page orientation
	$orientation = strtolower($orientation);
	if($orientation=='p' || $orientation=='portrait')
	{
		$this->DefOrientation = 'P';
		$this->w = $size[0];
		$this->h = $size[1];
	}
	elseif($orientation=='l' || $orientation=='landscape')
	{
		$this->DefOrientation = 'L';
		$this->w = $size[1];
		$this->h = $size[0];
	}
	else
		$this->Error('Incorrect orientation: '.$orientation);
	$this->CurOrientation = $this->DefOrientation;
	$this->wPt = $this->w*$this->k;
	$this->hPt = $this->h*$this->k;
	// Page rotation
	$this->CurRotation = 0;
	// Page margins (1 cm)
	$margin = 28.35/$this->k;
	$this->SetMargins($margin,$margin);
	// Interior cell margin (1 mm)
	$this->cMargin = $margin/10;
	// Line width (0.2 mm)
	$this->LineWidth = .567/$this->k;
	// Automatic page break
	$this->SetAutoPageBreak(true,2*$margin);
	// Default display mode
	$this->SetDisplayMode('default');
	// Enable compression
	$this->SetCompression(true);
	// Set default PDF version number
	$this->PDFVersion = '1.3';
}

function findAll($needle, $haystack) 
{
  // initialize the return value array
	$rv = array();

  // set up a temp variable to make things simple
	$temp = 0;

  // successively find each instance of needle in haystack
	while($temp < strlen($haystack)) 
	{
		$temp = strpos($haystack,$needle, $temp);

		if($temp !== false) 
		{
			$rv[] = $temp;
			$temp++;
		} 
		else
		{
      // nothing to find
			return $rv;
		}
	}
	return $rv;
} 

function WriteHTML($html)
{
	$html = $this->ReplaceHTML($html);
	$w = array();

    // search for a table
	$starts = $this->findAll('<table',strtolower($html));
	$ends = $this->findAll('</table',strtolower($html));

	if(count($starts) > 0 && count($ends) > 0)
	{
		$positions[0] = 'doc-start';

		foreach($starts as $key => $start)
		{
			$end = $ends[$key];
			$positions[$start] = 'table-start';
			$positions[$end] = 'table-end';
		}

		$endPos = strlen($html)-1;
		$positions[$endPos] = 'doc-end';

		$lastKnownPos = 0;

		for($q=1;$q<=$endPos;$q++)
		{
			if(isset($positions[$q]))
			{
				$curPos = $positions[$q];

				if($curPos == 'table-start')
				{
					$this->WriteHTML2(substr($html,$lastKnownPos,$q-$lastKnownPos).'<BR>'); 
					$lastKnownPos = $q;
				}
				else if($curPos == 'table-end')
				{
					$tableVar = substr($html,$lastKnownPos,$q-$lastKnownPos+8);
					$tableData = $this->ParseTable($tableVar);

					for($i=0;$i<count($tableData[0]);$i++)
					{
						if($this->CurOrientation=='L')
						{
							$w[$i] = abs(277/(count($tableData[0])));
						}
						else
						{
							$w[$i] = abs(190/(count($tableData[0])));
						}
					}
					$this->WriteTable($tableData,$w);
					$lastKnownPos = $q+8;
				}
				else if($curPos == 'doc-end')
				{
					$this->WriteHTML2(substr($html,$lastKnownPos,$q-$lastKnownPos).'<BR>'); 
					$lastKnownPos = $q;              
				}
			}
		}
	} 
	else
	{
      // if there is no table, just write the HTML as normal
		$this->WriteHTML2($html);
	}
}

function WriteHTML2($html)
{
    //HTML parser
    //$html = $this->ReplaceHTML($html);
	$html=str_replace("\n",' ',$html);
	$a=preg_split('/<(.*)>/U',$html,-1,PREG_SPLIT_DELIM_CAPTURE);
	foreach($a as $i=>$e)
	{
    	/*print_r($i." - ");
    	print_r($e."<br>");*/
    	if($i%2==0)
    	{
            //Text
    		if($this->HREF)
    			$this->PutLink($this->HREF,$e);
    		else
    			if($e !== "" && $e !== " "){
    				$this->SetFillColor(255,255,255);
    				$width = $this->GetStringWidth($e)+5;
    				$y = $this->GetY();
    				$this->SetY($y-5);
            		//$this->SetX(10);
    				if($width > 190){
    					$this->MultiCell(0,5,$e,0,'L',true);	
    				}
    				else{
    					$this->MultiCell($width,5,$e,0,'L',true);	
    				}
    				$y = $this->GetY();
    				$this->SetY($y);
    			}                                                                                
    		}
    		else
    		{
            //Tag
    			if($e[0]=='/'){
    				$this->CloseTag(strtoupper(substr($e,1)));
    				$this->Setfont('','');
    				$this->SetTextColor(0,0,0);
    				$this->SetFillColor(255,255,255);
    			}
    			else
    			{
                //Extract attributes
    				$a2=explode(' ',$e);
    				$tag=strtoupper(array_shift($a2));
    				$attr=array();
    				foreach($a2 as $v)
    				{
    					if(preg_match('/([^=]*)=["\']?([^"\']*)/',$v,$a3))
    						$attr[strtoupper($a3[1])]=$a3[2];
    				}
    				$this->OpenTag($tag,$attr);
    			}
    		}
    		
    	}
    //die;
    }

    function OpenTag($tag, $attr)
    {
    	$this->attr_tag($attr);
    //Opening tag
    	switch($tag){
    		case 'STRONG':
    		$this->SetStyle('B',true);
    		break;
    		case 'B':
    		$this->SetStyle($tag,true);
    		$this->Ln();
    		break;
    		case 'I':
    		case 'U':
    		$this->SetStyle($tag,true);
    		break;
    		case 'A':
    		$this->HREF=$attr['HREF'];
    		break;
    		case 'IMG':
    		/*if(isset($attr['SRC']) && (isset($attr['WIDTH']) || isset($attr['HEIGHT']))) {
    			if(!isset($attr['WIDTH']))
    				$attr['WIDTH'] = 0;
    			if(!isset($attr['HEIGHT']))
    				$attr['HEIGHT'] = 0;
    			$this->Image($attr['SRC'], $this->GetX(), $this->GetY(), px2mm($attr['WIDTH']), px2mm($attr['HEIGHT']));
    		}*/
    		break;
    		case 'TR':
    		break;
    		case 'BLOCKQUOTE':
    		case 'BR':
    		$this->Ln();
    		break;
    		case 'P':
    		$this->Ln(5);
    		break;
    		case 'FONT':
    		if (isset($attr['COLOR']) && $attr['COLOR']!='') {
    			$coul=hex2dec($attr['COLOR']);
    			$this->SetTextColor($coul['R'],$coul['V'],$coul['B']);
    			$this->issetcolor=true;
    		}
    		if (isset($attr['FACE']) && in_array(strtolower($attr['FACE']), $this->fontlist)) {
    			$this->SetFont(strtolower($attr['FACE']));
    			$this->issetfont=true;
    		}
    		break;
    	}
    }

    public function attr_tag($attr){
	//print_r($attr);die;
    	if(array_key_exists('STYLE', $attr)){
    		$attr = explode(";",$attr['STYLE']);
    		for($x=0;$x<count($attr);$x++){
    			$attr[$x] = explode(":",$attr[$x]);
    			switch($attr[$x][0]){
    				case 'color':
    				$attr[$x][1] = substr($attr[$x][1],1);
    				$rgb = str_split($attr[$x][1],2);
    				$this->SetTextColor(hexdec($rgb[0]),hexdec($rgb[1]),hexdec($rgb[2]));
    				break;
    				case 'background-color':
    				$attr[$x][1] = substr($attr[$x][1],1);
    				$rgb = str_split($attr[$x][1],2);
    				$this->SetFillColor(hexdec($rgb[0]),hexdec($rgb[1]),hexdec($rgb[2]));
    				break;
    			}
    			
    		}	
    	}
    	
    }

    function CloseTag($tag)
    {
    //Closing tag
    	if($tag=='STRONG')
    		$tag='B';
    	if($tag=='EM')
    		$tag='I';
    	if($tag=='B' || $tag=='I' || $tag=='U')
    		$this->SetStyle($tag,false);
    	if($tag=='A')
    		$this->HREF='';
    	if($tag=='FONT'){
    		if ($this->issetcolor==true) {
    			$this->SetTextColor(0);
    		}
    		if ($this->issetfont) {
    			$this->SetFont('arial');
    			$this->issetfont=false;
    		}
    	}
    	if($tag=='P')
    		$this->Ln(5);

    	$this->SetTextColor(0,0,0);
    }

    function SetStyle($tag, $enable)
    {
   //Modify style and select corresponding font
    	$this->$tag+=($enable ? 1 : -1);
    	$style='';
    	foreach(array('B','I','U') as $s)
    	{
    		if($this->$s>0)
    			$style.=$s;
    	}
    	$this->SetFont('',$style);
    }

    function PutLink($URL, $txt)
    {
    //Put a hyperlink
    	$this->SetTextColor(0,0,255);
    	$this->SetStyle('U',true);
    	$this->Write(5,$txt,$URL);
    	$this->SetStyle('U',false);
    	$this->SetTextColor(0);
    }

    function WriteTable($data, $w)
    {
    	$this->SetLineWidth(.3);
    	$this->SetFillColor(255,255,255);
    	$this->SetTextColor(0);
    	$this->SetFont('');
    //$this->Ln(5);
    	foreach($data as $row)
    	{
    		$nb=0;
    		for($i=0;$i<count($row);$i++)
    			$nb=max($nb,$this->NbLines($w[$i],/*trim(*/$row[$i]/*)*/));
    		$h=5*$nb;
    		$this->CheckPageBreak($h);
    		for($i=0;$i<count($row);$i++)
    		{
    			$x=$this->GetX();
    			$y=$this->GetY();
    			$this->Rect($x,$y,$w[$i],$h);
    			$this->MultiCell($w[$i],5,trim($row[$i]),1,'C',true);
            //Put the position to the right of the cell
    			$this->SetXY($x+$w[$i],$y);
    		}
    		$this->Ln(5);

    	}
    	$this->Ln(5);    
    }

    function NbLines($w, $txt)
    {
    //Computes the number of lines a MultiCell of width w will take
    	$cw=&$this->CurrentFont['cw'];
    	if($w==0)
    		$w=$this->w-$this->rMargin-$this->x;
    	$wmax=($w-2*$this->cMargin)*1000/$this->FontSize;
    	$s=str_replace("\r",'',$txt);
    	$nb=strlen($s);
    	if($nb>0 && $s[$nb-1]=="\n")
    		$nb--;
    	$sep=-1;
    	$i=0;
    	$j=0;
    	$l=0;
    	$nl=1;
    	while($i<$nb)
    	{
    		$c=$s[$i];
    		if($c=="\n")
    		{
    			$i++;
    			$sep=-1;
    			$j=$i;
    			$l=0;
    			$nl++;
    			continue;
    		}
    		if($c==' ')
    			$sep=$i;
    		$l+=$cw[$c];
    		if($l>$wmax)
    		{
    			if($sep==-1)
    			{
    				if($i==$j)
    					$i++;
    			}
    			else
    				$i=$sep+1;
    			$sep=-1;
    			$j=$i;
    			$l=0;
    			$nl++;
    		}
    		else
    			$i++;
    	}
    	return $nl;
    }

    function CheckPageBreak($h)
    {
    //If the height h would cause an overflow, add a new page immediately
    	if($this->GetY()+$h>$this->PageBreakTrigger){
    		$this->AddPage($this->CurOrientation);
    	}

    }

    function ReplaceHTML($html)
    {
    	$html = str_replace( '<em>', "<i>" , $html );
    	$html = str_replace( '</em>', "</i>" , $html );
    	$html = str_replace( '&ndash;', '-',$html );
    	$html = str_replace( '&eacute;','e',$html);
    	$html = str_replace( '&egrave;','e',$html);
    //$html = str_replace( '<li>', "-" , $html );
    	$html = str_replace( '<LI>', " - " , $html );
    //$html = str_replace( '</ul>', " " , $html );
    	$html = str_replace( '<strong>', "<b>" , $html );
    	$html = str_replace( '</strong>', "</b>" , $html );
    	$html = str_replace( '&#160;', "\n" , $html );
    	$html = str_replace( '&nbsp;', " " , $html );
    	$html = str_replace( '&nbsp', " " , $html );
    	$html = str_replace( '&quot;', "\"" , $html ); 
    	$html = str_replace( '&#39;', "'" , $html );
    	return $html;
    }

    function ParseTable($Table)
    {
    	$_var='';
    	$htmlText = $Table;
    	$parser = new HtmlParser($htmlText);
    	while ($parser->parse())
    	{
    		if(strtolower($parser->iNodeName)=='table')
    		{
    			if($parser->iNodeType == NODE_TYPE_ENDELEMENT)
    				$_var .='/::';
    			else
    				$_var .='::';
    		}

    		if(strtolower($parser->iNodeName)=='tr')
    		{
    			if($parser->iNodeType == NODE_TYPE_ENDELEMENT)
                $_var .='!-:'; //opening row
            else
                $_var .=':-!'; //closing row
        }
        if(strtolower($parser->iNodeName)=='td' && $parser->iNodeType == NODE_TYPE_ENDELEMENT)
        {
        	$_var .='#,#';
        }
        if ($parser->iNodeName=='Text' && isset($parser->iNodeValue))
        {
        	$_var .= $parser->iNodeValue;
        }
    }
    $elems = explode(':-!',str_replace('/','',str_replace('::','',str_replace('!-:','',$_var)))); //opening row
    foreach($elems as $key=>$value)
    {
    	if(trim($value)!='')
    	{
    		$elems2 = explode('#,#',$value);
    		array_pop($elems2);
    		$data[] = $elems2;
    	}
    }
    return $data;
}

function SetMargins($left, $top, $right=null)
{
	// Set left, top and right margins
	$this->lMargin = $left;
	$this->tMargin = $top;
	if($right===null)
		$right = $left;
	$this->rMargin = $right;
}

function SetLeftMargin($margin)
{
	// Set left margin
	$this->lMargin = $margin;
	if($this->page>0 && $this->x<$margin)
		$this->x = $margin;
}

function SetTopMargin($margin)
{
	// Set top margin
	$this->tMargin = $margin;
}

function SetRightMargin($margin)
{
	// Set right margin
	$this->rMargin = $margin;
}

function SetAutoPageBreak($auto, $margin=0)
{
	// Set auto page break mode and triggering margin
	$this->AutoPageBreak = $auto;
	$this->bMargin = $margin;
	$this->PageBreakTrigger = $this->h-$margin;
}

function SetDisplayMode($zoom, $layout='default')
{
	// Set display mode in viewer
	if($zoom=='fullpage' || $zoom=='fullwidth' || $zoom=='real' || $zoom=='default' || !is_string($zoom))
		$this->ZoomMode = $zoom;
	else
		$this->Error('Incorrect zoom display mode: '.$zoom);
	if($layout=='single' || $layout=='continuous' || $layout=='two' || $layout=='default')
		$this->LayoutMode = $layout;
	else
		$this->Error('Incorrect layout display mode: '.$layout);
}

function SetCompression($compress)
{
	// Set page compression
	if(function_exists('gzcompress'))
		$this->compress = $compress;
	else
		$this->compress = false;
}

function SetTitle($title, $isUTF8=false)
{
	// Title of document
	$this->metadata['Title'] = $isUTF8 ? $title : utf8_encode($title);
}

function SetAuthor($author, $isUTF8=false)
{
	// Author of document
	$this->metadata['Author'] = $isUTF8 ? $author : utf8_encode($author);
}

function SetSubject($subject, $isUTF8=false)
{
	// Subject of document
	$this->metadata['Subject'] = $isUTF8 ? $subject : utf8_encode($subject);
}

function SetKeywords($keywords, $isUTF8=false)
{
	// Keywords of document
	$this->metadata['Keywords'] = $isUTF8 ? $keywords : utf8_encode($keywords);
}

function SetCreator($creator, $isUTF8=false)
{
	// Creator of document
	$this->metadata['Creator'] = $isUTF8 ? $creator : utf8_encode($creator);
}

function AliasNbPages($alias='{nb}')
{
	// Define an alias for total number of pages
	$this->AliasNbPages = $alias;
}

function Error($msg)
{
	// Fatal error
	throw new Exception('FPDF error: '.$msg);
}

function Close()
{
	// Terminate document
	if($this->state==3)
		return;
	if($this->page==0)
		$this->AddPage();
	// Page footer
	$this->InFooter = true;
	$this->Footer();
	$this->InFooter = false;
	// Close page
	$this->_endpage();
	// Close document
	$this->_enddoc();
}

function AddPage($orientation='', $size='', $rotation=0)
{
	// Start a new page
	if($this->state==3)
		$this->Error('The document is closed');
	$family = $this->FontFamily;
	$style = $this->FontStyle.($this->underline ? 'U' : '');
	$fontsize = $this->FontSizePt;
	$lw = $this->LineWidth;
	$dc = $this->DrawColor;
	$fc = $this->FillColor;
	$tc = $this->TextColor;
	$cf = $this->ColorFlag;
	if($this->page>0)
	{
		// Page footer
		$this->InFooter = true;
		$this->Footer();
		$this->InFooter = false;
		// Close page
		$this->_endpage();
	}
	// Start new page
	$this->_beginpage($orientation,$size,$rotation);
	// Set line cap style to square
	$this->_out('2 J');
	// Set line width
	$this->LineWidth = $lw;
	$this->_out(sprintf('%.2F w',$lw*$this->k));
	// Set font
	if($family)
		$this->SetFont($family,$style,$fontsize);
	// Set colors
	$this->DrawColor = $dc;
	if($dc!='0 G')
		$this->_out($dc);
	$this->FillColor = $fc;
	if($fc!='0 g')
		$this->_out($fc);
	$this->TextColor = $tc;
	$this->ColorFlag = $cf;
	// Page header
	$this->InHeader = true;
	$this->Header();
	$this->InHeader = false;
	// Restore line width
	if($this->LineWidth!=$lw)
	{
		$this->LineWidth = $lw;
		$this->_out(sprintf('%.2F w',$lw*$this->k));
	}
	// Restore font
	if($family)
		$this->SetFont($family,$style,$fontsize);
	// Restore colors
	if($this->DrawColor!=$dc)
	{
		$this->DrawColor = $dc;
		$this->_out($dc);
	}
	if($this->FillColor!=$fc)
	{
		$this->FillColor = $fc;
		$this->_out($fc);
	}
	$this->TextColor = $tc;
	$this->ColorFlag = $cf;
}

function Header()
{
	// To be implemented in your own inherited class
	$this->SetFont('Arial','B',16);
	$this->Cell(60,20,'',1,0,'C',$this->Image(asset(Laralum::publicPath()).'/images/sg.png',12,15,55,0));
	$this->Cell(100,20,$this->project[0]->name,1,0,'C');
	$this->Cell(30,20,'',1,1,'C',$this->Image(asset(Laralum::publicPath()).'/images/c1.png',177,13,15,0));
}

function Footer()
{
	// To be implemented in your own inherited class
	$this->SetFont('Arial','',10);
	$this->SetX(10);
	$this->Cell(10,5,'N','LTR',0,'C');
	$this->Cell(30,5,'Copyright 2016','TR',0,'C');
	$this->Cell(85,5,'Dossier Architecture Hebergement','TR',0,'C');
	$this->Cell(20,5,'Version','TR',0,'C');
	$this->Cell(35,5,'Date de redaction','TR',0,'C');
	$this->Cell(10,5,'Page','TR',0,'C');
	$this->Ln();
	$this->Cell(10,5,'XXX','LBR',0,'C');
	$this->Cell(30,5,'Societe Generale','BR',0,'C');
	$this->Cell(85,5,'DAH_FLA_v1.docx','BR',0,'C');
	$this->Cell(20,5,'1.1','BR',0,'C');
	$this->Cell(35,5,'08/09/2016','BR',0,'C');
	$this->Cell(10,5,$this->PageNo().'/{nb}','BR',0,'C');
}

function PageNo()
{
	// Get current page number
	return $this->page;
}

function SetDrawColor($r, $g=null, $b=null)
{
	// Set color for all stroking operations
	if(($r==0 && $g==0 && $b==0) || $g===null)
		$this->DrawColor = sprintf('%.3F G',$r/255);
	else
		$this->DrawColor = sprintf('%.3F %.3F %.3F RG',$r/255,$g/255,$b/255);
	if($this->page>0)
		$this->_out($this->DrawColor);
}

function SetFillColor($r, $g=null, $b=null)
{
	// Set color for all filling operations
	if(($r==0 && $g==0 && $b==0) || $g===null)
		$this->FillColor = sprintf('%.3F g',$r/255);
	else
		$this->FillColor = sprintf('%.3F %.3F %.3F rg',$r/255,$g/255,$b/255);
	$this->ColorFlag = ($this->FillColor!=$this->TextColor);
	if($this->page>0)
		$this->_out($this->FillColor);
}

function SetTextColor($r, $g=null, $b=null)
{
	// Set color for text
	if(($r==0 && $g==0 && $b==0) || $g===null)
		$this->TextColor = sprintf('%.3F g',$r/255);
	else
		$this->TextColor = sprintf('%.3F %.3F %.3F rg',$r/255,$g/255,$b/255);
	$this->ColorFlag = ($this->FillColor!=$this->TextColor);
}

function GetStringWidth($s)
{
	// Get width of a string in the current font
	$s = (string)$s;
	$cw = &$this->CurrentFont['cw'];
	$w = 0;
	$l = strlen($s);
	for($i=0;$i<$l;$i++)
		$w += $cw[$s[$i]];
	return $w*$this->FontSize/1000;
}

function SetLineWidth($width)
{
	// Set line width
	$this->LineWidth = $width;
	if($this->page>0)
		$this->_out(sprintf('%.2F w',$width*$this->k));
}

function Line($x1, $y1, $x2, $y2)
{
	// Draw a line
	$this->_out(sprintf('%.2F %.2F m %.2F %.2F l S',$x1*$this->k,($this->h-$y1)*$this->k,$x2*$this->k,($this->h-$y2)*$this->k));
}

function Rect($x, $y, $w, $h, $style='')
{
	// Draw a rectangle
	if($style=='F')
		$op = 'f';
	elseif($style=='FD' || $style=='DF')
		$op = 'B';
	else
		$op = 'S';
	$this->_out(sprintf('%.2F %.2F %.2F %.2F re %s',$x*$this->k,($this->h-$y)*$this->k,$w*$this->k,-$h*$this->k,$op));
}

function AddFont($family, $style='', $file='')
{
	// Add a TrueType, OpenType or Type1 font
	$family = strtolower($family);
	if($file=='')
		$file = str_replace(' ','',$family).strtolower($style).'.php';
	$style = strtoupper($style);
	if($style=='IB')
		$style = 'BI';
	$fontkey = $family.$style;
	if(isset($this->fonts[$fontkey]))
		return;
	$info = $this->_loadfont($file);
	$info['i'] = count($this->fonts)+1;
	if(!empty($info['file']))
	{
		// Embedded font
		if($info['type']=='TrueType')
			$this->FontFiles[$info['file']] = array('length1'=>$info['originalsize']);
		else
			$this->FontFiles[$info['file']] = array('length1'=>$info['size1'], 'length2'=>$info['size2']);
	}
	$this->fonts[$fontkey] = $info;
}

function SetFont($family, $style='', $size=0)
{
	// Select a font; size given in points
	if($family=='')
		$family = $this->FontFamily;
	else
		$family = strtolower($family);
	$style = strtoupper($style);
	if(strpos($style,'U')!==false)
	{
		$this->underline = true;
		$style = str_replace('U','',$style);
	}
	else
		$this->underline = false;
	if($style=='IB')
		$style = 'BI';
	if($size==0)
		$size = $this->FontSizePt;
	// Test if font is already selected
	if($this->FontFamily==$family && $this->FontStyle==$style && $this->FontSizePt==$size)
		return;
	// Test if font is already loaded
	$fontkey = $family.$style;
	if(!isset($this->fonts[$fontkey]))
	{
		// Test if one of the core fonts
		if($family=='arial')
			$family = 'helvetica';
		if(in_array($family,$this->CoreFonts))
		{
			if($family=='symbol' || $family=='zapfdingbats')
				$style = '';
			$fontkey = $family.$style;
			if(!isset($this->fonts[$fontkey]))
				$this->AddFont($family,$style);
		}
		else
			$this->Error('Undefined font: '.$family.' '.$style);
	}
	// Select it
	$this->FontFamily = $family;
	$this->FontStyle = $style;
	$this->FontSizePt = $size;
	$this->FontSize = $size/$this->k;
	$this->CurrentFont = &$this->fonts[$fontkey];
	if($this->page>0)
		$this->_out(sprintf('BT /F%d %.2F Tf ET',$this->CurrentFont['i'],$this->FontSizePt));
}

function SetFontSize($size)
{
	// Set font size in points
	if($this->FontSizePt==$size)
		return;
	$this->FontSizePt = $size;
	$this->FontSize = $size/$this->k;
	if($this->page>0)
		$this->_out(sprintf('BT /F%d %.2F Tf ET',$this->CurrentFont['i'],$this->FontSizePt));
}

function AddLink()
{
	// Create a new internal link
	$n = count($this->links)+1;
	$this->links[$n] = array(0, 0);
	return $n;
}

function SetLink($link, $y=0, $page=-1)
{
	// Set destination of internal link
	if($y==-1)
		$y = $this->y;
	if($page==-1)
		$page = $this->page;
	$this->links[$link] = array($page, $y);
}

function Link($x, $y, $w, $h, $link)
{
	// Put a link on the page
	$this->PageLinks[$this->page][] = array($x*$this->k, $this->hPt-$y*$this->k, $w*$this->k, $h*$this->k, $link);
}

function Text($x, $y, $txt)
{
	// Output a string
	if(!isset($this->CurrentFont))
		$this->Error('No font has been set');
	$s = sprintf('BT %.2F %.2F Td (%s) Tj ET',$x*$this->k,($this->h-$y)*$this->k,$this->_escape($txt));
	if($this->underline && $txt!='')
		$s .= ' '.$this->_dounderline($x,$y,$txt);
	if($this->ColorFlag)
		$s = 'q '.$this->TextColor.' '.$s.' Q';
	$this->_out($s);
}

function AcceptPageBreak()
{
	// Accept automatic page break or not
	return $this->AutoPageBreak;
}

function Cell($w, $h=0, $txt='', $border=0, $ln=0, $align='', $fill=false, $link='')
{
	// Output a cell
	$k = $this->k;
	if($this->y+$h>$this->PageBreakTrigger && !$this->InHeader && !$this->InFooter && $this->AcceptPageBreak())
	{
		// Automatic page break
		$x = $this->x;
		$ws = $this->ws;
		if($ws>0)
		{
			$this->ws = 0;
			$this->_out('0 Tw');
		}
		$this->AddPage($this->CurOrientation,$this->CurPageSize,$this->CurRotation);
		$this->x = $x;
		if($ws>0)
		{
			$this->ws = $ws;
			$this->_out(sprintf('%.3F Tw',$ws*$k));
		}
	}
	if($w==0)
		$w = $this->w-$this->rMargin-$this->x;
	$s = '';
	if($fill || $border==1)
	{
		if($fill)
			$op = ($border==1) ? 'B' : 'f';
		else
			$op = 'S';
		$s = sprintf('%.2F %.2F %.2F %.2F re %s ',$this->x*$k,($this->h-$this->y)*$k,$w*$k,-$h*$k,$op);
	}
	if(is_string($border))
	{
		$x = $this->x;
		$y = $this->y;
		if(strpos($border,'L')!==false)
			$s .= sprintf('%.2F %.2F m %.2F %.2F l S ',$x*$k,($this->h-$y)*$k,$x*$k,($this->h-($y+$h))*$k);
		if(strpos($border,'T')!==false)
			$s .= sprintf('%.2F %.2F m %.2F %.2F l S ',$x*$k,($this->h-$y)*$k,($x+$w)*$k,($this->h-$y)*$k);
		if(strpos($border,'R')!==false)
			$s .= sprintf('%.2F %.2F m %.2F %.2F l S ',($x+$w)*$k,($this->h-$y)*$k,($x+$w)*$k,($this->h-($y+$h))*$k);
		if(strpos($border,'B')!==false)
			$s .= sprintf('%.2F %.2F m %.2F %.2F l S ',$x*$k,($this->h-($y+$h))*$k,($x+$w)*$k,($this->h-($y+$h))*$k);
	}
	if($txt!=='')
	{
		if(!isset($this->CurrentFont))
			$this->Error('No font has been set');
		if($align=='R')
			$dx = $w-$this->cMargin-$this->GetStringWidth($txt);
		elseif($align=='C')
			$dx = ($w-$this->GetStringWidth($txt))/2;
		else
			$dx = $this->cMargin;
		if($this->ColorFlag)
			$s .= 'q '.$this->TextColor.' ';
		$s .= sprintf('BT %.2F %.2F Td (%s) Tj ET',($this->x+$dx)*$k,($this->h-($this->y+.5*$h+.3*$this->FontSize))*$k,$this->_escape($txt));
		if($this->underline)
			$s .= ' '.$this->_dounderline($this->x+$dx,$this->y+.5*$h+.3*$this->FontSize,$txt);
		if($this->ColorFlag)
			$s .= ' Q';
		if($link)
			$this->Link($this->x+$dx,$this->y+.5*$h-.5*$this->FontSize,$this->GetStringWidth($txt),$this->FontSize,$link);
	}
	if($s)
		$this->_out($s);
	$this->lasth = $h;
	if($ln>0)
	{
		// Go to next line
		$this->y += $h;
		if($ln==1)
			$this->x = $this->lMargin;
	}
	else
		$this->x += $w;
}

function MultiCell($w, $h, $txt, $border=0, $align='J', $fill=false)
{
	// Output text with automatic or explicit line breaks
	if(!isset($this->CurrentFont))
		$this->Error('No font has been set');
	$cw = &$this->CurrentFont['cw'];
	if($w==0)
		$w = $this->w-$this->rMargin-$this->x;
	$wmax = ($w-2*$this->cMargin)*1000/$this->FontSize;
	$s = str_replace("\r",'',$txt);
	$nb = strlen($s);
	if($nb>0 && $s[$nb-1]=="\n")
		$nb--;
	$b = 0;
	if($border)
	{
		if($border==1)
		{
			$border = 'LTRB';
			$b = 'LRT';
			$b2 = 'LR';
		}
		else
		{
			$b2 = '';
			if(strpos($border,'L')!==false)
				$b2 .= 'L';
			if(strpos($border,'R')!==false)
				$b2 .= 'R';
			$b = (strpos($border,'T')!==false) ? $b2.'T' : $b2;
		}
	}
	$sep = -1;
	$i = 0;
	$j = 0;
	$l = 0;
	$ns = 0;
	$nl = 1;
	while($i<$nb)
	{
		// Get next character
		$c = $s[$i];
		if($c=="\n")
		{
			// Explicit line break
			if($this->ws>0)
			{
				$this->ws = 0;
				$this->_out('0 Tw');
			}
			$this->Cell($w,$h,substr($s,$j,$i-$j),$b,2,$align,$fill);
			$i++;
			$sep = -1;
			$j = $i;
			$l = 0;
			$ns = 0;
			$nl++;
			if($border && $nl==2)
				$b = $b2;
			continue;
		}
		if($c==' ')
		{
			$sep = $i;
			$ls = $l;
			$ns++;
		}
		$l += $cw[$c];
		if($l>$wmax)
		{
			// Automatic line break
			if($sep==-1)
			{
				if($i==$j)
					$i++;
				if($this->ws>0)
				{
					$this->ws = 0;
					$this->_out('0 Tw');
				}
				$this->Cell($w,$h,substr($s,$j,$i-$j),$b,2,$align,$fill);
			}
			else
			{
				if($align=='J')
				{
					$this->ws = ($ns>1) ? ($wmax-$ls)/1000*$this->FontSize/($ns-1) : 0;
					$this->_out(sprintf('%.3F Tw',$this->ws*$this->k));
				}
				$this->Cell($w,$h,substr($s,$j,$sep-$j),$b,2,$align,$fill);
				$i = $sep+1;
			}
			$sep = -1;
			$j = $i;
			$l = 0;
			$ns = 0;
			$nl++;
			if($border && $nl==2)
				$b = $b2;
		}
		else
			$i++;
	}
	// Last chunk
	if($this->ws>0)
	{
		$this->ws = 0;
		$this->_out('0 Tw');
	}
	if($border && strpos($border,'B')!==false)
		$b .= 'B';
	$this->Cell($w,$h,substr($s,$j,$i-$j),$b,2,$align,$fill);
	$this->x = $this->lMargin;
}

function Write($h, $txt, $link='')
{
	// Output text in flowing mode
	if(!isset($this->CurrentFont))
		$this->Error('No font has been set');
	$cw = &$this->CurrentFont['cw'];
	$w = $this->w-$this->rMargin-$this->x;
	$wmax = ($w-2*$this->cMargin)*1000/$this->FontSize;
	$s = str_replace("\r",'',$txt);
	$nb = strlen($s);
	$sep = -1;
	$i = 0;
	$j = 0;
	$l = 0;
	$nl = 1;
	while($i<$nb)
	{
		// Get next character
		$c = $s[$i];
		if($c=="\n")
		{
			// Explicit line break
			$this->Cell($w,$h,substr($s,$j,$i-$j),0,2,'',false,$link);
			$i++;
			$sep = -1;
			$j = $i;
			$l = 0;
			if($nl==1)
			{
				$this->x = $this->lMargin;
				$w = $this->w-$this->rMargin-$this->x;
				$wmax = ($w-2*$this->cMargin)*1000/$this->FontSize;
			}
			$nl++;
			continue;
		}
		if($c==' ')
			$sep = $i;
		$l += $cw[$c];
		if($l>$wmax)
		{
			// Automatic line break
			if($sep==-1)
			{
				if($this->x>$this->lMargin)
				{
					// Move to next line
					$this->x = $this->lMargin;
					$this->y += $h;
					$w = $this->w-$this->rMargin-$this->x;
					$wmax = ($w-2*$this->cMargin)*1000/$this->FontSize;
					$i++;
					$nl++;
					continue;
				}
				if($i==$j)
					$i++;
				$this->Cell($w,$h,substr($s,$j,$i-$j),0,2,'',false,$link);
			}
			else
			{
				$this->Cell($w,$h,substr($s,$j,$sep-$j),0,2,'',false,$link);
				$i = $sep+1;
			}
			$sep = -1;
			$j = $i;
			$l = 0;
			if($nl==1)
			{
				$this->x = $this->lMargin;
				$w = $this->w-$this->rMargin-$this->x;
				$wmax = ($w-2*$this->cMargin)*1000/$this->FontSize;
			}
			$nl++;
		}
		else
			$i++;
	}
	// Last chunk
	if($i!=$j)
		$this->Cell($l/1000*$this->FontSize,$h,substr($s,$j),0,0,'',false,$link);
}

function Ln($h=null)
{
	// Line feed; default value is the last cell height
	$this->x = $this->lMargin;
	if($h===null)
		$this->y += $this->lasth;
	else
		$this->y += $h;
}

function Image($file, $x=null, $y=null, $w=0, $h=0, $type='', $link='')
{
	// Put an image on the page
	if($file=='')
		$this->Error('Image file name is empty');
	if(!isset($this->images[$file]))
	{
		// First use of this image, get info
		if($type=='')
		{
			$pos = strrpos($file,'.');
			if(!$pos)
				$this->Error('Image file has no extension and no type was specified: '.$file);
			$type = substr($file,$pos+1);
		}
		$type = strtolower($type);
		if($type=='jpeg')
			$type = 'jpg';
		$mtd = '_parse'.$type;
		if(!method_exists($this,$mtd))
			$this->Error('Unsupported image type: '.$type);
		$info = $this->$mtd($file);
		$info['i'] = count($this->images)+1;
		$this->images[$file] = $info;
	}
	else
		$info = $this->images[$file];

	// Automatic width and height calculation if needed
	if($w==0 && $h==0)
	{
		// Put image at 96 dpi
		$w = -96;
		$h = -96;
	}
	if($w<0)
		$w = -$info['w']*72/$w/$this->k;
	if($h<0)
		$h = -$info['h']*72/$h/$this->k;
	if($w==0)
		$w = $h*$info['w']/$info['h'];
	if($h==0)
		$h = $w*$info['h']/$info['w'];

	// Flowing mode
	if($y===null)
	{
		if($this->y+$h>$this->PageBreakTrigger && !$this->InHeader && !$this->InFooter && $this->AcceptPageBreak())
		{
			// Automatic page break
			$x2 = $this->x;
			$this->AddPage($this->CurOrientation,$this->CurPageSize,$this->CurRotation);
			$this->x = $x2;
		}
		$y = $this->y;
		$this->y += $h;
	}

	if($x===null)
		$x = $this->x;
	$this->_out(sprintf('q %.2F 0 0 %.2F %.2F %.2F cm /I%d Do Q',$w*$this->k,$h*$this->k,$x*$this->k,($this->h-($y+$h))*$this->k,$info['i']));
	if($link)
		$this->Link($x,$y,$w,$h,$link);
}

function GetPageWidth()
{
	// Get current page width
	return $this->w;
}

function GetPageHeight()
{
	// Get current page height
	return $this->h;
}

function GetX()
{
	// Get x position
	return $this->x;
}

function SetX($x)
{
	// Set x position
	if($x>=0)
		$this->x = $x;
	else
		$this->x = $this->w+$x;
}

function GetY()
{
	// Get y position
	return $this->y;
}

function SetY($y, $resetX=true)
{
	// Set y position and optionally reset x
	if($y>=0)
		$this->y = $y;
	else
		$this->y = $this->h+$y;
	if($resetX)
		$this->x = $this->lMargin;
}

function SetXY($x, $y)
{
	// Set x and y positions
	$this->SetX($x);
	$this->SetY($y,false);
}

function Output($dest='', $name='', $isUTF8=false)
{
	// Output PDF to some destination
	$this->Close();
	if(strlen($name)==1 && strlen($dest)!=1)
	{
		// Fix parameter order
		$tmp = $dest;
		$dest = $name;
		$name = $tmp;
	}
	if($dest=='')
		$dest = 'I';
	if($name=='')
		$name = 'doc.pdf';
	switch(strtoupper($dest))
	{
		case 'I':
			// Send to standard output
		$this->_checkoutput();
		if(PHP_SAPI!='cli')
		{
				// We send to a browser
			header('Content-Type: application/pdf');
			header('Content-Disposition: inline; '.$this->_httpencode('filename',$name,$isUTF8));
			header('Cache-Control: private, max-age=0, must-revalidate');
			header('Pragma: public');
		}
		echo $this->buffer;
		break;
		case 'D':
			// Download file
		$this->_checkoutput();
		header('Content-Type: application/x-download');
		header('Content-Disposition: attachment; '.$this->_httpencode('filename',$name,$isUTF8));
		header('Cache-Control: private, max-age=0, must-revalidate');
		header('Pragma: public');
		echo $this->buffer;
		break;
		case 'F':
			// Save to local file
		if(!file_put_contents($name,$this->buffer))
			$this->Error('Unable to create output file: '.$name);
		break;
		case 'S':
			// Return as a string
		return $this->buffer;
		default:
		$this->Error('Incorrect output destination: '.$dest);
	}
	return '';
}

/*******************************************************************************
*                              Protected methods                               *
*******************************************************************************/

protected function _dochecks()
{
	// Check mbstring overloading
	if(ini_get('mbstring.func_overload') & 2)
		$this->Error('mbstring overloading must be disabled');
	// Ensure runtime magic quotes are disabled
	if(get_magic_quotes_runtime())
		@set_magic_quotes_runtime(0);
}

protected function _checkoutput()
{
	if(PHP_SAPI!='cli')
	{
		if(headers_sent($file,$line))
			$this->Error("Some data has already been output, can't send PDF file (output started at $file:$line)");
	}
	if(ob_get_length())
	{
		// The output buffer is not empty
		if(preg_match('/^(\xEF\xBB\xBF)?\s*$/',ob_get_contents()))
		{
			// It contains only a UTF-8 BOM and/or whitespace, let's clean it
			ob_clean();
		}
		else
			$this->Error("Some data has already been output, can't send PDF file");
	}
}

protected function _getpagesize($size)
{
	if(is_string($size))
	{
		$size = strtolower($size);
		if(!isset($this->StdPageSizes[$size]))
			$this->Error('Unknown page size: '.$size);
		$a = $this->StdPageSizes[$size];
		return array($a[0]/$this->k, $a[1]/$this->k);
	}
	else
	{
		if($size[0]>$size[1])
			return array($size[1], $size[0]);
		else
			return $size;
	}
}

protected function _beginpage($orientation, $size, $rotation)
{
	$this->page++;
	$this->pages[$this->page] = '';
	$this->state = 2;
	$this->x = $this->lMargin;
	$this->y = $this->tMargin;
	$this->FontFamily = '';
	// Check page size and orientation
	if($orientation=='')
		$orientation = $this->DefOrientation;
	else
		$orientation = strtoupper($orientation[0]);
	if($size=='')
		$size = $this->DefPageSize;
	else
		$size = $this->_getpagesize($size);
	if($orientation!=$this->CurOrientation || $size[0]!=$this->CurPageSize[0] || $size[1]!=$this->CurPageSize[1])
	{
		// New size or orientation
		if($orientation=='P')
		{
			$this->w = $size[0];
			$this->h = $size[1];
		}
		else
		{
			$this->w = $size[1];
			$this->h = $size[0];
		}
		$this->wPt = $this->w*$this->k;
		$this->hPt = $this->h*$this->k;
		$this->PageBreakTrigger = $this->h-$this->bMargin;
		$this->CurOrientation = $orientation;
		$this->CurPageSize = $size;
	}
	if($orientation!=$this->DefOrientation || $size[0]!=$this->DefPageSize[0] || $size[1]!=$this->DefPageSize[1])
		$this->PageInfo[$this->page]['size'] = array($this->wPt, $this->hPt);
	if($rotation!=0)
	{
		if($rotation%90!=0)
			$this->Error('Incorrect rotation value: '.$rotation);
		$this->CurRotation = $rotation;
		$this->PageInfo[$this->page]['rotation'] = $rotation;
	}
}

protected function _endpage()
{
	$this->state = 1;
}

protected function _loadfont($font)
{
	// Load a font definition file from the font directory
	if(strpos($font,'/')!==false || strpos($font,"\\")!==false)
		$this->Error('Incorrect font definition file name: '.$font);
	include($this->fontpath.$font);
	if(!isset($name))
		$this->Error('Could not include font definition file');
	if(isset($enc))
		$enc = strtolower($enc);
	if(!isset($subsetted))
		$subsetted = false;
	return get_defined_vars();
}

protected function _isascii($s)
{
	// Test if string is ASCII
	$nb = strlen($s);
	for($i=0;$i<$nb;$i++)
	{
		if(ord($s[$i])>127)
			return false;
	}
	return true;
}

protected function _httpencode($param, $value, $isUTF8)
{
	// Encode HTTP header field parameter
	if($this->_isascii($value))
		return $param.'="'.$value.'"';
	if(!$isUTF8)
		$value = utf8_encode($value);
	if(strpos($_SERVER['HTTP_USER_AGENT'],'MSIE')!==false)
		return $param.'="'.rawurlencode($value).'"';
	else
		return $param."*=UTF-8''".rawurlencode($value);
}

protected function _UTF8toUTF16($s)
{
	// Convert UTF-8 to UTF-16BE with BOM
	$res = "\xFE\xFF";
	$nb = strlen($s);
	$i = 0;
	while($i<$nb)
	{
		$c1 = ord($s[$i++]);
		if($c1>=224)
		{
			// 3-byte character
			$c2 = ord($s[$i++]);
			$c3 = ord($s[$i++]);
			$res .= chr((($c1 & 0x0F)<<4) + (($c2 & 0x3C)>>2));
			$res .= chr((($c2 & 0x03)<<6) + ($c3 & 0x3F));
		}
		elseif($c1>=192)
		{
			// 2-byte character
			$c2 = ord($s[$i++]);
			$res .= chr(($c1 & 0x1C)>>2);
			$res .= chr((($c1 & 0x03)<<6) + ($c2 & 0x3F));
		}
		else
		{
			// Single-byte character
			$res .= "\0".chr($c1);
		}
	}
	return $res;
}

protected function _escape($s)
{
	// Escape special characters
	if(strpos($s,'(')!==false || strpos($s,')')!==false || strpos($s,'\\')!==false || strpos($s,"\r")!==false)
		return str_replace(array('\\','(',')',"\r"), array('\\\\','\\(','\\)','\\r'), $s);
	else
		return $s;
}

protected function _textstring($s)
{
	// Format a text string
	if(!$this->_isascii($s))
		$s = $this->_UTF8toUTF16($s);
	return '('.$this->_escape($s).')';
}

protected function _dounderline($x, $y, $txt)
{
	// Underline text
	$up = $this->CurrentFont['up'];
	$ut = $this->CurrentFont['ut'];
	$w = $this->GetStringWidth($txt)+$this->ws*substr_count($txt,' ');
	return sprintf('%.2F %.2F %.2F %.2F re f',$x*$this->k,($this->h-($y-$up/1000*$this->FontSize))*$this->k,$w*$this->k,-$ut/1000*$this->FontSizePt);
}

protected function _parsejpg($file)
{
	// Extract info from a JPEG file
	$a = getimagesize($file);
	if(!$a)
		$this->Error('Missing or incorrect image file: '.$file);
	if($a[2]!=2)
		$this->Error('Not a JPEG file: '.$file);
	if(!isset($a['channels']) || $a['channels']==3)
		$colspace = 'DeviceRGB';
	elseif($a['channels']==4)
		$colspace = 'DeviceCMYK';
	else
		$colspace = 'DeviceGray';
	$bpc = isset($a['bits']) ? $a['bits'] : 8;
	$data = file_get_contents($file);
	return array('w'=>$a[0], 'h'=>$a[1], 'cs'=>$colspace, 'bpc'=>$bpc, 'f'=>'DCTDecode', 'data'=>$data);
}

protected function _parsepng($file)
{
	// Extract info from a PNG file
	$f = fopen($file,'rb');
	if(!$f)
		$this->Error('Can\'t open image file: '.$file);
	$info = $this->_parsepngstream($f,$file);
	fclose($f);
	return $info;
}

protected function _parsepngstream($f, $file)
{
	// Check signature
	if($this->_readstream($f,8)!=chr(137).'PNG'.chr(13).chr(10).chr(26).chr(10))
		$this->Error('Not a PNG file: '.$file);

	// Read header chunk
	$this->_readstream($f,4);
	if($this->_readstream($f,4)!='IHDR')
		$this->Error('Incorrect PNG file: '.$file);
	$w = $this->_readint($f);
	$h = $this->_readint($f);
	$bpc = ord($this->_readstream($f,1));
	if($bpc>8)
		$this->Error('16-bit depth not supported: '.$file);
	$ct = ord($this->_readstream($f,1));
	if($ct==0 || $ct==4)
		$colspace = 'DeviceGray';
	elseif($ct==2 || $ct==6)
		$colspace = 'DeviceRGB';
	elseif($ct==3)
		$colspace = 'Indexed';
	else
		$this->Error('Unknown color type: '.$file);
	if(ord($this->_readstream($f,1))!=0)
		$this->Error('Unknown compression method: '.$file);
	if(ord($this->_readstream($f,1))!=0)
		$this->Error('Unknown filter method: '.$file);
	if(ord($this->_readstream($f,1))!=0)
		$this->Error('Interlacing not supported: '.$file);
	$this->_readstream($f,4);
	$dp = '/Predictor 15 /Colors '.($colspace=='DeviceRGB' ? 3 : 1).' /BitsPerComponent '.$bpc.' /Columns '.$w;

	// Scan chunks looking for palette, transparency and image data
	$pal = '';
	$trns = '';
	$data = '';
	do
	{
		$n = $this->_readint($f);
		$type = $this->_readstream($f,4);
		if($type=='PLTE')
		{
			// Read palette
			$pal = $this->_readstream($f,$n);
			$this->_readstream($f,4);
		}
		elseif($type=='tRNS')
		{
			// Read transparency info
			$t = $this->_readstream($f,$n);
			if($ct==0)
				$trns = array(ord(substr($t,1,1)));
			elseif($ct==2)
				$trns = array(ord(substr($t,1,1)), ord(substr($t,3,1)), ord(substr($t,5,1)));
			else
			{
				$pos = strpos($t,chr(0));
				if($pos!==false)
					$trns = array($pos);
			}
			$this->_readstream($f,4);
		}
		elseif($type=='IDAT')
		{
			// Read image data block
			$data .= $this->_readstream($f,$n);
			$this->_readstream($f,4);
		}
		elseif($type=='IEND')
			break;
		else
			$this->_readstream($f,$n+4);
	}
	while($n);

	if($colspace=='Indexed' && empty($pal))
		$this->Error('Missing palette in '.$file);
	$info = array('w'=>$w, 'h'=>$h, 'cs'=>$colspace, 'bpc'=>$bpc, 'f'=>'FlateDecode', 'dp'=>$dp, 'pal'=>$pal, 'trns'=>$trns);
	if($ct>=4)
	{
		// Extract alpha channel
		if(!function_exists('gzuncompress'))
			$this->Error('Zlib not available, can\'t handle alpha channel: '.$file);
		$data = gzuncompress($data);
		$color = '';
		$alpha = '';
		if($ct==4)
		{
			// Gray image
			$len = 2*$w;
			for($i=0;$i<$h;$i++)
			{
				$pos = (1+$len)*$i;
				$color .= $data[$pos];
				$alpha .= $data[$pos];
				$line = substr($data,$pos+1,$len);
				$color .= preg_replace('/(.)./s','$1',$line);
				$alpha .= preg_replace('/.(.)/s','$1',$line);
			}
		}
		else
		{
			// RGB image
			$len = 4*$w;
			for($i=0;$i<$h;$i++)
			{
				$pos = (1+$len)*$i;
				$color .= $data[$pos];
				$alpha .= $data[$pos];
				$line = substr($data,$pos+1,$len);
				$color .= preg_replace('/(.{3})./s','$1',$line);
				$alpha .= preg_replace('/.{3}(.)/s','$1',$line);
			}
		}
		unset($data);
		$data = gzcompress($color);
		$info['smask'] = gzcompress($alpha);
		$this->WithAlpha = true;
		if($this->PDFVersion<'1.4')
			$this->PDFVersion = '1.4';
	}
	$info['data'] = $data;
	return $info;
}

protected function _readstream($f, $n)
{
	// Read n bytes from stream
	$res = '';
	while($n>0 && !feof($f))
	{
		$s = fread($f,$n);
		if($s===false)
			$this->Error('Error while reading stream');
		$n -= strlen($s);
		$res .= $s;
	}
	if($n>0)
		$this->Error('Unexpected end of stream');
	return $res;
}

protected function _readint($f)
{
	// Read a 4-byte integer from stream
	$a = unpack('Ni',$this->_readstream($f,4));
	return $a['i'];
}

protected function _parsegif($file)
{
	// Extract info from a GIF file (via PNG conversion)
	if(!function_exists('imagepng'))
		$this->Error('GD extension is required for GIF support');
	if(!function_exists('imagecreatefromgif'))
		$this->Error('GD has no GIF read support');
	$im = imagecreatefromgif($file);
	if(!$im)
		$this->Error('Missing or incorrect image file: '.$file);
	imageinterlace($im,0);
	ob_start();
	imagepng($im);
	$data = ob_get_clean();
	imagedestroy($im);
	$f = fopen('php://temp','rb+');
	if(!$f)
		$this->Error('Unable to create memory stream');
	fwrite($f,$data);
	rewind($f);
	$info = $this->_parsepngstream($f,$file);
	fclose($f);
	return $info;
}

protected function _out($s)
{
	// Add a line to the document
	if($this->state==2)
		$this->pages[$this->page] .= $s."\n";
	elseif($this->state==1)
		$this->_put($s);
	elseif($this->state==0)
		$this->Error('No page has been added yet');
	elseif($this->state==3)
		$this->Error('The document is closed');
}

protected function _put($s)
{
	$this->buffer .= $s."\n";
}

protected function _getoffset()
{
	return strlen($this->buffer);
}

protected function _newobj($n=null)
{
	// Begin a new object
	if($n===null)
		$n = ++$this->n;
	$this->offsets[$n] = $this->_getoffset();
	$this->_put($n.' 0 obj');
}

protected function _putstream($data)
{
	$this->_put('stream');
	$this->_put($data);
	$this->_put('endstream');
}

protected function _putstreamobject($data)
{
	if($this->compress)
	{
		$entries = '/Filter /FlateDecode ';
		$data = gzcompress($data);
	}
	else
		$entries = '';
	$entries .= '/Length '.strlen($data);
	$this->_newobj();
	$this->_put('<<'.$entries.'>>');
	$this->_putstream($data);
	$this->_put('endobj');
}

protected function _putpage($n)
{
	$this->_newobj();
	$this->_put('<</Type /Page');
	$this->_put('/Parent 1 0 R');
	if(isset($this->PageInfo[$n]['size']))
		$this->_put(sprintf('/MediaBox [0 0 %.2F %.2F]',$this->PageInfo[$n]['size'][0],$this->PageInfo[$n]['size'][1]));
	if(isset($this->PageInfo[$n]['rotation']))
		$this->_put('/Rotate '.$this->PageInfo[$n]['rotation']);
	$this->_put('/Resources 2 0 R');
	if(isset($this->PageLinks[$n]))
	{
		// Links
		$annots = '/Annots [';
		foreach($this->PageLinks[$n] as $pl)
		{
			$rect = sprintf('%.2F %.2F %.2F %.2F',$pl[0],$pl[1],$pl[0]+$pl[2],$pl[1]-$pl[3]);
			$annots .= '<</Type /Annot /Subtype /Link /Rect ['.$rect.'] /Border [0 0 0] ';
			if(is_string($pl[4]))
				$annots .= '/A <</S /URI /URI '.$this->_textstring($pl[4]).'>>>>';
			else
			{
				$l = $this->links[$pl[4]];
				if(isset($this->PageInfo[$l[0]]['size']))
					$h = $this->PageInfo[$l[0]]['size'][1];
				else
					$h = ($this->DefOrientation=='P') ? $this->DefPageSize[1]*$this->k : $this->DefPageSize[0]*$this->k;
				$annots .= sprintf('/Dest [%d 0 R /XYZ 0 %.2F null]>>',$this->PageInfo[$l[0]]['n'],$h-$l[1]*$this->k);
			}
		}
		$this->_put($annots.']');
	}
	if($this->WithAlpha)
		$this->_put('/Group <</Type /Group /S /Transparency /CS /DeviceRGB>>');
	$this->_put('/Contents '.($this->n+1).' 0 R>>');
	$this->_put('endobj');
	// Page content
	if(!empty($this->AliasNbPages))
		$this->pages[$n] = str_replace($this->AliasNbPages,$this->page,$this->pages[$n]);
	$this->_putstreamobject($this->pages[$n]);
}

protected function _putpages()
{
	$nb = $this->page;
	for($n=1;$n<=$nb;$n++)
		$this->PageInfo[$n]['n'] = $this->n+1+2*($n-1);
	for($n=1;$n<=$nb;$n++)
		$this->_putpage($n);
	// Pages root
	$this->_newobj(1);
	$this->_put('<</Type /Pages');
	$kids = '/Kids [';
	for($n=1;$n<=$nb;$n++)
		$kids .= $this->PageInfo[$n]['n'].' 0 R ';
	$this->_put($kids.']');
	$this->_put('/Count '.$nb);
	if($this->DefOrientation=='P')
	{
		$w = $this->DefPageSize[0];
		$h = $this->DefPageSize[1];
	}
	else
	{
		$w = $this->DefPageSize[1];
		$h = $this->DefPageSize[0];
	}
	$this->_put(sprintf('/MediaBox [0 0 %.2F %.2F]',$w*$this->k,$h*$this->k));
	$this->_put('>>');
	$this->_put('endobj');
}

protected function _putfonts()
{
	foreach($this->FontFiles as $file=>$info)
	{
		// Font file embedding
		$this->_newobj();
		$this->FontFiles[$file]['n'] = $this->n;
		$font = file_get_contents($this->fontpath.$file,true);
		if(!$font)
			$this->Error('Font file not found: '.$file);
		$compressed = (substr($file,-2)=='.z');
		if(!$compressed && isset($info['length2']))
			$font = substr($font,6,$info['length1']).substr($font,6+$info['length1']+6,$info['length2']);
		$this->_put('<</Length '.strlen($font));
		if($compressed)
			$this->_put('/Filter /FlateDecode');
		$this->_put('/Length1 '.$info['length1']);
		if(isset($info['length2']))
			$this->_put('/Length2 '.$info['length2'].' /Length3 0');
		$this->_put('>>');
		$this->_putstream($font);
		$this->_put('endobj');
	}
	foreach($this->fonts as $k=>$font)
	{
		// Encoding
		if(isset($font['diff']))
		{
			if(!isset($this->encodings[$font['enc']]))
			{
				$this->_newobj();
				$this->_put('<</Type /Encoding /BaseEncoding /WinAnsiEncoding /Differences ['.$font['diff'].']>>');
				$this->_put('endobj');
				$this->encodings[$font['enc']] = $this->n;
			}
		}
		// ToUnicode CMap
		if(isset($font['uv']))
		{
			if(isset($font['enc']))
				$cmapkey = $font['enc'];
			else
				$cmapkey = $font['name'];
			if(!isset($this->cmaps[$cmapkey]))
			{
				$cmap = $this->_tounicodecmap($font['uv']);
				$this->_putstreamobject($cmap);
				$this->cmaps[$cmapkey] = $this->n;
			}
		}
		// Font object
		$this->fonts[$k]['n'] = $this->n+1;
		$type = $font['type'];
		$name = $font['name'];
		if($font['subsetted'])
			$name = 'AAAAAA+'.$name;
		if($type=='Core')
		{
			// Core font
			$this->_newobj();
			$this->_put('<</Type /Font');
			$this->_put('/BaseFont /'.$name);
			$this->_put('/Subtype /Type1');
			if($name!='Symbol' && $name!='ZapfDingbats')
				$this->_put('/Encoding /WinAnsiEncoding');
			if(isset($font['uv']))
				$this->_put('/ToUnicode '.$this->cmaps[$cmapkey].' 0 R');
			$this->_put('>>');
			$this->_put('endobj');
		}
		elseif($type=='Type1' || $type=='TrueType')
		{
			// Additional Type1 or TrueType/OpenType font
			$this->_newobj();
			$this->_put('<</Type /Font');
			$this->_put('/BaseFont /'.$name);
			$this->_put('/Subtype /'.$type);
			$this->_put('/FirstChar 32 /LastChar 255');
			$this->_put('/Widths '.($this->n+1).' 0 R');
			$this->_put('/FontDescriptor '.($this->n+2).' 0 R');
			if(isset($font['diff']))
				$this->_put('/Encoding '.$this->encodings[$font['enc']].' 0 R');
			else
				$this->_put('/Encoding /WinAnsiEncoding');
			if(isset($font['uv']))
				$this->_put('/ToUnicode '.$this->cmaps[$cmapkey].' 0 R');
			$this->_put('>>');
			$this->_put('endobj');
			// Widths
			$this->_newobj();
			$cw = &$font['cw'];
			$s = '[';
			for($i=32;$i<=255;$i++)
				$s .= $cw[chr($i)].' ';
			$this->_put($s.']');
			$this->_put('endobj');
			// Descriptor
			$this->_newobj();
			$s = '<</Type /FontDescriptor /FontName /'.$name;
			foreach($font['desc'] as $k=>$v)
				$s .= ' /'.$k.' '.$v;
			if(!empty($font['file']))
				$s .= ' /FontFile'.($type=='Type1' ? '' : '2').' '.$this->FontFiles[$font['file']]['n'].' 0 R';
			$this->_put($s.'>>');
			$this->_put('endobj');
		}
		else
		{
			// Allow for additional types
			$mtd = '_put'.strtolower($type);
			if(!method_exists($this,$mtd))
				$this->Error('Unsupported font type: '.$type);
			$this->$mtd($font);
		}
	}
}

protected function _tounicodecmap($uv)
{
	$ranges = '';
	$nbr = 0;
	$chars = '';
	$nbc = 0;
	foreach($uv as $c=>$v)
	{
		if(is_array($v))
		{
			$ranges .= sprintf("<%02X> <%02X> <%04X>\n",$c,$c+$v[1]-1,$v[0]);
			$nbr++;
		}
		else
		{
			$chars .= sprintf("<%02X> <%04X>\n",$c,$v);
			$nbc++;
		}
	}
	$s = "/CIDInit /ProcSet findresource begin\n";
	$s .= "12 dict begin\n";
	$s .= "begincmap\n";
	$s .= "/CIDSystemInfo\n";
	$s .= "<</Registry (Adobe)\n";
	$s .= "/Ordering (UCS)\n";
	$s .= "/Supplement 0\n";
	$s .= ">> def\n";
	$s .= "/CMapName /Adobe-Identity-UCS def\n";
	$s .= "/CMapType 2 def\n";
	$s .= "1 begincodespacerange\n";
	$s .= "<00> <FF>\n";
	$s .= "endcodespacerange\n";
	if($nbr>0)
	{
		$s .= "$nbr beginbfrange\n";
		$s .= $ranges;
		$s .= "endbfrange\n";
	}
	if($nbc>0)
	{
		$s .= "$nbc beginbfchar\n";
		$s .= $chars;
		$s .= "endbfchar\n";
	}
	$s .= "endcmap\n";
	$s .= "CMapName currentdict /CMap defineresource pop\n";
	$s .= "end\n";
	$s .= "end";
	return $s;
}

protected function _putimages()
{
	foreach(array_keys($this->images) as $file)
	{
		$this->_putimage($this->images[$file]);
		unset($this->images[$file]['data']);
		unset($this->images[$file]['smask']);
	}
}

protected function _putimage(&$info)
{
	$this->_newobj();
	$info['n'] = $this->n;
	$this->_put('<</Type /XObject');
	$this->_put('/Subtype /Image');
	$this->_put('/Width '.$info['w']);
	$this->_put('/Height '.$info['h']);
	if($info['cs']=='Indexed')
		$this->_put('/ColorSpace [/Indexed /DeviceRGB '.(strlen($info['pal'])/3-1).' '.($this->n+1).' 0 R]');
	else
	{
		$this->_put('/ColorSpace /'.$info['cs']);
		if($info['cs']=='DeviceCMYK')
			$this->_put('/Decode [1 0 1 0 1 0 1 0]');
	}
	$this->_put('/BitsPerComponent '.$info['bpc']);
	if(isset($info['f']))
		$this->_put('/Filter /'.$info['f']);
	if(isset($info['dp']))
		$this->_put('/DecodeParms <<'.$info['dp'].'>>');
	if(isset($info['trns']) && is_array($info['trns']))
	{
		$trns = '';
		for($i=0;$i<count($info['trns']);$i++)
			$trns .= $info['trns'][$i].' '.$info['trns'][$i].' ';
		$this->_put('/Mask ['.$trns.']');
	}
	if(isset($info['smask']))
		$this->_put('/SMask '.($this->n+1).' 0 R');
	$this->_put('/Length '.strlen($info['data']).'>>');
	$this->_putstream($info['data']);
	$this->_put('endobj');
	// Soft mask
	if(isset($info['smask']))
	{
		$dp = '/Predictor 15 /Colors 1 /BitsPerComponent 8 /Columns '.$info['w'];
		$smask = array('w'=>$info['w'], 'h'=>$info['h'], 'cs'=>'DeviceGray', 'bpc'=>8, 'f'=>$info['f'], 'dp'=>$dp, 'data'=>$info['smask']);
		$this->_putimage($smask);
	}
	// Palette
	if($info['cs']=='Indexed')
		$this->_putstreamobject($info['pal']);
}

protected function _putxobjectdict()
{
	foreach($this->images as $image)
		$this->_put('/I'.$image['i'].' '.$image['n'].' 0 R');
}

protected function _putresourcedict()
{
	$this->_put('/ProcSet [/PDF /Text /ImageB /ImageC /ImageI]');
	$this->_put('/Font <<');
	foreach($this->fonts as $font)
		$this->_put('/F'.$font['i'].' '.$font['n'].' 0 R');
	$this->_put('>>');
	$this->_put('/XObject <<');
	$this->_putxobjectdict();
	$this->_put('>>');
}

protected function _putresources()
{
	$this->_putfonts();
	$this->_putimages();
	// Resource dictionary
	$this->_newobj(2);
	$this->_put('<<');
	$this->_putresourcedict();
	$this->_put('>>');
	$this->_put('endobj');
}

protected function _putinfo()
{
	$this->metadata['Producer'] = 'FPDF '.FPDF_VERSION;
	$this->metadata['CreationDate'] = 'D:'.@date('YmdHis');
	foreach($this->metadata as $key=>$value)
		$this->_put('/'.$key.' '.$this->_textstring($value));
}

protected function _putcatalog()
{
	$n = $this->PageInfo[1]['n'];
	$this->_put('/Type /Catalog');
	$this->_put('/Pages 1 0 R');
	if($this->ZoomMode=='fullpage')
		$this->_put('/OpenAction ['.$n.' 0 R /Fit]');
	elseif($this->ZoomMode=='fullwidth')
		$this->_put('/OpenAction ['.$n.' 0 R /FitH null]');
	elseif($this->ZoomMode=='real')
		$this->_put('/OpenAction ['.$n.' 0 R /XYZ null null 1]');
	elseif(!is_string($this->ZoomMode))
		$this->_put('/OpenAction ['.$n.' 0 R /XYZ null null '.sprintf('%.2F',$this->ZoomMode/100).']');
	if($this->LayoutMode=='single')
		$this->_put('/PageLayout /SinglePage');
	elseif($this->LayoutMode=='continuous')
		$this->_put('/PageLayout /OneColumn');
	elseif($this->LayoutMode=='two')
		$this->_put('/PageLayout /TwoColumnLeft');
}

protected function _putheader()
{
	$this->_put('%PDF-'.$this->PDFVersion);
}

protected function _puttrailer()
{
	$this->_put('/Size '.($this->n+1));
	$this->_put('/Root '.$this->n.' 0 R');
	$this->_put('/Info '.($this->n-1).' 0 R');
}

protected function _enddoc()
{
	$this->_putheader();
	$this->_putpages();
	$this->_putresources();
	// Info
	$this->_newobj();
	$this->_put('<<');
	$this->_putinfo();
	$this->_put('>>');
	$this->_put('endobj');
	// Catalog
	$this->_newobj();
	$this->_put('<<');
	$this->_putcatalog();
	$this->_put('>>');
	$this->_put('endobj');
	// Cross-ref
	$offset = $this->_getoffset();
	$this->_put('xref');
	$this->_put('0 '.($this->n+1));
	$this->_put('0000000000 65535 f ');
	for($i=1;$i<=$this->n;$i++)
		$this->_put(sprintf('%010d 00000 n ',$this->offsets[$i]));
	// Trailer
	$this->_put('trailer');
	$this->_put('<<');
	$this->_puttrailer();
	$this->_put('>>');
	$this->_put('startxref');
	$this->_put($offset);
	$this->_put('%%EOF');
	$this->state = 3;
}
}


class HtmlParser {

    /**
     * Field iNodeType.
     * May be one of the NODE_TYPE_* constants above.
     */
    public $iNodeType;

    /**
     * Field iNodeName.
     * For elements, it's the name of the element.
     */
    public $iNodeName = "";

    /**
     * Field iNodeValue.
     * For text nodes, it's the text.
     */
    public $iNodeValue = "";

    /**
     * Field iNodeAttributes.
     * A string-indexed array containing attribute values
     * of the current node. Indexes are always lowercase.
     */
    public $iNodeAttributes;

    // The following fields are private:

    private $iHtmlText;
    private $iHtmlTextLength;
    private $iHtmlTextIndex = 0;
    private $iHtmlCurrentChar;
    private $BOE_ARRAY;
    private $B_ARRAY;
    private $BOS_ARRAY;
    
    /**
     * Constructor.
     * Constructs an HtmlParser instance with
     * the HTML text given.
     */
    function __construct ($aHtmlText) {
    	$this->iHtmlText = $aHtmlText;
    	$this->iHtmlTextLength = strlen($aHtmlText);
    	$this->iNodeAttributes = array();
    	$this->setTextIndex (0);

    	$this->BOE_ARRAY = array (" ", "\t", "\r", "\n", "=" );
    	$this->B_ARRAY = array (" ", "\t", "\r", "\n" );
    	$this->BOS_ARRAY = array (" ", "\t", "\r", "\n", "/" );
    }

    /**
     * Method parse.
     * Parses the next node. Returns false only if
     * the end of the HTML text has been reached.
     * Updates values of iNode* fields.
     */
    function parse() {
    	$text = $this->skipToElement();
    	if ($text != "") {
    		$this->iNodeType = NODE_TYPE_TEXT;
    		$this->iNodeName = "Text";
    		$this->iNodeValue = $text;
    		return true;
    	}
    	return $this->readTag();
    }

    function clearAttributes() {
    	$this->iNodeAttributes = array();
    }

    function readTag() {
    	if ($this->iCurrentChar != "<") {
    		$this->iNodeType = NODE_TYPE_DONE;
    		return false;
    	}
    	$this->clearAttributes();
    	$this->skipMaxInTag ("<", 1);
    	if ($this->iCurrentChar == '/') {
    		$this->moveNext();
    		$name = $this->skipToBlanksInTag();
    		$this->iNodeType = NODE_TYPE_ENDELEMENT;
    		$this->iNodeName = $name;
    		$this->iNodeValue = "";            
    		$this->skipEndOfTag();
    		return true;
    	}
    	$name = $this->skipToBlanksOrSlashInTag();
    	if (!$this->isValidTagIdentifier ($name)) {
    		$comment = false;
    		if (strpos($name, "!--") === 0) {
    			$ppos = strpos($name, "--", 3);
    			if (strpos($name, "--", 3) === (strlen($name) - 2)) {
    				$this->iNodeType = NODE_TYPE_COMMENT;
    				$this->iNodeName = "Comment";
    				$this->iNodeValue = "<" . $name . ">";
    				$comment = true;                        
    			}
    			else {
    				$rest = $this->skipToStringInTag ("-->");    
    				if ($rest != "") {
    					$this->iNodeType = NODE_TYPE_COMMENT;
    					$this->iNodeName = "Comment";
    					$this->iNodeValue = "<" . $name . $rest;
    					$comment = true;
                            // Already skipped end of tag
    					return true;
    				}
    			}
    		}
    		if (!$comment) {
    			$this->iNodeType = NODE_TYPE_TEXT;
    			$this->iNodeName = "Text";
    			$this->iNodeValue = "<" . $name;
    			return true;
    		}
    	}
    	else {
    		$this->iNodeType = NODE_TYPE_ELEMENT;
    		$this->iNodeValue = "";
    		$this->iNodeName = $name;
    		while ($this->skipBlanksInTag()) {
    			$attrName = $this->skipToBlanksOrEqualsInTag();
    			if ($attrName != "" && $attrName != "/") {
    				$this->skipBlanksInTag();
    				if ($this->iCurrentChar == "=") {
    					$this->skipEqualsInTag();
    					$this->skipBlanksInTag();
    					$value = $this->readValueInTag();
    					$this->iNodeAttributes[strtolower($attrName)] = $value;
    				}
    				else {
    					$this->iNodeAttributes[strtolower($attrName)] = "";
    				}
    			}
    		}
    	}
    	$this->skipEndOfTag();
    	return true;            
    }

    function isValidTagIdentifier ($name) {
    	return preg_match ("/^[A-Za-z0-9_\\-]+$/", $name);
    }
    
    function skipBlanksInTag() {
    	return "" != ($this->skipInTag ($this->B_ARRAY));
    }

    function skipToBlanksOrEqualsInTag() {
    	return $this->skipToInTag ($this->BOE_ARRAY);
    }

    function skipToBlanksInTag() {
    	return $this->skipToInTag ($this->B_ARRAY);
    }

    function skipToBlanksOrSlashInTag() {
    	return $this->skipToInTag ($this->BOS_ARRAY);
    }

    function skipEqualsInTag() {
    	return $this->skipMaxInTag ("=", 1);
    }

    function readValueInTag() {
    	$ch = $this->iCurrentChar;
    	$value = "";
    	if ($ch == "\"") {
    		$this->skipMaxInTag ("\"", 1);
    		$value = $this->skipToInTag ("\"");
    		$this->skipMaxInTag ("\"", 1);
    	}
    	else if ($ch == "'") {
    		$this->skipMaxInTag ("'", 1);
    		$value = $this->skipToInTag ("'");
    		$this->skipMaxInTag ("'", 1);
    	}                
    	else {
    		$value = $this->skipToBlanksInTag();
    	}
    	return $value;
    }

    function setTextIndex ($index) {
    	$this->iHtmlTextIndex = $index;
    	if ($index >= $this->iHtmlTextLength) {
    		$this->iCurrentChar = -1;
    	}
    	else {
    		$this->iCurrentChar = $this->iHtmlText{$index};
    	}
    }

    function moveNext() {
    	if ($this->iHtmlTextIndex < $this->iHtmlTextLength) {
    		$this->setTextIndex ($this->iHtmlTextIndex + 1);
    		return true;
    	}
    	else {
    		return false;
    	}
    }

    function skipEndOfTag() {
    	while (($ch = $this->iCurrentChar) !== -1) {
    		if ($ch == ">") {
    			$this->moveNext();
    			return;
    		}
    		$this->moveNext();
    	}
    }

    function skipInTag ($chars) {
    	$sb = "";
    	while (($ch = $this->iCurrentChar) !== -1) {
    		if ($ch == ">") {
    			return $sb;
    		} else {
    			$match = false;
    			for ($idx = 0; $idx < count($chars); $idx++) {
    				if ($ch == $chars[$idx]) {
    					$match = true;
    					break;
    				}
    			}
    			if (!$match) {
    				return $sb;
    			}
    			$sb .= $ch;
    			$this->moveNext();
    		}
    	}
    	return $sb;
    }

    function skipMaxInTag ($chars, $maxChars) {
    	$sb = "";
    	$count = 0;
    	while (($ch = $this->iCurrentChar) !== -1 && $count++ < $maxChars) {
    		if ($ch == ">") {
    			return $sb;
    		} else {
    			$match = false;
    			for ($idx = 0; $idx < count($chars); $idx++) {
    				if ($ch == $chars[$idx]) {
    					$match = true;
    					break;
    				}
    			}
    			if (!$match) {
    				return $sb;
    			}
    			$sb .= $ch;
    			$this->moveNext();
    		}
    	}
    	return $sb;
    }

    function skipToInTag ($chars) {
    	$sb = "";
    	while (($ch = $this->iCurrentChar) !== -1) {
    		$match = $ch == ">";
    		if (!$match) {
    			for ($idx = 0; $idx < count($chars); $idx++) {
    				if ($ch == $chars[$idx]) {
    					$match = true;
    					break;
    				}
    			}
    		}
    		if ($match) {
    			return $sb;
    		}
    		$sb .= $ch;
    		$this->moveNext();
    	}
    	return $sb;
    }

    function skipToElement() {
    	$sb = "";
    	while (($ch = $this->iCurrentChar) !== -1) {
    		if ($ch == "<") {
    			return $sb;
    		}
    		$sb .= $ch;
    		$this->moveNext();
    	}
    	return $sb;             
    }

    /**
     * Returns text between current position and $needle,
     * inclusive, or "" if not found. The current index is moved to a point
     * after the location of $needle, or not moved at all
     * if nothing is found.
     */
    function skipToStringInTag ($needle) {
    	$pos = strpos ($this->iHtmlText, $needle, $this->iHtmlTextIndex);
    	if ($pos === false) {
    		return "";
    	}
    	$top = $pos + strlen($needle);
    	$retvalue = substr ($this->iHtmlText, $this->iHtmlTextIndex, $top - $this->iHtmlTextIndex);
    	$this->setTextIndex ($top);
    	return $retvalue;
    }
}

function HtmlParser_ForFile ($fileName) { 
	return HtmlParser_ForURL($fileName);
}

function HtmlParser_ForURL ($url) {
	$fp = fopen ($url, "r");
	$content = "";
	while (true) {
		$data = fread ($fp, 8192);
		if (strlen($data) == 0) {
			break;
		}
		$content .= $data;
	}
	fclose ($fp);
	return new HtmlParser ($content);
}



?>
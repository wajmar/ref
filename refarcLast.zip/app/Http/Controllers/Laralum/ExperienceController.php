<?php 

namespace App\Http\Controllers\Laralum;

use Illuminate\Http\Request;

use App\Htpp\Requests;
use App\Http\Controllers\Controller;
use App\Experience;

class ExperienceController extends Controller{

	public function index(Request $request){

		$exps = Laralum::experience();
		return view('laralum/experience/index',['exps' => $exps]);
	}

	public function admin(Request $request){
		$exps = Laralum::experiences_all();
		return view('laralum/experience/admin',['exps'=>$exps]);
	}

	public function add_report(Request $request){

		$exp = new Experience();
		$request['id_user'] = Laralum::loggedInUser()->id;

		$wishdate = explode('/',$request->wishdate_report);
		$request['wishdate'] = $wishdate[2].'-'.$wishdate[0].'-'.$wishdate[1];

		$exp = $exp->add_report($request);

		//	Recuperation de tous les reports de l'utilisateur courant
		$exps = Laralum::experience();

		return view('laralum/experience/index',['exps' => $exps]);
	}

	public function edit_report(Request $request){
		$exp = Experience::where('id',$request->id)->first();
		$exp->page = $request->page_report;
		$exp->type = $request->type_report;
		$exp->criticite = $request->criticite_report;
		$wishdate = explode('/',$request->wishdate_report);
		$request['wishdate_report'] = $wishdate[2].'-'.$wishdate[0].'-'.$wishdate[1];
		$exp->wished_at = $request->wishdate_report;
		$exp->comment = $request->comment_report;
		$exp->save();

		//	Recuperation de tous les reports de l'utilisateur courant
		$exps = Laralum::experience();

		return view('laralum/experience/exps_list',['exps' => $exps]);
	}

	public function delete(Request $request){
		$exp = Experience::where('id',$request->id);
		$exp->delete();

		//	Recuperation de tous les reports de l'utilisateur courant
		if($request->type_del == 'admin'){
			$exps = Laralum::experiences_all();
			return view('laralum/experience/exps_list_admin',['exps' => $exps]);
		}
		else{
			$exps = Laralum::experience();
			return view('laralum/experience/exps_list',['exps' => $exps]);
		}
	}

	public function edit(Request $request){
		$exp = new Experience();
		// Mise en forme de la date
		$date_retexp = explode('/',$request->date_retexp);
		$request['date_retexp'] = $date_retexp[2].'-'.$date_retexp[0].'-'.$date_retexp[1];

		$exp = $exp->edit($request);
		$exps = Laralum::experiences_all();
		return view('laralum/experience/admin',['exps'=>$exps]);
	}

}

?>
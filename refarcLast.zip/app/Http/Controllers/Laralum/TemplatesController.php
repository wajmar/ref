<?php

namespace App\Http\Controllers\Laralum;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Templates;
use App\TemplatesParams;
use App\TemplatesInterv;
use App\TemplatesDiff;
use App\Pictures;
use App\TypeTpl;
use Laralum;
use Storage;
use File;

class TemplatesController extends Controller
{
    /**
     * [index description]
     * @return [type] [description]
     */
    public function suivi($id)
    {
        # Check projects permissions
        Laralum::permissionToAccess('refarc.templates.access');
        $tpl = laralum::templatesParamsLast('id', $id);

        return view('laralum/templates/suivi', ['id' => $id, 'tpl' =>  $tpl]);
    }
    
    public function tpls($id)
    {
        # Check projects permissions
        Laralum::permissionToAccess('refarc.templates.access');

        $parents = Laralum::templatesNiv(['niv' => 0, 'id_template' => $id]);        
        $first_nivs = Laralum::templatesNiv(['niv' => 1, 'id_template' => $id]);
        $second_nivs = Laralum::templatesNiv(['niv' => 2, 'id_template' => $id]);
        $tpl = laralum::templatesParamsLast('id', $id);
       
        return view(
            'laralum/templates/tpls',
            [
                'id' => $id,
                'parents' =>  $parents,
                'first_nivs' =>  $first_nivs,
                'second_nivs' =>  $second_nivs,
                'tpl' =>  $tpl
            ]
        );
    }

    public function upload(Request $request)
    {
        Laralum::permissionToAccess('refarc.templates.access');

        # Check permissions
        Laralum::permissionToAccess('refarc.templates.edit');

        $picture = new Pictures();

        $row = Laralum::picturesCount();
        $key = count($row);


        $file = $request->file('file');

        # Check the file size for each file before uploading any of them
        $file_name = $file->getClientOriginalName();
        $max_upload = $file->getMaxFilesize() / 1000000;
        $max_upload = (string)$max_upload;
        if($file->getClientSize() == 0 or $file->getClientSize() > $file->getMaxFilesize()) {
            return redirect()->route('Laralum::files_upload')->with('error', trans('laralum.msg_max_file_size', ['file' => $file_name, 'number' => substr($max_upload, 0, 4)]));
        }
        $file_name = $request['version'].'_'.++$key.'_'.$file->getClientOriginalName();
        Storage::disk('uploadsTpl')->put($file_name, File::get($file));

        $picture->nom = $file_name;
        $picture->user_id = Laralum::loggedInUser()->id;
        $picture->id_app = 0;
        try {
            $picture->save();
        } catch (Exception $e) {
                throw $e;
        }

        return $file_name;

    } 

    public function update($id, Request $request)
    {
        Laralum::permissionToAccess('refarc.templates.access');

        # Check permissions
        Laralum::permissionToAccess('refarc.templates.edit');

        $req_id = $request['id'];

        $tpl = new Templates();
        $tpl->editTpl($req_id, $request);

        $row = Laralum::templates('id', $req_id);

        return $row;
        
    }

    private function getChild($id, $niv, $numPrg, $idTpl)
    {
        
        $childs = Templates::where('niv', '=', $niv)->where('parent', '=', $id)->where('id_template', '=', $idTpl)
        ->get();

        $newValue = '';
        $nbPrg = count($childs);
        $expPrg = explode('.', $numPrg);   

        if ($niv == 1) {
            $newValue = $expPrg[0].'.'.++$nbPrg;
        } elseif ($niv == 2) {
            $newValue = $expPrg[0].'.'.$expPrg[1].'.'.++$nbPrg;
        }
        
        return $newValue;
    }

    public function createParagraph($id, Request $request)
    {
        Laralum::permissionToAccess('refarc.templates.access');

        # Check permissions
        Laralum::permissionToAccess('refarc.templates.edit');

        $request['user_id'] = Laralum::loggedInUser()->id;

        $tpl = new Templates();

        $newNumPrg = self::getChild($request['id'], $request['niv'], $request['numPrg'], $id);
       
        if (!empty($newNumPrg)) {
            $tpl->addPrg($newNumPrg, $request);
        }

        return $row = Laralum::templates('id_template', $id);
    } 

    public function createNewParagraph($id, Request $request)
    {
        Laralum::permissionToAccess('refarc.templates.access');

        # Check permissions
        Laralum::permissionToAccess('refarc.templates.edit');

        $request['user_id'] = Laralum::loggedInUser()->id;

        $tpl = new Templates();

        $data = Templates::where('niv', '=', 0)->where('parent', '=', 0)->where('id_template', '=', $id)
        ->get();

        $LastParents = count($data);

        $newPrgNum = ++$LastParents;
       
        $tpl->addNewPrg($newPrgNum, $id, $request);

        return $row = Laralum::templates('id_template', $id);
    }  

    public function deleteParagraph($id, Request $request)
    {
        Laralum::permissionToAccess('refarc.templates.access');

        # Check permissions
        Laralum::permissionToAccess('refarc.templates.delete');
        
        $request['user_id'] = Laralum::loggedInUser()->id;


        $tpl = new Templates();

        $tpl->deletePrg($id, $request['id'], $request['niv'], $request['numPrg'], $request['parentId']);

        return $row = Laralum::templates('id_template', $id);
    }

    // Pour Gerer la liste des intervenants/diffusion generiques

    public function generic_users(){

        $interv_tpls = TemplatesInterv::all(); 
        $diff_tpls = TemplatesDiff::all();

        return view(
            'laralum/templates/users',
                [
                    'intervenants' =>  $interv_tpls,
                    'diffusion' =>  $diff_tpls,
                ]
        );
    }

    public function add_interv_tpls(Request $request){

        $intervenant = new TemplatesInterv();
        $request['user_id'] = Laralum::loggedInUser()->id;
        // Ajout de l'intervenant
        $intervenant = $intervenant->add_interv($request);

        return $intervenant->id;
    }

    public function del_interv_tpls($id){

        $intervenant = TemplatesInterv::where('id',$id);
        $intervenant->delete();
        return 'true';
    }

    public function add_diff_tpls(Request $request){

        $diffusion = new TemplatesDiff();
        $request['user_id'] = Laralum::loggedInUser()->id;

        // Ajout de la diffusion
        $diffusion = $diffusion->add_diff($request);

        return $diffusion->id;
    }

    public function del_diff_tpls($id){

        $diffusion = TemplatesDiff::where('id',$id);
        $diffusion->delete();

        return 'true';
    }

}

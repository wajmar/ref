<?php

namespace App\Http\Controllers\Laralum;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Role_User;
use App\Role;
use App\User;
use Laralum;
use Auth;
use Gate;

class UsersController extends Controller
{

    public function index()
    {
        Laralum::permissionToAccess('refarc.users.access');

    	# Get all users
    	$users = Laralum::users();
    	# Get the active users
    	$active_users = Laralum::users('active', true);

    	# Get Banned Users
    	$banned_users = Laralum::users('banned', true);

    	# Get all roles
    	$roles = Laralum::roles();

	$roles_user = Laralum::roles_user();

    	# Return the view
    	return view('laralum/users/index', [
    		'users' 		=> 	$users,
    		'roles'			=>	$roles,
		'roles_user'    	=>  	$roles_user,
    		'active_users'		=>	$active_users,
    		'banned_users'		=>	$banned_users,
		]);
    }

    public function show($id)
    {
        Laralum::permissionToAccess('refarc.users.access');

    	# Find the user
    	$user = Laralum::user('id', $id);
        $roles_user = Laralum::roles_user('user_id',$user->id);
        $roles = Laralum::roles();
        $projects_user = Laralum::projects('user_id',$user->id);

    	# Return the view
    	return view('laralum/users/show', ['user' => $user,'roles_user' => $roles_user,'roles' => $roles,'projects' => $projects_user]);
    }

    public function create()
    {
        Laralum::permissionToAccess('refarc.users.access');

        # Check permissions
        Laralum::permissionToAccess('refarc.users.create');

        # Get all roles
        $roles = Laralum::roles();

        # Get all the data
        $data_index = 'users';
        require('Data/Create/Get.php');

        # Return the view
        return view('laralum/users/create', [
            'roles'     =>  $roles,
            'fields'    =>  $fields,
            'confirmed' =>  $confirmed,
            'encrypted' =>  $encrypted,
            'hashed'    =>  $hashed,
            'masked'    =>  $masked,
            'table'     =>  $table,
            'code'      =>  $code,
            'wysiwyg'   =>  $wysiwyg,
            'relations' =>  $relations,
        ]);
    }

    public function store(Request $request)
    {
        Laralum::permissionToAccess('refarc.users.access');

        # Check permissions
        Laralum::permissionToAccess('refarc.users.create');

        # create the user
        $row = Laralum::newUser();
        $row->name = $request->name;
        $row->email = $request->email;
        $row->password = $request->password;


        # Setup a random activation key
        $row->activation_key = str_random(25);

        # Get the register IP
        $row->register_ip = $request->ip();

        # Activate the user if set
        if($request->input('active')){
            $row->active = true;
        }

        # Save the user
        $row->save();

        # Send welcome email if set
        if($request->input('mail')) {
            # Send Welcome email
            $row->sendWelcomeEmail($row);
        }

        # Send activation email if set
        if($request->input('send_activation')) {
            $row->sendActivationEmail($row);
        }

        // Recuperation de tous les roles
        $roles = Role::all();
        // Bouche sur tous les roles
        foreach($roles as $role){
            // Si le role a ete cocher
            if($request[''.$role->id.''] == 'on'){
                $role_user = new Role_User;
                $role_user->role_id = $role->id;
                $role_user->user_id = $row->id;
                $role_user->save();
            }
        }

        # Return the admin to the users page with a success message
        return redirect()->route('Laralum::users')->with('success', trans('laralum.msg_user_created'));
    }

    public function edit($id)
    {
        # Find the user
        $row = Laralum::user('id', $id);
        $roles = Laralum::roles();
        $roles_user = Laralum::roles_user('user_id',$row->id);
        //print_r($roles_user[0]->id);
        //die;

        # Check if admin access
        /*Laralum::mustNotBeAdmin($row);*/

        # Return the view
        return view('laralum/users/edit', [
            'row'       =>  $row,
            'roles'      => $roles,
            'roles_user' => $roles_user,
        ]);
    }

    public function update($id, Request $request)
    {
        Laralum::permissionToAccess('refarc.users.access');

        # Check permissions
        Laralum::permissionToAccess('refarc.users.edit');

        # Find the user
        $row = Laralum::user('id', $id);

        # Check if admin access
        /*Laralum::mustNotBeAdmin($row);*/

        // Mise a jour de l'utilisateur
        $user = new User();
        $user = $user->update_user($id,$request);

        # Return the admin to the users page with a success message
        return redirect()->route('Laralum::users')->with('success', trans('laralum.msg_user_edited'));    
    }

    public function editRoles($id)
    {
        Laralum::permissionToAccess('refarc.users.access');

        # Check permissions
        Laralum::permissionToAccess('refarc.users.roles');

    	# Find the user
    	$user = Laralum::user('id', $id);

        # Check if admin access
        Laralum::mustNotBeAdmin($user);

    	# Get all roles
    	$roles = Laralum::roles();

    	# Return the view
    	return view('laralum/users/roles', ['user' => $user, 'roles' => $roles]);
    }

    public function setRoles($id, Request $request)
    {
        Laralum::permissionToAccess('refarc.users.access');

        # Check permissions
        Laralum::permissionToAccess('refarc.users.roles');

		# Find the user
    	$user = Laralum::user('id', $id);

        # Check if admin access
        Laralum::mustNotBeAdmin($user);

    	# Get all roles
    	$roles = Laralum::roles();

    	# Change user's roles
    	foreach($roles as $role) {

            $modify = true;

            # Check for su
            if($role->su) {
                $modify = false;
            }

            # Check if it's assignable
            if(!$role->assignable) {
                $modify = false;
            }

            if($modify) {
                if($request->input($role->id)){
                    # The admin selected that role

                    # Check if the user was already in that role
                    if($this->checkRole($user->id, $role->id)) {
                        # The user is already in that role, so no change is made
                    } else {
                        # Add the user to the selected role
                        $this->addRel($user->id, $role->id);
                    }
                } else {
                    # The admin did not select that role

                    # Check if the user was in that role
                    if($this->checkRole($user->id, $role->id)) {
                        # The user is in that role, so as the admin did not select it, we need to delete the relationship
                        $this->deleteRel($user->id, $role->id);
                    } else {
                        # The user is not in that role and the admin did not select it
                    }
                }
            }
    	}

    	# Return Redirect
        return redirect()->route('Laralum::users')->with('success', trans('laralum.msg_user_roles_edited'));
    }

    public function checkRole($user_id, $role_id)
    {
        Laralum::permissionToAccess('refarc.users.access');

    	# This function returns true if the specified user is found in the specified role and false if not

    	if(Role_User::whereUser_idAndRole_id($user_id, $role_id)->first()) {
    		return true;
    	} else {
    		return false;
    	}

    }

    public function deleteRel($user_id, $role_id)
    {
        Laralum::permissionToAccess('refarc.users.access');

    	$rel = Role_User::whereUser_idAndRole_id($user_id, $role_id)->first();
    	if($rel) {
    		$rel->delete();
    	}
    }

    public function addRel($user_id, $role_id)
    {
        Laralum::permissionToAccess('refarc.users.access');

    	$rel = Role_User::whereUser_idAndRole_id($user_id, $role_id)->first();
    	if(!$rel) {
    		$rel = new Role_User;
    		$rel->user_id = $user_id;
    		$rel->role_id = $role_id;
    		$rel->save();
    	}
    }

    public function destroy($id)
    {
        Laralum::permissionToAccess('refarc.users.access');

        # Check permissions
        Laralum::permissionToAccess('refarc.users.delete');

        # Find The User
        $user = Laralum::user('id', $id);

        # Check if admin access
        Laralum::mustNotBeAdmin($user);

        # Check if it's su
        if($user->su) {
            abort(403, trans('laralum.error_security_reasons'));
        }

    	# Check before deleting
    	if($id == Laralum::loggedInUser()->id) {
            abort(403, trans('laralum.error_user_delete_yourself'));
    	} else {

    		# Delete Relationships
    		$rels = Role_User::where('user_id', $user->id)->get();
    		foreach($rels as $rel) {
    			$rel->delete();
    		}

    		# Delete User
    		$user->delete();

    		# Return the admin with a success message
            return redirect()->route('Laralum::users')->with('success', trans('laralum.msg_user_deleted'));
    	}
    }

    public function editSettings()
    {
        Laralum::permissionToAccess('refarc.users.access');

        # Check permissions
        Laralum::permissionToAccess('refarc.users.settings');

    	# Get the user settings
    	$rows = Laralum::userSettings();
        $roles = Laralum::roles();
        $select_data = [
            0  =>  trans('laralum.dropdown_manual_activation'),
            1  =>  trans('laralum.dropdown_send_activation_mail'),
            2  =>  trans('laralum.dropdown_activated_by_default')
        ];
        if (!empty($rows) && !empty($roles)) {
            # Return the view
            return view('laralum/users/settings', ['rows' =>  $rows, 'roles' => $roles, 'select_data' => $select_data]);
        }

    }

    public function updateSettings(Request $request)
    {
        Laralum::permissionToAccess('refarc.users.access');

        # Check permissions
        Laralum::permissionToAccess('refarc.users.settings');

    	# Get the user settings
    	$row = Laralum::userSettings();

    	$row->default_role = $request['default_role'];
        $row->location = ($request['location'] == 'on') ? 1 : 0;
        $row->register_enabled = ($request['register_enabled'] == 'on') ? 1 : 0;
        $row->default_active = $request['default_active'];
        $row->welcome_email = ($request['welcome_email'] == 'on') ? 1 : 0;

        try {
            $row->save();
        } catch (Exception $e) {
            return $e;
        }

    	# Return a redirect
        return redirect()->route('Laralum::users')->with('success', trans('laralum.msg_user_update_settings'));
    }
}
